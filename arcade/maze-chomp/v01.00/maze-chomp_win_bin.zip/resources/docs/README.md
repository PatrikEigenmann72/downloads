Documents shipped with the app. `Maze-Chomp.docx` (source) / `Maze-Chomp.pdf` - the manual: how to
play, controls, points, bonus fruit, leaderboard, where scores are kept, and the notes on running
an unsigned binary past Gatekeeper/SmartScreen the first time, or building it yourself instead.

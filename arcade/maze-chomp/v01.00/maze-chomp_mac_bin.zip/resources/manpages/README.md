Numbered `NN_name.man` files, shown in-game by the engine's help viewer (`engine/arcade_manpage.h`,
Fn+F1 on the title page, after GAME OVER or while paused) in filename order. Same markup as the legacy
apps' `.man` files: `{title:"..."}`, `{link:"label","file.man"}`, `{navigation}`, and plain
paragraphs separated by a blank line.

# resources

Standard arcade project layout, mostly the same subfolder taxonomy `legacy/cobs` and
`legacy/tone3` already use:

- **defaults/** - factory defaults (the preset leaderboard), copied to app data on first run
- **config/** - key=value settings (`config.data`, via `toolbox/config`), free-form help text
- **icons/** - app icon image(s)
- **manpages/** - numbered `NN_name.man` files, read by `toolbox/help/manpage.c` - plural here,
  a deliberate departure from both legacy apps' singular `manpage/`
- **pictures/** - sprite/image assets, loaded via `toolbox/pictures`
- **sounds/** - music/sound-effect `.wav` files, loaded via `toolbox/audio/wav.c`

Most of these are still empty - maze-chomp is fully procedural today (shapes drawn via code,
sound synthesized by `arcade_sfx`). Everything in `resources/` is read-only once installed. The leaderboard and the
player name live in the game's app-data folder (`%APPDATA%\maze-chomp`, `~/Library/Application Support/maze-chomp`)
as `leaderboard.dat` and `settings.dat` (flat files via `toolbox/db/persistence`, see
`engine/arcade_leaderboard.h`) - see `shared/toolbox/STORAGE.md`.

`config.data` - App.Name/App.Description (window title, title-screen marquee/tagline), the
leaderboard file names in app data (Path.Leaderboard, Path.Settings), and the standard state-label texts
(READY!/PAUSED/GAME OVER/LEADERBOARD/etc.),
loaded once at startup via `toolbox/config`. Same key=value format as `legacy/cobs` and
`legacy/tone3`'s own `config.data`.
A `config.data` in the game's app-data folder, if present, overrides these values key by key.

`defaults/` - factory defaults (shared/toolbox/STORAGE.md). On start the game copies each file here
into its app-data folder (`%APPDATA%\maze-chomp`, `~/Library/Application Support/maze-chomp`) **only if
it isn't there yet** - a player's own leaderboard is never overwritten. Delete the app-data copy to
get the preset back.

- **leaderboard.dat** - the arcade-style preset leaderboard (format: `engine/arcade_leaderboard.h`)

No `settings.dat` here on purpose: a new player is asked for a name.

Reserved for sprite/image assets, loaded via `toolbox/pictures` - empty for now, maze-chomp is
still fully procedural (shapes drawn via code).

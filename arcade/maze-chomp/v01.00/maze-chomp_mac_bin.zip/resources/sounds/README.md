Music `.wav` files, loaded via `toolbox/audio/wav.c` and played on the engine's `arcade_sfx` music
track (sound effects are still synthesized at runtime). 44100 Hz - `wav.c` doesn't resample.

- `beginning.wav` - loops on the title page.
- `intermission.wav` - loops while the apple's ghost hunt runs.

The paths are in `resources/config/config.data` (`Sound.Beginning`, `Sound.Intermission`).

Reserved for the app's own icon (PNG), same as `legacy/tone3/resources/icons/` - empty for now.

#!/bin/bash
# ------------------------------------------------------------------------------------
# Script:       compile.sh
# Description:  Builds one tool in this project by name (its folder must contain a
#               matching <tool>.pmake). Forwards to pmake from inside that folder, then
#               normalizes the result. bin/'s top level always shows the same
#               ever-accumulating build history, in every repo - pmake's own
#               version-suffixed output (bin/<tool>_vXX.XX), left exactly where pmake
#               wrote it, so you can always tell what's actually been compiled. What
#               happens next differs by repo: in the terminal project, a flat
#               bin/<tool> copy (no suffix) is the whole deliverable - a CLI tool is
#               just a binary, nothing else to organize. Everywhere else (legacy,
#               arcade, ...), bin/<tool>/ becomes a self-contained deployable copy (the
#               binary, plain name, plus the project's own resources/ synced in via
#               rsync, *.db files excluded - a live database bin/<tool>/<tool> itself
#               writes into is never something this script should overwrite from the
#               source tree's own copy) - so a project reading resources/skin/,
#               .../config/, etc. via a relative path works the same run straight from
#               bin/<tool>/ as it does from its source folder), and bin/<tool>.lnk is a
#               top-level symlink into it for convenience (the .lnk suffix avoids
#               colliding with the bin/<tool>/ folder's own name). Either way, this
#               script doesn't build a bundle, an install, or anything else - see
#               scripts/install.sh for what happens next.
# ------------------------------------------------------------------------------------
# Author:       Patrik Eigenmann
# eMail:        p.eigenmann72@gmail.com
# ------------------------------------------------------------------------------------
# Change Log:
# Mon 2026-10-12 Versions 00.01-00.15: builds one tool with pmake               Version: 00.01 - 00.15
#                (<tool>.pmake) from inside its own folder, then normalizes the
#                result in bin/. pmake's version-suffixed output always stays
#                at bin/'s top level as the build history; the terminal repo
#                gets a flat bin/<tool> copy, every other repo a self-contained
#                bin/<tool>/ folder - the binary plus a fresh copy of
#                resources/ (rsync, *.db excluded) and data/*.db only if not
#                already there, so a live database is never overwritten. Every
#                copy is atomic (copy to .new, then mv - avoids macOS's
#                code-signing SIGKILL on a just-overwritten binary). One script
#                for every repo, the repo detected by folder name; every step
#                announces itself, and the "Done." line names the build pmake
#                just made. Full entry-by-entry history archived in
#                compile.changelog.txt.
# Mon 2026-10-12 Released script to stable version.                             Version: 01.00
# ------------------------------------------------------------------------------------

show_help() {
cat << EOF
NAME
    compile.sh - build one tool/project's binary and normalize it in bin/

SYNOPSIS
    scripts/compile.sh <tool> [pmake args...]

DESCRIPTION
    Builds the <tool> folder using its <tool>.pmake file. pmake's own
    version-suffixed output always stays at bin/'s top level, untouched. In
    the terminal project, a flat bin/<tool> copy (no suffix) is the whole
    deliverable. Everywhere else, bin/<tool>/ becomes a self-contained
    deployable copy (the binary, plain name, plus the project's own
    resources/), and bin/<tool>.lnk is a top-level symlink into it for
    convenience. See scripts/install.sh for what happens to that next (a CLI
    tool copied flat, or a real project turned into a double-clickable
    bundle). Any extra
    arguments are forwarded straight through to pmake - see 'pmake -h' for
    what it accepts (-DDEBUG, --debug, --keywords). Run from anywhere inside
    the project.

EXAMPLES
    scripts/compile.sh pmake
    scripts/compile.sh enigma -DDEBUG
    scripts/compile.sh enigma --debug:warn
EOF
}

case "$1" in
    -h|-help|-\?|"")
        show_help
        exit 0
        ;;
esac

set -e

TOOL="$1"
shift

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOL_DIR="$PROJECT_ROOT/$TOOL"

if [ ! -d "$TOOL_DIR" ]; then
    echo "No such tool folder: $TOOL_DIR"
    exit 1
fi

echo "Building $TOOL..."
cd "$TOOL_DIR"
pmake "$TOOL" "$@"

# pmake names its output "<tool>_<suffix>" (version, and OS if is_os_gnostic=on) and
# always writes it flat into bin/ - normalizing it below is this script's own job, not
# pmake's.
BUILT="$(ls -t "$PROJECT_ROOT/bin/${TOOL}"_* 2>/dev/null | head -n1)"
if [ -z "$BUILT" ]; then
    echo "pmake did not produce a binary in $PROJECT_ROOT/bin."
    exit 1
fi

REPO_NAME="$(basename "$PROJECT_ROOT")"

if [ "$REPO_NAME" = "terminal" ]; then
    # A CLI tool is just a binary, the same way ls/cat/cp/rm always were - a flat,
    # OS/version-suffix-free copy is the whole deliverable, no resources/ concept at all.
    # Clears away a stale bin/<tool>/ directory first, in case this project was last
    # built by an older version of this script.
    FLAT_BIN="$PROJECT_ROOT/bin/$TOOL"
    echo "Normalizing: bin/$(basename "$BUILT") -> bin/$TOOL"
    if [ -d "$FLAT_BIN" ]; then
        rm -rf "$FLAT_BIN"
    fi
    # Atomic copy-then-rename, same reasoning as the non-terminal branch below - see its own
    # comment for the macOS code-signing bug this avoids.
    cp "$BUILT" "$FLAT_BIN.new"
    chmod +x "$FLAT_BIN.new"
    mv -f "$FLAT_BIN.new" "$FLAT_BIN"

    echo "Done. Type './bin/$(basename "$BUILT")' (from $PROJECT_ROOT) to run, or scripts/install.sh $TOOL to install it."
else
    # pmake's own version-suffixed output ($BUILT) stays exactly where pmake put it, at
    # bin/'s top level, untouched - that's the flat, ever-accumulating build history
    # (bin/<tool>_vXX.XX, bin/<tool>_vYY.YY, ...), same idea as the terminal project's
    # own bin/, just without a plain flat name competing for the same spot.
    #
    # bin/<tool>/ is the self-contained, deployable unit: a real copy of the binary
    # (plain name, no version/OS suffix) plus a fresh copy of the project's own
    # resources/ (skin, config, db, ...) - so a project reading e.g.
    # resources/skin/<tool>.skin via a path relative to its own working directory finds
    # it the same way whether run from bin/<tool>/ or from its own source folder. This
    # folder is what install.sh turns into a bundle, and what you'd copy/zip elsewhere
    # to hand someone a working copy.
    #
    # bin/<tool>.lnk is a symlink into that folder, purely for convenience - so you can
    # type/tab-complete bin/<tool>.lnk from bin/'s own top level instead of digging into
    # bin/<tool>/<tool>. The .lnk suffix exists only to avoid colliding with the
    # bin/<tool>/ folder's own name - a symlink and a directory can't share one name.
    #
    # Clears away a stale bin/<tool> FILE first (mkdir -p fails if a plain file already
    # sits at that path) - in case this project was last built by an older version of
    # this script, when bin/<tool> itself used to be that flat file.
    BIN_DIR="$PROJECT_ROOT/bin/$TOOL"
    if [ -f "$BIN_DIR" ]; then
        rm -f "$BIN_DIR"
    fi
    mkdir -p "$BIN_DIR"

    echo "Copying: bin/$(basename "$BUILT") -> bin/$TOOL/$TOOL"
    # Copy to a temp name, then atomically rename into place - overwriting bin/<tool>/<tool>
    # in-place (the old plain "cp" here) hit a real macOS bug: rebuilding and relaunching the
    # same path in quick succession (e.g. scripts/compile.sh <tool> && scripts/term.sh <tool>,
    # repeated) can leave the kernel's code-signing validation for that inode out of sync with
    # its just-overwritten content, killing the very next launch with SIGKILL (Code Signature
    # Invalid) - not a bug in the tool itself. mv within the same directory is atomic and always
    # produces a fresh inode, so there's nothing stale left to race against.
    cp "$BUILT" "$BIN_DIR/$TOOL.new"
    chmod +x "$BIN_DIR/$TOOL.new"
    mv -f "$BIN_DIR/$TOOL.new" "$BIN_DIR/$TOOL"

    if [ -d "$TOOL_DIR/resources" ]; then
        echo "Copying: $TOOL/resources -> bin/$TOOL/resources (except *.db - see this script's own changelog)"
        mkdir -p "$BIN_DIR/resources"
        rsync -a --delete --exclude='*.db' "$TOOL_DIR/resources/" "$BIN_DIR/resources/"
    fi

    # A live database (e.g. cobs's own data/cobs.db) lives in data/, not resources/ - same
    # never-overwrite protection as resources/'s own *.db exclusion above, just for the
    # standard <app>/data/*.db location (matching python's own convention - see this file's
    # own Version 00.14 entry). Only ever copies a *.db that isn't already sitting in
    # bin/$TOOL/data/; baseline-scripts.txt and the resources/sql/*.sql scripts it lists stay
    # read directly from the source tree at pack.sh's own baseline-build time, never copied
    # here.
    if [ -d "$TOOL_DIR/data" ]; then
        mkdir -p "$BIN_DIR/data"
        for src_db in "$TOOL_DIR/data"/*.db; do
            [ -e "$src_db" ] || continue
            dest_db="$BIN_DIR/data/$(basename "$src_db")"
            if [ -f "$dest_db" ]; then
                echo "Keeping: bin/$TOOL/data/$(basename "$dest_db") (already installed - not overwritten from source)"
            else
                echo "Copying: $TOOL/data/$(basename "$src_db") -> bin/$TOOL/data/$(basename "$src_db")"
                cp "$src_db" "$dest_db"
            fi
        done
    fi

    LNK="$PROJECT_ROOT/bin/$TOOL.lnk"
    if [ -d "$LNK" ]; then
        rm -rf "$LNK"
    fi
    echo "Linking: bin/$TOOL.lnk -> $TOOL/$TOOL"
    ln -sf "$TOOL/$TOOL" "$LNK"

    echo "Done. Type './bin/$TOOL/$TOOL' (from $PROJECT_ROOT) to run - $(basename "$BUILT") with its resources - or scripts/install.sh $TOOL to install it."
fi

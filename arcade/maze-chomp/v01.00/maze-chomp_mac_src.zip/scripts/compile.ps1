# ------------------------------------------------------------------------------------
# Script:       compile.ps1
# Description:  Builds one tool in this project by name (its folder must contain a
#               matching <tool>.pmake). Forwards to pmake from inside that folder, then
#               installs the result into bin\ - a flat bin\<tool>.exe binary in the
#               terminal project (a CLI tool is just a binary, same as ls/cat/cp always
#               were), or a self-contained bin\<tool>\ directory everywhere else (legacy,
#               arcade, ...) - the binary plus a copy of the project's own resources\
#               tree, if it has one, so a built project can be run or copied elsewhere
#               without depending on the source checkout it was built from. Windows port
#               of compile.sh - see that file's own changelog for shared history.
# ------------------------------------------------------------------------------------
# Author:       Patrik Eigenmann
# eMail:        p.eigenmann72@gmail.com
# ------------------------------------------------------------------------------------
# Change Log:
# Mon 2026-10-12 Versions 00.01-00.09: Windows port of compile.sh. Always     Version: 00.01 - 00.09
#                builds <tool>_win.pmake, never the macOS <tool>.pmake - a
#                missing one stops with a clear message. pmake's versioned
#                .exe stays at the top of bin\ as the build history; the
#                terminal repo gets a flat bin\<tool>.exe copy, every other
#                repo a self-contained bin\<tool>\ folder - the .exe, a fresh
#                copy of resources\ and data\*.db only if not already there.
#                Copy-Item, never Move-Item, so no build is lost. Icons are
#                not part of compiling - install.ps1 makes them from the
#                source PNG. The "Done." line names the build pmake just
#                made. Full entry-by-entry history archived in
#                compile.changelog.txt.
# Mon 2026-10-12 Released script to stable version.                           Version: 01.00
# ------------------------------------------------------------------------------------

param(
    [Parameter(Position = 0)]
    [string]$Tool,

    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$PmakeArgs
)

function Show-Help {
    @"
NAME
    compile.ps1 - build one tool/project and install it into bin\

SYNOPSIS
    scripts\compile.ps1 <tool> [pmake args...]

DESCRIPTION
    Builds the <tool> folder using its <tool>_win.pmake file (<tool>.pmake is
    the macOS one, used by compile.sh), then installs the
    result into bin\ - a flat bin\<tool>.exe binary in the terminal project,
    or a self-contained bin\<tool>\ directory (binary + a copy of the
    project's own resources\ tree, if any) in every other project (legacy,
    arcade, ...). Any extra arguments are forwarded straight through to
    pmake - see 'pmake -h' for what it accepts (-DDEBUG, --debug,
    --keywords). Run from anywhere inside the project.

EXAMPLES
    scripts\compile.ps1 pmake
    scripts\compile.ps1 enigma -DDEBUG
    scripts\compile.ps1 enigma --debug:warn
"@
}

if (-not $Tool -or $Tool -eq '-h' -or $Tool -eq '-help' -or $Tool -eq '-?') {
    Show-Help
    exit 0
}

$ErrorActionPreference = 'Stop'

$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$ToolDir = Join-Path $ProjectRoot $Tool

if (-not (Test-Path $ToolDir -PathType Container)) {
    Write-Host "No such tool folder: $ToolDir"
    exit 1
}

Write-Host "Building $Tool..."
Push-Location $ToolDir
try {
    # Windows always builds <tool>_win.pmake - <tool>.pmake is macOS's (compile.sh). pmake cuts its
    # argument at the last dot, so the OS can't be a second extension.
    if (-not (Test-Path (Join-Path $ToolDir "${Tool}_win.pmake") -PathType Leaf)) {
        Write-Host "No Windows build file: $Tool\${Tool}_win.pmake ($Tool.pmake is the macOS one - create the _win twin)."
        exit 1
    }
    & pmake "${Tool}_win" @PmakeArgs
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
finally {
    Pop-Location
}

# pmake names its output "<tool>_<suffix>.exe" (version, and OS if is_os_gnostic=on) and
# always writes it flat into bin\ - installation (below) is this script's job, not pmake's.
$Built = Get-ChildItem -Path (Join-Path $ProjectRoot 'bin') -Filter "$Tool`_*.exe" -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if (-not $Built) {
    Write-Host "pmake did not produce a binary in $ProjectRoot\bin - nothing to install."
    exit 1
}

$RepoName = Split-Path -Leaf $ProjectRoot

if ($RepoName -eq 'terminal') {
    # A CLI tool is just a binary, the same way ls/cat/cp/rm always were - no project
    # folder, nothing else to install alongside it. Clears away a stale bin\<tool>\
    # directory first, in case this tool used to be installed the other way.
    $FlatPath = Join-Path $ProjectRoot "bin\$Tool.exe"
    $StaleDir = Join-Path $ProjectRoot "bin\$Tool"
    if (Test-Path $StaleDir -PathType Container) {
        Remove-Item -Recurse -Force $StaleDir
    }
    Copy-Item -Force $Built.FullName $FlatPath
    Write-Host "Done. Type './bin/$($Built.Name)' (from $ProjectRoot) to run."
}
else {
    # A real project can have its own file structure (resources\, ...), so it gets a
    # self-contained bin\<tool>\ directory - the binary plus a copy of whatever
    # resources\ the project ships, mirroring how a legacy install put an app's own
    # files together in one directory rather than scattering them. Clears away a
    # stale flat bin\<tool>.exe binary first, in case this tool used to be installed
    # the other way.
    $InstallDir = Join-Path $ProjectRoot "bin\$Tool"
    $StaleFile = Join-Path $ProjectRoot "bin\$Tool.exe"
    if (Test-Path $StaleFile -PathType Leaf) {
        Remove-Item -Force $StaleFile
    }
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Copy-Item -Force $Built.FullName (Join-Path $InstallDir "$Tool.exe")

    $ResourcesSrc = Join-Path $ToolDir 'resources'
    if (Test-Path $ResourcesSrc -PathType Container) {
        $ResourcesDst = Join-Path $InstallDir 'resources'
        if (Test-Path $ResourcesDst) {
            Remove-Item -Recurse -Force $ResourcesDst
        }
        Copy-Item -Recurse -Force $ResourcesSrc $ResourcesDst
    }

    # A database (e.g. cobs's data\cobs.db) lives in data\, not resources\ - the factory default
    # the program copies into the user's app data on first run (shared/toolbox/STORAGE.md). Same
    # rule as compile.sh: only copied if bin\<tool>\data\ doesn't already hold one by that name.
    $DataSrc = Join-Path $ToolDir 'data'
    $DbFiles = Get-ChildItem -Path $DataSrc -Filter '*.db' -File -ErrorAction SilentlyContinue
    if ($DbFiles) {
        $DataDst = Join-Path $InstallDir 'data'
        New-Item -ItemType Directory -Force -Path $DataDst | Out-Null
        foreach ($Db in $DbFiles) {
            $DestDb = Join-Path $DataDst $Db.Name
            if (Test-Path $DestDb -PathType Leaf) {
                Write-Host "Keeping: bin\$Tool\data\$($Db.Name) (already there - not overwritten from source)"
            }
            else {
                Write-Host "Copying: $Tool\data\$($Db.Name) -> bin\$Tool\data\$($Db.Name)"
                Copy-Item -Force $Db.FullName $DestDb
            }
        }
    }

    Write-Host "Done. Type './bin/$Tool/$Tool.exe' (from $ProjectRoot) to run - $($Built.Name) with its resources."
}

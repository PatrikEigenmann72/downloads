// -----------------------------------------------------------------------------------------------
// main.c - Maze Chomp: eat every dot, power pellets turn the hunters blue, clear the maze to
// advance. A port of web/apps/maze-chomp.html to the arcade engine - same maze, same speeds and
// timings, same ghost personalities (Blinky chases, Pinky ambushes four tiles ahead, Inky
// pincers off Blinky, Clyde loses interest up close), same scatter/chase phases and scoring.
//
// Controls: arrows or WASD move, P pauses, M toggles sound, SPACE starts a game from the title
// page and restarts after game over, ESC quits.
//
// Coordinates: the maze keeps the browser version's own pixel space (19 x 21 cells of 20 px,
// cell centers at col*20+10), drawn MAZE_Y pixels down to leave room for the HUD above it.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-10-12 Versions 00.01-00.22: ported from web/apps/maze-chomp.html onto  Version: 00.22
//                the arcade engine (same maze, speeds, ghost personalities and
//                scoring); title page; mac window at 80% of the Windows size;
//                config.data; the shared leaderboard (persistent player name,
//                flat files, top 100, auto-scrolling board); the storage
//                standard (app-data folder, first-run seeding); --version;
//                bonus fruit with the original's level table, orange
//                invincibility and apple ghost hunt with a status strip; title
//                and ghost-hunt music; Fn+F1 help through the engine's manpage
//                viewer; version in the window title; log file in
//                ~/Documents/Logs. Full entry-by-entry history archived in
//                main.changelog.txt.
// Mon 2026-10-12 Major Release.                                                    Version: 01.00
// -----------------------------------------------------------------------------------------------
#include "arcade.h"
#include "logging/debug.h"
#include "logging/log.h"
#include "arcade_sfx.h"
#include "arcade_leaderboard.h"
#include "arcade_manpage.h"
#include "config/config.h"
#include "help/version.h" // --version standard - version_requested() in main().
#include "platform.h"

#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// pmake reads MAJOR/MINOR from here to name the binary (maze-chomp_vMM.mm).
#define MAJOR 1
#define MINOR 0

// The program's name as --version shows it (shared/toolbox/help/version.h).
#define APP_NAME    "maze-chomp"

// The title page's and GAME OVER's key hints. The bare F keys belong to the OS on Mac and Windows
// keyboards alike (F1 dims the screen) - Fn+F1 is what arrives here as F1.
#define KEY_HINTS "FN+F1 HELP   D LEADERBOARD   N NAME"
// ------------------------------------------------------------------------------------------
// Layout
// ------------------------------------------------------------------------------------------
#define ROWS 21
#define COLS 19
#ifdef __APPLE__
#define CELL 16                     // 80% of the Windows build's tile size - macOS window felt too large
#else
#define CELL 20
#endif
#define MAZE_W (COLS * CELL)       // 380
#define MAZE_H (ROWS * CELL)       // 420
#define HUD_H 36                   // score / title / lives above the maze
#define STATUS_H 18                // active fruit effects and the fruits eaten, under the maze
#define FOOT_H 16                  // key help below it
#define MAZE_Y HUD_H
#define STATUS_Y (MAZE_Y + MAZE_H)
#define FB_W MAZE_W
#define FB_H (HUD_H + MAZE_H + STATUS_H + FOOT_H)
#define PIXEL_SCALE 2

// '#' wall, '.' dot, 'o' power pellet, ' ' open, '-' the ghost-house door (open for ghosts and
// Maze Chomp alike, exactly like the browser version's tileAt() treats it).
static const char *MAZE[ROWS] = {
    "###################",
    "#o...............o#",
    "#.#.###########.#.#",
    "#.#.###########.#.#",
    "#........#........#",
    "#.#.###########.#.#",
    "#.................#",
    "#.#######.#######.#",
    "#.#######.#######.#",
    "...................",
    "#.##### #-# #####.#",
    "#.######   ######.#",
    "#.###############.#",
    "#.................#",
    "#.#######.#######.#",
    "#.#######.#######.#",
    "#.................#",
    "#.#.###########.#.#",
    "#.#.###########.#.#",
    "#o...............o#",
    "###################"
};

// ------------------------------------------------------------------------------------------
// Colors - the browser version's CSS custom properties.
// ------------------------------------------------------------------------------------------
#define COL_VOID        ARCADE_RGB(0x06, 0x06, 0x0c)
#define COL_SCREEN      ARCADE_RGB(0x0b, 0x0c, 0x1a)
#define COL_WALL        ARCADE_RGB(0x28, 0x46, 0xff)
#define COL_WALL_GLOW   ARCADE_RGB(0x5a, 0x74, 0xff)
#define COL_DOT         ARCADE_RGB(0xf5, 0xe6, 0xc8)
#define COL_PAC         ARCADE_RGB(0xff, 0xd6, 0x0a)
#define COL_FRIGHT      ARCADE_RGB(0x2b, 0x3f, 0xdb)
#define COL_FRIGHT_FLASH ARCADE_RGB(0xf2, 0xf2, 0xf2)
#define COL_EYE_WHITE   ARCADE_RGB(0xee, 0xf1, 0xff)
#define COL_EYE_PUPIL   ARCADE_RGB(0x1a, 0x20, 0x40)
#define COL_INK         ARCADE_RGB(0xe9, 0xe8, 0xff)
#define COL_MUTED       ARCADE_RGB(0x83, 0x88, 0xc0)
#define COL_POINTS      ARCADE_RGB(0xff, 0xf2, 0xb0)
#define COL_RED         ARCADE_RGB(0xff, 0x3b, 0x3b)
#define COL_CYAN        ARCADE_RGB(0x4d, 0xe3, 0xe0)
#define COL_ORANGE      ARCADE_RGB(0xff, 0x9a, 0x1f)
#define COL_LEAF        ARCADE_RGB(0x3c, 0xc8, 0x4a)
#define COL_STEM        ARCADE_RGB(0x9a, 0x5a, 0x2a)
#define COL_MELON       ARCADE_RGB(0x3f, 0xb8, 0x5a)
#define COL_MELON_DARK  ARCADE_RGB(0x1e, 0x6e, 0x30)
#define COL_BELL        ARCADE_RGB(0xff, 0xd8, 0x3a)
#define COL_KEY         ARCADE_RGB(0x9e, 0xe6, 0xff)
#define COL_WING        ARCADE_RGB(0x5a, 0x9a, 0xff)

// ------------------------------------------------------------------------------------------
// Directions
// ------------------------------------------------------------------------------------------
enum { DIR_NONE, DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT };
static const int DX[5] = { 0, 0, 0, -1, 1 };
static const int DY[5] = { 0, -1, 1, 0, 0 };
static const int ALL_DIRS[4] = { DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT };

// ------------------------------------------------------------------------------------------
// Game state
// ------------------------------------------------------------------------------------------

// Anything that walks the maze cell to cell: current cell, pixel position, the cell center it's
// heading for, and its direction.
typedef struct {
    int row, col;
    double x, y;
    double tx, ty;
    int dir;
} Mover;

typedef enum { BLINKY, PINKY, INKY, CLYDE, GHOST_COUNT } GhostName;
typedef enum { G_HOUSE, G_EXITING, G_NORMAL, G_DESCENDING } GhostState;
typedef enum { SP_NONE, SP_FRIGHTENED, SP_EATEN } GhostSpecial;

typedef struct {
    Mover m;
    GhostName name;
    double speed;
    GhostState state;
    GhostSpecial special;
    double fright_timer;
    double release_timer;
    double bob;           // idle bobbing phase while waiting in the house
} Ghost;

typedef struct {
    Mover m;
    double speed;
    double mouth;         // mouth animation phase
} Pac;

#define MAX_PARTICLES 8
typedef struct {
    double x, y, vy, life;
    int points;
} Particle;

typedef enum { ITEM_NONE, ITEM_DOT, ITEM_PELLET } Item;

// The original's bonus fruit, in the order the levels bring them (fruit_for_level()).
typedef enum {
    FRUIT_CHERRY, FRUIT_STRAWBERRY, FRUIT_ORANGE, FRUIT_APPLE,
    FRUIT_MELON, FRUIT_GALAXIAN, FRUIT_BELL, FRUIT_KEY, FRUIT_COUNT
} FruitKind;
static const int FRUIT_POINTS[FRUIT_COUNT] = { 100, 300, 500, 700, 1000, 2000, 3000, 5000 };

#define FRUIT_SOLID_SECS 20.0      // on the maze, steady
#define FRUIT_BLINK_SECS 5.0       // then blinking, then gone
#define FRUIT_INVINCIBLE_SECS 8.0  // orange: ghosts pass harmlessly through
#define FRUIT_HUNT_SECS 8.0        // apple: every ghost on the maze stays blue
#define FRUIT_SHOWN 7              // fruits eaten this game, listed in the status strip

#define MUSIC_VOL 0.15             // the clips peak near full scale - this sits them with the beeps
typedef enum { ST_TITLE, ST_READY, ST_PLAYING, ST_PAUSED, ST_DYING, ST_GAMEOVER, ST_WIN } GameState;

typedef struct {
    ArcadeWindow *window;
    Item dots[ROWS][COLS];
    int dots_remaining;
    int score, lives, level;
    Pac pac;
    Ghost ghosts[GHOST_COUNT];
    Particle particles[MAX_PARTICLES];
    int particle_count;
    bool scatter;         // global phase: scatter (true) or chase (false)
    int phase_idx;
    double phase_elapsed;
    int eat_chain;        // ghosts eaten on the current power pellet (200, 400, 800, 1600)
    GameState state;
    double state_timer;
    int queued_dir;
    bool chomp_toggle;
    double clock;         // seconds since start - drives the pellet pulse and fright flashing
    int dots_total;       // dots + pellets the maze starts with
    int dots_eaten;       // this level's, survives a death - drives the fruit triggers
    bool fruit_active;
    FruitKind fruit_kind;
    int fruit_row, fruit_col;
    double fruit_timer;   // seconds left on the maze, the last FRUIT_BLINK_SECS blinking
    double invincible_timer; // orange
    double hunt_timer;    // apple
    FruitKind eaten[FRUIT_SHOWN]; // newest last
    int eaten_count;
    ArcadeLeaderboard lb;   // data/leaderboard.dat + data/settings.dat (see engine/arcade_leaderboard.h)
    ArcadeManPage help;     // Fn+F1 - resources/manpages/ (see engine/arcade_manpage.h)
    WavClip music_beginning;    // title page
    WavClip music_intermission; // the apple's ghost hunt
} Game;

static const double PHASE_DURATIONS[] = { 7, 20, 7, 20, 5, 20, 5, INFINITY };
#define PHASE_COUNT ((int)(sizeof(PHASE_DURATIONS) / sizeof(PHASE_DURATIONS[0])))

static const int SCATTER_HOME[GHOST_COUNT][2] = { { 1, 17 }, { 1, 1 }, { 19, 17 }, { 19, 1 } };
static const ArcadeColor GHOST_COLOR[GHOST_COUNT] = {
    ARCADE_RGB(0xff, 0x3b, 0x3b), ARCADE_RGB(0xff, 0x8f, 0xd6),
    ARCADE_RGB(0x4d, 0xe3, 0xe0), ARCADE_RGB(0xff, 0xab, 0x4d)
};

// ------------------------------------------------------------------------------------------
// Maze helpers
// ------------------------------------------------------------------------------------------
static int wrap_col(int c) { return ((c % COLS) + COLS) % COLS; }

static char tile_at(int row, int col) {
    if (row < 0 || row >= ROWS) return '#';
    return MAZE[row][wrap_col(col)];
}

static bool can_move(int row, int col, int d) {
    if (d == DIR_NONE) return false;
    return tile_at(row + DY[d], col + DX[d]) != '#';
}

static double center_x(int col) { return col * CELL + CELL / 2.0; }
static double center_y(int row) { return row * CELL + CELL / 2.0; }

static bool is_opposite(int a, int b) { return DX[a] == -DX[b] && DY[a] == -DY[b]; }

static int opposite(int d) {
    switch (d) {
        case DIR_UP:    return DIR_DOWN;
        case DIR_DOWN:  return DIR_UP;
        case DIR_LEFT:  return DIR_RIGHT;
        case DIR_RIGHT: return DIR_LEFT;
        default:        return DIR_NONE;
    }
}

static double speed_for_level(int lv) { return 62 + (lv - 1 < 6 ? lv - 1 : 6) * 4; } // px/s, capped
static double fright_for_level(int lv) { double d = 8 - (lv - 1) * 0.7; return d < 3 ? 3 : d; }

// The original's level table: one level each of cherry and strawberry, two each of orange through
// bell, the key from level 13 on.
static FruitKind fruit_for_level(int lv) {
    if (lv <= 1)  return FRUIT_CHERRY;
    if (lv == 2)  return FRUIT_STRAWBERRY;
    if (lv >= 13) return FRUIT_KEY;
    return (FruitKind)(FRUIT_ORANGE + (lv - 3) / 2);
}

static void mover_place(Mover *m, int row, int col) {
    m->row = row; m->col = col;
    m->x = m->tx = center_x(col);
    m->y = m->ty = center_y(row);
    m->dir = DIR_NONE;
}

// ------------------------------------------------------------------------------------------
// Sound effects - the browser version's sfx*() recipes.
// ------------------------------------------------------------------------------------------
static void sfx_chomp(Game *g) {
    g->chomp_toggle = !g->chomp_toggle;
    arcade_sfx_beep(g->chomp_toggle ? 220 : 180, 0.06, ARCADE_SFX_SQUARE, 0.045, 0);
}
static void sfx_pellet(void) { arcade_sfx_beep(140, 0.22, ARCADE_SFX_SAWTOOTH, 0.05, 0); }
static void sfx_eat_ghost(void) {
    arcade_sfx_beep(500, 0.12, ARCADE_SFX_SQUARE, 0.07, 0);
    arcade_sfx_beep(760, 0.12, ARCADE_SFX_SQUARE, 0.05, 0);
}
static void sfx_death(void) {
    arcade_sfx_beep(300, 0.10, ARCADE_SFX_SAWTOOTH, 0.06, 0.00);
    arcade_sfx_beep(180, 0.15, ARCADE_SFX_SAWTOOTH, 0.06, 0.11);
    arcade_sfx_beep(90,  0.30, ARCADE_SFX_SAWTOOTH, 0.06, 0.26);
}
static void sfx_fruit(void) {
    arcade_sfx_slide(400, 1200, 0.18, ARCADE_SFX_SQUARE, 0.06, 0);
    arcade_sfx_beep(1200, 0.08, ARCADE_SFX_SQUARE, 0.04, 0.18);
}
static void sfx_win(void) {
    static const double notes[] = { 523, 659, 784, 1047 };
    for (int i = 0; i < 4; i++) arcade_sfx_beep(notes[i], 0.18, ARCADE_SFX_SQUARE, 0.06, i * 0.14);
}

// ------------------------------------------------------------------------------------------
// Setup
// ------------------------------------------------------------------------------------------
static void build_dots(Game *g) {
    g->dots_remaining = 0;
    g->dots_eaten = 0;
    for (int r = 0; r < ROWS; r++) {
        for (int c = 0; c < COLS; c++) {
            char ch = MAZE[r][c];
            g->dots[r][c] = ch == '.' ? ITEM_DOT : ch == 'o' ? ITEM_PELLET : ITEM_NONE;
            if (g->dots[r][c] != ITEM_NONE) g->dots_remaining++;
        }
    }
    g->dots_total = g->dots_remaining;
}

static void make_ghost(Game *g, GhostName name, int row, int col, double release_delay) {
    Ghost *gh = &g->ghosts[name];
    mover_place(&gh->m, row, col);
    gh->name = name;
    gh->speed = speed_for_level(g->level) * (name == BLINKY ? 0.98 : 0.92);
    gh->state = name == BLINKY ? G_NORMAL : G_HOUSE;
    gh->special = SP_NONE;
    gh->fright_timer = 0;
    gh->release_timer = release_delay;
    gh->bob = (double)rand() / RAND_MAX * 2 * M_PI;
}

static void reset_positions(Game *g) {
    mover_place(&g->pac.m, 16, 9);
    g->pac.speed = speed_for_level(g->level) * 1.05;
    g->pac.mouth = 0;
    make_ghost(g, BLINKY, 9, 9, 0);
    make_ghost(g, PINKY, 11, 9, 1.0);
    make_ghost(g, INKY, 11, 8, 5.0);
    make_ghost(g, CLYDE, 11, 10, 9.0);
    g->eat_chain = 0;
    g->scatter = true; g->phase_idx = 0; g->phase_elapsed = 0;
    g->particle_count = 0;
    g->queued_dir = DIR_NONE;
    g->fruit_active = false; // like the original, a death takes the fruit (and its effects) along
    g->invincible_timer = 0;
    g->hunt_timer = 0;
}

static void enter_ready(Game *g, bool full) {
    g->state = ST_READY;
    g->state_timer = full ? 1.6 : 1.3;
}

static void start_new_game(Game *g) {
    g->score = 0; g->lives = 3; g->level = 1;
    g->eaten_count = 0;
    build_dots(g);
    reset_positions(g);
    enter_ready(g, true);
}

static void start_next_level(Game *g) {
    g->level++;
    build_dots(g);
    reset_positions(g);
    enter_ready(g, true);
}

// ------------------------------------------------------------------------------------------
// Ghost brains
// ------------------------------------------------------------------------------------------
static int clamp_int(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

static void ghost_target(const Game *g, const Ghost *gh, int *trow, int *tcol) {
    if (gh->special == SP_EATEN) { *trow = 9; *tcol = 9; return; } // back to the house door
    if (g->scatter) { *trow = SCATTER_HOME[gh->name][0]; *tcol = SCATTER_HOME[gh->name][1]; return; }

    int prow = g->pac.m.row, pcol = g->pac.m.col;
    int pd = g->pac.m.dir == DIR_NONE ? DIR_RIGHT : g->pac.m.dir;
    switch (gh->name) {
        case PINKY:  // ambush four tiles ahead
            *trow = clamp_int(prow + DY[pd] * 4, 0, ROWS - 1);
            *tcol = clamp_int(pcol + DX[pd] * 4, 0, COLS - 1);
            return;
        case INKY: { // pincer: double the vector from Blinky to two tiles ahead of Maze Chomp
            int pivot_row = prow + DY[pd] * 2, pivot_col = pcol + DX[pd] * 2;
            const Ghost *blinky = &g->ghosts[BLINKY];
            *trow = clamp_int(2 * pivot_row - blinky->m.row, 0, ROWS - 1);
            *tcol = clamp_int(2 * pivot_col - blinky->m.col, 0, COLS - 1);
            return;
        }
        case CLYDE: { // chases from afar, retreats to his corner up close
            double dist = hypot(gh->m.row - prow, gh->m.col - pcol);
            if (dist > 8) { *trow = prow; *tcol = pcol; }
            else { *trow = SCATTER_HOME[CLYDE][0]; *tcol = SCATTER_HOME[CLYDE][1]; }
            return;
        }
        default:     // Blinky: straight at Maze Chomp
            *trow = prow; *tcol = pcol;
            return;
    }
}

static int ghost_choose_dir(const Game *g, const Ghost *gh, int row, int col) {
    int avail[4], n = 0;
    for (int i = 0; i < 4; i++) {
        int d = ALL_DIRS[i];
        if (can_move(row, col, d) && !is_opposite(d, gh->m.dir)) avail[n++] = d;
    }
    if (n == 0) {
        for (int i = 0; i < 4; i++) if (can_move(row, col, ALL_DIRS[i])) avail[n++] = ALL_DIRS[i];
    }
    if (n == 0) return DIR_NONE;
    if (gh->special == SP_FRIGHTENED) return avail[rand() % n];

    int trow, tcol;
    ghost_target(g, gh, &trow, &tcol);
    int best = avail[0], best_d = -1;
    for (int i = 0; i < n; i++) {
        int nr = row + DY[avail[i]], nc = col + DX[avail[i]];
        int dd = (nr - trow) * (nr - trow) + (nc - tcol) * (nc - tcol);
        if (best_d < 0 || dd < best_d) { best_d = dd; best = avail[i]; }
    }
    return best;
}

// ------------------------------------------------------------------------------------------
// Movement - entities move toward the next cell center; the decide step fires exactly once per
// cell crossing (the browser version's advance()).
// ------------------------------------------------------------------------------------------
typedef int (*DecideFn)(Game *g, void *who, int row, int col);
typedef void (*ArriveFn)(Game *g, int row, int col);

static void advance(Game *g, Mover *m, void *who, double dt, double speed, DecideFn decide, ArriveFn arrive) {
    if (m->dir == DIR_NONE) {
        int nd = decide(g, who, m->row, m->col);
        if (nd != DIR_NONE) {
            m->dir = nd;
            m->tx = center_x(m->col + DX[nd]);
            m->ty = center_y(m->row + DY[nd]);
        }
        return;
    }
    double move = speed * dt;
    for (int guard = 0; move > 1e-6 && guard < 8; guard++) {
        double ddx = m->tx - m->x, ddy = m->ty - m->y;
        double dist = hypot(ddx, ddy);
        if (dist <= move) {
            m->row += DY[m->dir];
            m->col = wrap_col(m->col + DX[m->dir]);
            m->x = center_x(m->col);
            m->y = center_y(m->row);
            move -= dist;
            if (arrive) arrive(g, m->row, m->col);
            int nd = decide(g, who, m->row, m->col);
            if (nd == DIR_NONE) { m->dir = DIR_NONE; break; }
            m->dir = nd;
            m->tx = center_x(m->col + DX[nd]);
            m->ty = center_y(m->row + DY[nd]);
        } else {
            m->x += ddx / dist * move;
            m->y += ddy / dist * move;
            move = 0;
        }
    }
}

static int pac_decide(Game *g, void *who, int row, int col) {
    (void)who;
    if (g->queued_dir != DIR_NONE && can_move(row, col, g->queued_dir)) return g->queued_dir;
    if (g->pac.m.dir != DIR_NONE && can_move(row, col, g->pac.m.dir)) return g->pac.m.dir;
    return DIR_NONE;
}

static int ghost_decide(Game *g, void *who, int row, int col) {
    return ghost_choose_dir(g, (Ghost *)who, row, col);
}

// A random empty corridor cell (no dot left, outside the ghost house, not a tunnel mouth) at least
// six cells from Maze Chomp. Falls back to any such cell if none is that far.
static bool pick_fruit_cell(const Game *g, int *out_row, int *out_col) {
    int cells[ROWS * COLS][2], n = 0, near_n = 0, near[ROWS * COLS][2];
    for (int r = 0; r < ROWS; r++) {
        for (int c = 1; c < COLS - 1; c++) {
            char ch = MAZE[r][c];
            if (ch == '#' || ch == '-' || g->dots[r][c] != ITEM_NONE) continue;
            if (r == 11 && c >= 8 && c <= 10) continue; // inside the house
            if (abs(r - g->pac.m.row) + abs(c - g->pac.m.col) >= 6) { cells[n][0] = r; cells[n][1] = c; n++; }
            else { near[near_n][0] = r; near[near_n][1] = c; near_n++; }
        }
    }
    if (n == 0 && near_n == 0) return false;
    int (*from)[2] = n > 0 ? cells : near;
    int i = rand() % (n > 0 ? n : near_n);
    *out_row = from[i][0];
    *out_col = from[i][1];
    return true;
}

static void spawn_fruit(Game *g) {
    if (!pick_fruit_cell(g, &g->fruit_row, &g->fruit_col)) return;
    g->fruit_active = true;
    g->fruit_kind = fruit_for_level(g->level);
    g->fruit_timer = FRUIT_SOLID_SECS + FRUIT_BLINK_SECS;
}

// Turns every ghost out on the maze blue (and around) - a power pellet, and the apple's hunt start.
static void frighten_ghosts(Game *g, double duration) {
    g->eat_chain = 0;
    for (int i = 0; i < GHOST_COUNT; i++) {
        Ghost *gh = &g->ghosts[i];
        if (gh->state == G_NORMAL && gh->special != SP_EATEN) {
            gh->special = SP_FRIGHTENED;
            gh->fright_timer = duration;
            if (gh->m.dir != DIR_NONE) { // turn around on the spot
                gh->m.dir = opposite(gh->m.dir);
                gh->m.tx = center_x(gh->m.col);
                gh->m.ty = center_y(gh->m.row);
            }
        }
    }
}

static void eat_fruit(Game *g) {
    int pts = FRUIT_POINTS[g->fruit_kind];
    g->fruit_active = false;
    g->score += pts;
    if (g->particle_count < MAX_PARTICLES) {
        g->particles[g->particle_count++] =
            (Particle){ center_x(g->fruit_col), center_y(g->fruit_row), -24, 0.9, pts };
    }
    if (g->eaten_count == FRUIT_SHOWN) {
        memmove(g->eaten, g->eaten + 1, (FRUIT_SHOWN - 1) * sizeof(g->eaten[0]));
        g->eaten_count--;
    }
    g->eaten[g->eaten_count++] = g->fruit_kind;
    sfx_fruit();

    if (g->fruit_kind == FRUIT_ORANGE) g->invincible_timer = FRUIT_INVINCIBLE_SECS;
    if (g->fruit_kind == FRUIT_APPLE) {
        g->hunt_timer = FRUIT_HUNT_SECS;
        frighten_ghosts(g, FRUIT_HUNT_SECS);
    }
}

static void eat_at(Game *g, int row, int col) {
    if (g->fruit_active && row == g->fruit_row && col == g->fruit_col) eat_fruit(g);

    Item item = g->dots[row][col];
    if (item == ITEM_NONE) return;
    g->dots[row][col] = ITEM_NONE;
    g->dots_remaining--;
    g->dots_eaten++;
    // The original's triggers were dots 70 and 170 of 244 - the same share of this maze's dots.
    if (g->dots_eaten == g->dots_total * 70 / 244 || g->dots_eaten == g->dots_total * 170 / 244) {
        spawn_fruit(g);
    }

    if (item == ITEM_DOT) {
        g->score += 10;
        sfx_chomp(g);
        return;
    }

    g->score += 50;
    sfx_pellet();
    frighten_ghosts(g, fright_for_level(g->level));
}

// ------------------------------------------------------------------------------------------
// Update
// ------------------------------------------------------------------------------------------
static void update_pac(Game *g, double dt) {
    advance(g, &g->pac.m, NULL, dt, g->pac.speed, pac_decide, eat_at);
    g->pac.mouth += dt * 10;
}

static void update_ghost(Game *g, Ghost *gh, double dt) {
    switch (gh->state) {
        case G_HOUSE:
            gh->bob += dt * 3;
            gh->release_timer -= dt;
            if (gh->release_timer <= 0) gh->state = G_EXITING;
            return;

        case G_EXITING: { // slide to the house's middle, then up through the door
            double target_x = center_x(9);
            if (fabs(gh->m.x - target_x) > 1.5) {
                gh->m.x += (target_x > gh->m.x ? 1 : -1) * gh->speed * dt;
                gh->m.y = center_y(11);
            } else {
                gh->m.x = target_x;
                gh->m.y -= gh->speed * dt;
                if (gh->m.y <= center_y(9)) {
                    mover_place(&gh->m, 9, 9);
                    gh->state = G_NORMAL;
                }
            }
            return;
        }

        case G_DESCENDING: // eaten ghost's eyes sink back into the house
            gh->m.x = center_x(9);
            gh->m.y += gh->speed * 1.6 * dt;
            if (gh->m.y >= center_y(11)) {
                mover_place(&gh->m, 11, 9);
                gh->state = G_HOUSE;
                gh->special = SP_NONE;
                gh->release_timer = 1.5;
            }
            return;

        case G_NORMAL:
            // The apple's hunt keeps every ghost out here blue - newcomers from the house too - and
            // never ends a pellet's fright early.
            if (g->hunt_timer > 0 && gh->special != SP_EATEN) {
                gh->special = SP_FRIGHTENED;
                if (gh->fright_timer < g->hunt_timer) gh->fright_timer = g->hunt_timer;
            }
            if (gh->special == SP_FRIGHTENED) {
                gh->fright_timer -= dt;
                if (gh->fright_timer <= 0) gh->special = SP_NONE;
            }
            double speed = gh->special == SP_FRIGHTENED ? gh->speed * 0.55
                         : gh->special == SP_EATEN      ? gh->speed * 1.8
                                                        : gh->speed;
            advance(g, &gh->m, gh, dt, speed, ghost_decide, NULL);
            if (gh->special == SP_EATEN && gh->m.row == 9 && gh->m.col == 9) gh->state = G_DESCENDING;
            return;
    }
}

static void lose_life(Game *g) {
    g->state = ST_DYING;
    g->state_timer = 1.1;
    sfx_death();
}

static void update_collisions(Game *g) {
    for (int i = 0; i < GHOST_COUNT; i++) {
        Ghost *gh = &g->ghosts[i];
        if (gh->state != G_NORMAL) continue;
        if (hypot(g->pac.m.x - gh->m.x, g->pac.m.y - gh->m.y) >= CELL * 0.55) continue;

        if (gh->special == SP_FRIGHTENED) {
            static const int values[] = { 200, 400, 800, 1600 };
            int pts = values[g->eat_chain < 3 ? g->eat_chain : 3];
            g->score += pts;
            g->eat_chain++;
            if (g->particle_count < MAX_PARTICLES) {
                g->particles[g->particle_count++] = (Particle){ gh->m.x, gh->m.y, -24, 0.7, pts };
            }
            gh->special = SP_EATEN;
            sfx_eat_ghost();
        } else if (gh->special != SP_EATEN && g->invincible_timer <= 0) { // orange: passes through
            lose_life(g);
            return;
        }
    }
}

static void update_fruit(Game *g, double dt) {
    if (g->fruit_active) {
        g->fruit_timer -= dt;
        if (g->fruit_timer <= 0) g->fruit_active = false;
    }
    if (g->invincible_timer > 0) g->invincible_timer -= dt;
    if (g->hunt_timer > 0) g->hunt_timer -= dt;
}

static void update_particles(Game *g, double dt) {
    int kept = 0;
    for (int i = 0; i < g->particle_count; i++) {
        Particle p = g->particles[i];
        p.life -= dt;
        p.y += p.vy * dt;
        if (p.life > 0) g->particles[kept++] = p;
    }
    g->particle_count = kept;
}

static void handle_input(Game *g) {
    if (arcade_key_down(ARCADE_KEY_UP)    || arcade_key_down(ARCADE_KEY_W)) g->queued_dir = DIR_UP;
    if (arcade_key_down(ARCADE_KEY_DOWN)  || arcade_key_down(ARCADE_KEY_S)) g->queued_dir = DIR_DOWN;
    if (arcade_key_down(ARCADE_KEY_LEFT)  || arcade_key_down(ARCADE_KEY_A)) g->queued_dir = DIR_LEFT;
    if (arcade_key_down(ARCADE_KEY_RIGHT) || arcade_key_down(ARCADE_KEY_D)) g->queued_dir = DIR_RIGHT;

    if (arcade_key_pressed(ARCADE_KEY_P)) {
        if (g->state == ST_PLAYING) g->state = ST_PAUSED;
        else if (g->state == ST_PAUSED) g->state = ST_PLAYING;
    }
    if (arcade_key_pressed(ARCADE_KEY_M)) arcade_sfx_set_muted(!arcade_sfx_is_muted());
    if (arcade_key_pressed(ARCADE_KEY_SPACE) &&
        (g->state == ST_TITLE || g->state == ST_GAMEOVER || g->state == ST_WIN)) {
        // With a saved name, the session's first game asks "continue with the name ___? Y/N"
        // first - update() then starts the game via arcade_leaderboard_start_ready().
        if (arcade_leaderboard_request_start(&g->lb)) start_new_game(g);
    }
    if (arcade_key_pressed(ARCADE_KEY_ESCAPE)) arcade_window_request_quit(g->window);
    if (arcade_key_pressed(ARCADE_KEY_F1) &&
        (g->state == ST_TITLE || g->state == ST_GAMEOVER || g->state == ST_PAUSED)) {
        arcade_manpage_show(&g->help);
    }

    if (g->state == ST_TITLE || g->state == ST_GAMEOVER) {
        if (arcade_key_pressed(ARCADE_KEY_D)) arcade_leaderboard_show(&g->lb);
        if (arcade_key_pressed(ARCADE_KEY_N)) arcade_leaderboard_edit_name(&g->lb);
    }
}

// The music the state wants: the title song on the title page and GAME OVER, the intermission while a ghost
// hunt runs (held, not dropped, while paused), otherwise none. Called every frame -
// arcade_sfx_music_play() leaves a track that's already playing alone.
static void update_music(Game *g) {
    bool hunting = g->hunt_timer > 0 && (g->state == ST_PLAYING || g->state == ST_PAUSED);
    if (g->state == ST_TITLE || g->state == ST_GAMEOVER) arcade_sfx_music_play(&g->music_beginning, true, MUSIC_VOL);
    else if (hunting) arcade_sfx_music_play(&g->music_intermission, true, MUSIC_VOL);
    else arcade_sfx_music_stop();
    arcade_sfx_music_set_paused(g->state == ST_PAUSED);
}

static void update(void *user_data, double dt) {
    Game *g = user_data;
    if (dt > 0.05) dt = 0.05;
    if (arcade_manpage_update(&g->help, dt)) return;   // help is open - it owns input/frame
    if (arcade_leaderboard_update(&g->lb, dt)) return; // an overlay is active - it owns input/frame
    if (arcade_leaderboard_start_ready(&g->lb)) start_new_game(g); // the Y/N question was answered
    g->clock += dt;

    handle_input(g);

    switch (g->state) {
        case ST_PLAYING:
            g->phase_elapsed += dt;
            if (g->phase_idx < PHASE_COUNT - 1 && g->phase_elapsed >= PHASE_DURATIONS[g->phase_idx]) {
                g->phase_idx++;
                g->phase_elapsed = 0;
                g->scatter = (g->phase_idx % 2) == 0;
            }
            update_fruit(g, dt);
            update_pac(g, dt);
            for (int i = 0; i < GHOST_COUNT; i++) update_ghost(g, &g->ghosts[i], dt);
            update_collisions(g);
            update_particles(g, dt);
            if (g->state == ST_PLAYING && g->dots_remaining <= 0) {
                g->state = ST_WIN;
                g->state_timer = 1.6;
                sfx_win();
            }
            break;
        case ST_DYING:
            g->state_timer -= dt;
            if (g->state_timer <= 0) {
                g->lives--;
                if (g->lives <= 0) {
                    g->state = ST_GAMEOVER;
                    arcade_leaderboard_offer(&g->lb, g->score);
                }
                else { reset_positions(g); enter_ready(g, false); }
            }
            break;
        case ST_READY:
            g->state_timer -= dt;
            if (g->state_timer <= 0) g->state = ST_PLAYING;
            break;
        case ST_WIN:
            g->state_timer -= dt;
            if (g->state_timer <= 0) start_next_level(g);
            break;
        default:
            break;
    }
    update_music(g);
}

// ------------------------------------------------------------------------------------------
// Drawing helpers - the engine draws opaque shapes; shapes with blending, wedges and skirts are
// drawn here pixel by pixel. The framebuffer packs each pixel as R | G<<8 | B<<16 | A<<24.
// ------------------------------------------------------------------------------------------
static void blend_pixel(ArcadeFramebuffer *fb, int x, int y, ArcadeColor c, double alpha) {
    if (x < 0 || y < 0 || x >= fb->width || y >= fb->height) return;
    uint32_t *p = &fb->pixels[y * fb->width + x];
    uint8_t r = (uint8_t)(*p & 0xFF), gr = (uint8_t)((*p >> 8) & 0xFF), b = (uint8_t)((*p >> 16) & 0xFF);
    r  = (uint8_t)(r  + (c.r - r)  * alpha);
    gr = (uint8_t)(gr + (c.g - gr) * alpha);
    b  = (uint8_t)(b  + (c.b - b)  * alpha);
    *p = (uint32_t)r | ((uint32_t)gr << 8) | ((uint32_t)b << 16) | 0xFF000000u;
}

static void dim_rect(ArcadeFramebuffer *fb, int x, int y, int w, int h, ArcadeColor c, double alpha) {
    for (int py = y; py < y + h; py++)
        for (int px = x; px < x + w; px++) blend_pixel(fb, px, py, c, alpha);
}

static void fill_round_rect(ArcadeFramebuffer *fb, int x, int y, int w, int h, int r, ArcadeColor c) {
    for (int py = 0; py < h; py++) {
        for (int px = 0; px < w; px++) {
            int cx = px < r ? r - px - 1 : px >= w - r ? px - (w - r) : -1;
            int cy = py < r ? r - py - 1 : py >= h - r ? py - (h - r) : -1;
            if (cx >= 0 && cy >= 0 && cx * cx + cy * cy > r * r) continue; // outside a corner arc
            arcade_set_pixel(fb, x + px, y + py, c);
        }
    }
}

// A disc with a wedge cut out, opening toward dir - Maze Chomp himself, and the HUD's life icons.
static void draw_chomper(ArcadeFramebuffer *fb, double cx, double cy, int r, int dir, double openness, ArcadeColor c) {
    double fx = DX[dir], fy = DY[dir];
    for (int dy = -r; dy <= r; dy++) {
        for (int dx = -r; dx <= r; dx++) {
            if (dx * dx + dy * dy > r * r) continue;
            double along = dx * fx + dy * fy, across = fabs(dx * fy - dy * fx);
            if ((dx || dy) && atan2(across, along) < openness * M_PI) continue; // inside the mouth
            arcade_set_pixel(fb, (int)lround(cx) + dx, (int)lround(cy) + dy, c);
        }
    }
}

static void draw_eyes(ArcadeFramebuffer *fb, int x, int y, int dir, double look) {
    int ox = (int)lround(DX[dir] * look), oy = (int)lround(DY[dir] * look);
    arcade_fill_circle(fb, x - 4, y - 4, 3, COL_EYE_WHITE);
    arcade_fill_circle(fb, x + 4, y - 4, 3, COL_EYE_WHITE);
    arcade_fill_circle(fb, x - 4 + ox, y - 4 + oy, 1, COL_EYE_PUPIL);
    arcade_fill_circle(fb, x + 4 + ox, y - 4 + oy, 1, COL_EYE_PUPIL);
}

// Dome on top, straight sides, a zigzag skirt along the bottom - the browser version's path.
static void draw_ghost_body(ArcadeFramebuffer *fb, int x, int y, int dir, ArcadeColor c) {
    const int r = CELL / 2 - 2;
    const int dome_y = y - 2, skirt_y = y + r - 2;
    // Skirt polyline from right to left: (x+r, skirt) then four alternating points, then (x-r, skirt).
    double px[6] = { x + r, x + r - 2, x + r - 6, x + r - 10, x + r - 14, x - r };
    double py[6] = { skirt_y, skirt_y + 4, skirt_y - 2, skirt_y + 4, skirt_y - 2, skirt_y };

    for (int col = x - r; col <= x + r; col++) {
        // Bottom edge of this column: interpolate along the skirt polyline.
        double bottom = skirt_y;
        for (int i = 0; i < 5; i++) {
            double x0 = px[i], x1 = px[i + 1];
            if (col <= x0 && col >= x1) {
                double t = x0 == x1 ? 0 : (x0 - col) / (x0 - x1);
                bottom = py[i] + (py[i + 1] - py[i]) * t;
                break;
            }
        }
        int dx = col - x;
        int top = dome_y - (int)floor(sqrt((double)(r * r - dx * dx)));
        for (int row = top; row <= (int)lround(bottom); row++) arcade_set_pixel(fb, col, row, c);
    }
    draw_eyes(fb, x, y, dir == DIR_NONE ? DIR_LEFT : dir, 2.2);
}

// Horizontal spans from half-width hw0 at row y0 to hw1 at row y1, centered on cx - the flared
// bodies of the strawberry, the bell and the galaxian's wings.
static void fill_taper(ArcadeFramebuffer *fb, int cx, int y0, double hw0, int y1, double hw1, ArcadeColor c) {
    for (int y = y0; y <= y1; y++) {
        double t = y1 == y0 ? 0 : (double)(y - y0) / (y1 - y0);
        int hw = (int)lround(hw0 + (hw1 - hw0) * t);
        arcade_fill_rect(fb, cx - hw, y, hw * 2 + 1, 1, c);
    }
}

static void draw_line(ArcadeFramebuffer *fb, int x0, int y0, int x1, int y1, ArcadeColor c) {
    int steps = abs(x1 - x0) > abs(y1 - y0) ? abs(x1 - x0) : abs(y1 - y0);
    for (int i = 0; i <= steps; i++) {
        double t = steps ? (double)i / steps : 0;
        arcade_set_pixel(fb, (int)lround(x0 + (x1 - x0) * t), (int)lround(y0 + (y1 - y0) * t), c);
    }
}

// One bonus fruit, about 2r across, centered on (cx, cy) - on the maze and in the status strip.
static void draw_fruit(ArcadeFramebuffer *fb, FruitKind kind, int cx, int cy, int r) {
    int h = r / 2 > 1 ? r / 2 : 1; // a half step, for leaves, stems and holes
    switch (kind) {
        case FRUIT_CHERRY:
            draw_line(fb, cx - h, cy + h, cx + h, cy - r, COL_STEM);
            draw_line(fb, cx + h + 1, cy + h + 1, cx + h, cy - r, COL_STEM);
            arcade_fill_circle(fb, cx - h, cy + h, h + 1, COL_RED);
            arcade_fill_circle(fb, cx + h + 1, cy + h + 1, h + 1, COL_RED);
            arcade_set_pixel(fb, cx - h - 1, cy + h - 1, COL_INK);
            break;
        case FRUIT_STRAWBERRY:
            arcade_fill_circle(fb, cx, cy - h + 1, r - h + 1, COL_RED);
            fill_taper(fb, cx, cy - h + 1, r - 1, cy + r, 0, COL_RED);
            for (int i = -1; i <= 1; i++) arcade_set_pixel(fb, cx + i * h, cy + (i ? 0 : h), COL_POINTS);
            fill_taper(fb, cx, cy - r, 0, cy - r + h, h + 1, COL_LEAF);
            break;
        case FRUIT_ORANGE:
            arcade_fill_circle(fb, cx, cy + 1, r - 1, COL_ORANGE);
            arcade_fill_circle(fb, cx + h, cy - r + 1, h - 1 > 0 ? h - 1 : 1, COL_LEAF);
            arcade_set_pixel(fb, cx, cy - r + 2, COL_STEM);
            arcade_set_pixel(fb, cx - h, cy - h + 1, COL_POINTS);
            break;
        case FRUIT_APPLE:
            arcade_fill_circle(fb, cx, cy + 1, r - 1, COL_RED);
            draw_line(fb, cx, cy - h + 1, cx + 1, cy - r, COL_STEM);
            arcade_fill_circle(fb, cx + h + 1, cy - r + 1, h - 1 > 0 ? h - 1 : 1, COL_LEAF);
            arcade_set_pixel(fb, cx - h, cy - h + 2, COL_INK);
            break;
        case FRUIT_MELON:
            arcade_fill_circle(fb, cx, cy + 1, r - 1, COL_MELON);
            for (int x = cx - r + 2; x < cx + r - 1; x += 3)
                for (int y = cy - r + 2; y <= cy + r; y++)
                    if ((x - cx) * (x - cx) + (y - cy - 1) * (y - cy - 1) < (r - 2) * (r - 2))
                        arcade_set_pixel(fb, x, y, COL_MELON_DARK);
            arcade_set_pixel(fb, cx, cy - r + 1, COL_STEM);
            break;
        case FRUIT_GALAXIAN:
            fill_taper(fb, cx, cy - h - 1, 1, cy + r - 1, r, COL_WING);     // wings
            arcade_fill_rect(fb, cx - 1, cy - r + 1, 3, r + h, COL_BELL);    // body
            arcade_fill_circle(fb, cx, cy - r + 2, 1, COL_RED);              // nose
            break;
        case FRUIT_BELL:
            arcade_fill_circle(fb, cx, cy - h, r - h, COL_BELL);
            fill_taper(fb, cx, cy - h, r - h, cy + h + 1, r, COL_BELL);
            arcade_fill_circle(fb, cx, cy + r - 1, 1, COL_INK);              // clapper
            arcade_set_pixel(fb, cx - h, cy - h, COL_INK);
            break;
        case FRUIT_KEY:
            arcade_fill_circle(fb, cx, cy - h, h + 1, COL_KEY);
            arcade_fill_circle(fb, cx, cy - h, h - 1 > 0 ? h - 1 : 0, COL_SCREEN); // the ring's hole
            arcade_fill_rect(fb, cx - 1, cy, 2, r, COL_KEY);                 // shaft
            arcade_fill_rect(fb, cx + 1, cy + r - 3, 2, 1, COL_KEY);         // teeth
            arcade_fill_rect(fb, cx + 1, cy + r - 1, 2, 1, COL_KEY);
            break;
        default:
            break;
    }
}

static void draw_text_centered(ArcadeFramebuffer *fb, const char *text, int cx, int y, ArcadeColor c, int scale) {
    arcade_draw_text(fb, text, cx - arcade_text_width(text, scale) / 2, y, c, scale);
}

// ------------------------------------------------------------------------------------------
// Render
// ------------------------------------------------------------------------------------------
static void draw_hud(const Game *g, ArcadeFramebuffer *fb) {
    char buf[32];
    arcade_draw_text(fb, "SCORE", 8, 6, COL_MUTED, 1);
    snprintf(buf, sizeof(buf), "%d", g->score);
    arcade_draw_text(fb, buf, 8, 17, COL_INK, 2);

    draw_text_centered(fb, config_get_string("App.Name"), FB_W / 2, 6, COL_PAC, 2);
    snprintf(buf, sizeof(buf), "LEVEL %d", g->level);
    draw_text_centered(fb, buf, FB_W / 2, 24, COL_MUTED, 1);

    arcade_draw_text(fb, "LIVES", FB_W - 8 - arcade_text_width("LIVES", 1), 6, COL_MUTED, 1);
    for (int i = 0; i < g->lives; i++) {
        draw_chomper(fb, FB_W - 14 - i * 16, 23, 6, DIR_RIGHT, 0.22, COL_PAC);
    }
}

static void draw_maze(const Game *g, ArcadeFramebuffer *fb) {
    arcade_fill_rect(fb, 0, MAZE_Y, MAZE_W, MAZE_H, COL_SCREEN);
    for (int r = 0; r < ROWS; r++) {
        for (int c = 0; c < COLS; c++) {
            if (MAZE[r][c] != '#') continue;
            int x = c * CELL, y = MAZE_Y + r * CELL;
            // A faint halo first, then the wall block - the browser version's shadowBlur glow.
            for (int py = y; py < y + CELL; py++)
                for (int px = x; px < x + CELL; px++) blend_pixel(fb, px, py, COL_WALL_GLOW, 0.12);
            fill_round_rect(fb, x + 2, y + 2, CELL - 4, CELL - 4, 4, COL_WALL);
        }
    }

    for (int r = 0; r < ROWS; r++) {
        for (int c = 0; c < COLS; c++) {
            int cx = (int)center_x(c), cy = MAZE_Y + (int)center_y(r);
            if (g->dots[r][c] == ITEM_DOT) {
                arcade_fill_circle(fb, cx, cy, 2, COL_DOT);
            } else if (g->dots[r][c] == ITEM_PELLET) {
                int pulse = (int)lround(5 + sin(g->clock * 6) * 1.3);
                arcade_fill_circle(fb, cx, cy, pulse + 2, ARCADE_RGB(0x3a, 0x37, 0x3c)); // soft halo
                arcade_fill_circle(fb, cx, cy, pulse, COL_DOT);
            }
        }
    }
}

static void draw_maze_fruit(const Game *g, ArcadeFramebuffer *fb) {
    if (!g->fruit_active) return;
    if (g->fruit_timer < FRUIT_BLINK_SECS && ((int)floor(g->clock * 6)) % 2) return; // about to go
    draw_fruit(fb, g->fruit_kind, (int)center_x(g->fruit_col), MAZE_Y + (int)center_y(g->fruit_row),
               CELL / 2 - 1);
}

// The strip under the maze: what's running and for how long on the left, this game's fruits on the
// right (newest rightmost), like the arcade's fruit row.
static void draw_status(const Game *g, ArcadeFramebuffer *fb) {
    char buf[32];
    int x = 8, icon_y = STATUS_Y + 9, text_y = STATUS_Y + 6;
    struct { double left; FruitKind icon; const char *label; } effects[] = {
        { g->invincible_timer, FRUIT_ORANGE, "INVINCIBLE" },
        { g->hunt_timer,       FRUIT_APPLE,  "GHOST HUNT" },
    };
    for (int i = 0; i < 2; i++) {
        if (effects[i].left <= 0) continue;
        draw_fruit(fb, effects[i].icon, x + 5, icon_y, 5);
        snprintf(buf, sizeof(buf), "%s %d", effects[i].label, (int)ceil(effects[i].left));
        bool ending = effects[i].left < 2 && ((int)floor(g->clock * 6)) % 2;
        arcade_draw_text(fb, buf, x + 13, text_y, ending ? COL_MUTED : COL_INK, 1);
        x += 13 + arcade_text_width(buf, 1) + 12;
    }
    for (int i = 0; i < g->eaten_count; i++) {
        draw_fruit(fb, g->eaten[i], FB_W - 10 - (g->eaten_count - 1 - i) * 14, icon_y, 5);
    }
}

static void draw_ghost(const Game *g, const Ghost *gh, ArcadeFramebuffer *fb) {
    if (gh->state == G_HOUSE && gh->release_timer > 2.5) return; // still deep in the house
    int x = (int)lround(gh->m.x);
    int y = MAZE_Y + (int)lround(gh->m.y + sin(gh->bob) * (gh->state == G_HOUSE ? 2 : 0));

    if (gh->special == SP_EATEN || gh->state == G_DESCENDING) { // just the eyes, heading home
        draw_eyes(fb, x, y, gh->m.dir == DIR_NONE ? DIR_LEFT : gh->m.dir, 1.6);
        return;
    }

    ArcadeColor color = GHOST_COLOR[gh->name];
    if (gh->special == SP_FRIGHTENED) {
        bool flashing = gh->fright_timer < 2;
        bool on = !flashing || ((int)floor(g->clock * 6)) % 2 == 0;
        color = on ? COL_FRIGHT : COL_FRIGHT_FLASH;
    }
    draw_ghost_body(fb, x, y, gh->m.dir, color);
}

static void draw_overlay(Game *g, ArcadeFramebuffer *fb) {
    if (g->state == ST_PLAYING) return;
    dim_rect(fb, 0, MAZE_Y, MAZE_W, MAZE_H, COL_VOID, g->state == ST_TITLE ? 0.7 : 0.55);

    int mid_x = MAZE_W / 2, mid_y = MAZE_Y + MAZE_H / 2;
    char buf[48];
    switch (g->state) {
        case ST_TITLE: // the browser version's marquee, tagline and footnote
            draw_text_centered(fb, config_get_string("App.Name"), mid_x, mid_y - 110, COL_PAC, 4);
            draw_text_centered(fb, config_get_string("App.Description"), mid_x, mid_y - 66, COL_MUTED, 1);
            draw_chomper(fb, mid_x - 60, mid_y - 22, 9, DIR_RIGHT, 0.22, COL_PAC);
            for (int i = 0; i < 3; i++) arcade_fill_circle(fb, mid_x - 36 + i * 14, mid_y - 22, 2, COL_DOT);
            draw_ghost_body(fb, mid_x + 40, mid_y - 22, DIR_LEFT, GHOST_COLOR[BLINKY]);
            draw_ghost_body(fb, mid_x + 62, mid_y - 22, DIR_LEFT, GHOST_COLOR[PINKY]);
            draw_text_centered(fb, "EAT EVERY DOT", mid_x, mid_y + 10, COL_INK, 1);
            draw_text_centered(fb, "POWER PELLETS TURN THE HUNTERS BLUE", mid_x, mid_y + 24, COL_INK, 1);
            draw_text_centered(fb, "CLEAR THE MAZE TO ADVANCE", mid_x, mid_y + 38, COL_INK, 1);
            draw_text_centered(fb, KEY_HINTS, mid_x, mid_y + 56, COL_MUTED, 1);
            if (((int)floor(g->clock * 2)) % 2 == 0) { // slow arcade-style blink
                draw_text_centered(fb, config_get_string("Text.PressSpaceStart"), mid_x, mid_y + 76, COL_PAC, 2);
            }
            {
                ArcadeLeaderboardEntry top[3];
                int count = arcade_leaderboard_top(&g->lb, top, 3);
                if (count > 0) {
                    draw_text_centered(fb, config_get_string("Text.Leaderboard"), mid_x, mid_y + 94, COL_MUTED, 1);
                    for (int i = 0; i < count; i++) {
                        snprintf(buf, sizeof(buf), "%d. %-5s %d", top[i].rank, top[i].name, top[i].points);
                        draw_text_centered(fb, buf, mid_x, mid_y + 106 + i * 10, COL_INK, 1);
                    }
                }
            }
            break;
        case ST_READY:
            draw_text_centered(fb, config_get_string("Text.Ready"), mid_x, mid_y - 7, COL_PAC, 2);
            break;
        case ST_PAUSED:
            draw_text_centered(fb, config_get_string("Text.Paused"), mid_x, mid_y - 7, COL_INK, 2);
            break;
        case ST_GAMEOVER:
            draw_text_centered(fb, config_get_string("Text.GameOver"), mid_x, mid_y - 20, COL_RED, 2);
            snprintf(buf, sizeof(buf), "SCORE %d", g->score);
            draw_text_centered(fb, buf, mid_x, mid_y + 4, COL_INK, 1);
            draw_text_centered(fb, config_get_string("Text.PressSpaceRetry"), mid_x, mid_y + 20, COL_MUTED, 1);
            draw_text_centered(fb, KEY_HINTS, mid_x, mid_y + 36, COL_MUTED, 1);
            break;
        case ST_WIN:
            draw_text_centered(fb, "MAZE CLEARED", mid_x, mid_y - 20, COL_CYAN, 2);
            snprintf(buf, sizeof(buf), "LEVEL %d COMPLETE", g->level);
            draw_text_centered(fb, buf, mid_x, mid_y + 4, COL_INK, 1);
            break;
        default:
            break;
    }
}

static void render(void *user_data, ArcadeFramebuffer *fb) {
    Game *g = user_data;
    arcade_clear(fb, COL_VOID);

    draw_hud(g, fb);
    draw_maze(g, fb);
    draw_maze_fruit(g, fb);
    for (int i = 0; i < GHOST_COUNT; i++) draw_ghost(g, &g->ghosts[i], fb);

    int dir = g->pac.m.dir == DIR_NONE ? DIR_RIGHT : g->pac.m.dir;
    double openness = fabs(sin(g->pac.mouth)) * 0.28 + 0.03;
    // Orange while the orange's invincibility lasts, flickering back to yellow in its last 2 s.
    bool glowing = g->invincible_timer > 0 &&
                   (g->invincible_timer >= 2 || ((int)floor(g->clock * 8)) % 2 == 0);
    draw_chomper(fb, g->pac.m.x, MAZE_Y + g->pac.m.y, CELL / 2 - 2, dir, openness,
                 glowing ? COL_ORANGE : COL_PAC);

    char buf[16];
    for (int i = 0; i < g->particle_count; i++) { // the font has no '+', so "200" rather than "+200"
        snprintf(buf, sizeof(buf), "%d", g->particles[i].points);
        draw_text_centered(fb, buf, (int)g->particles[i].x, MAZE_Y + (int)g->particles[i].y - 4, COL_POINTS, 1);
    }

    draw_overlay(g, fb);
    draw_status(g, fb);

#ifdef __APPLE__
    // Tighter spacing than the Windows build - the 75%-size maze (CELL 15 vs 20) leaves less
    // room, and the triple-spaced original overflows a 285px-wide window at 6px/char.
    draw_text_centered(fb, arcade_sfx_is_muted() ? "ARROWS OR WASD P PAUSE M SOUND: OFF ESC QUIT"
                                          : "ARROWS OR WASD P PAUSE M SOUND: ON ESC QUIT",
                       FB_W / 2, STATUS_Y + STATUS_H + 5, COL_MUTED, 1);
#else
    draw_text_centered(fb, arcade_sfx_is_muted() ? "ARROWS OR WASD   P PAUSE   M SOUND: OFF   ESC QUIT"
                                          : "ARROWS OR WASD   P PAUSE   M SOUND: ON   ESC QUIT",
                       FB_W / 2, STATUS_Y + STATUS_H + 5, COL_MUTED, 1);
#endif

    arcade_leaderboard_draw(&g->lb, fb, FB_W, FB_H);
    arcade_manpage_draw(&g->help, fb);
}

// ------------------------------------------------------------------------------------------
// Storage (shared/toolbox/STORAGE.md): resources/ in the bundle stay read-only; the leaderboard,
// settings and the user's own config.data live in this game's app-data folder. A factory default
// in resources/defaults/ is copied there on first run - never over the player's own file.
// ------------------------------------------------------------------------------------------
#define APP_ID "maze-chomp"

// <app data>/<name>, seeded from resources/defaults/<name> if that exists and the file doesn't.
static const char *app_data_file(char *out, size_t out_len, const char *name) {
    char default_src[256];
    snprintf(out, out_len, "%s/%s", platform_app_data_dir(APP_ID), name);
    snprintf(default_src, sizeof(default_src), "resources/defaults/%s", name);
    platform_seed_file(out, default_src);
    return out;
}

// The shipped config.data first, then the user's overrides in app data (if any) - config_get_*
// returns the newest value, so the second file wins key by key.
static void load_config(void) {
    char user_config[1024];
    config_load_file("resources/config/config.data");
    snprintf(user_config, sizeof(user_config), "%s/config.data", platform_app_data_dir(APP_ID));
    FILE *f = fopen(user_config, "r");
    if (f) {
        fclose(f);
        config_load_file(user_config);
    }
}

int main(int argc, char **argv) {
    // --version (-version, -v) prints the identity block and exits - before anything opens a
    // window/screen.
    if (version_requested(argc, argv)) return 0;
    platform_enter_bundle_dir(); // resources/... resolve however the game was started
    log_init(LOG_ALL);           // ~/Documents/Logs/<exe name>.log, cleared every launch
    log_info("%s v%02d.%02d started", APP_NAME, MAJOR, MINOR);
    debug_parse_args(argc, argv);
    srand((unsigned)time(NULL));
    load_config();
    char leaderboard_path[1024], settings_path[1024];
    app_data_file(leaderboard_path, sizeof(leaderboard_path), config_get_string("Path.Leaderboard"));
    app_data_file(settings_path, sizeof(settings_path), config_get_string("Path.Settings"));

    if (!arcade_sfx_init()) {
        debug_info_tag("audio", "no audio device - playing silently");
        log_warn("no audio device - playing silently");
    }

    static Game game;
    // A missing or unreadable clip just means no music there - wav_load() leaves it empty.
    if (wav_load(&game.music_beginning, config_get_string("Sound.Beginning")) != 0) {
        debug_info_tag("audio", "no title music - %s didn't load", config_get_string("Sound.Beginning"));
        log_warn("no title music - %s didn't load", config_get_string("Sound.Beginning"));
    }
    if (wav_load(&game.music_intermission, config_get_string("Sound.Intermission")) != 0) {
        debug_info_tag("audio", "no ghost-hunt music - %s didn't load", config_get_string("Sound.Intermission"));
        log_warn("no ghost-hunt music - %s didn't load", config_get_string("Sound.Intermission"));
    }
    arcade_leaderboard_init(&game.lb, leaderboard_path, settings_path, COL_INK, COL_MUTED, COL_PAC);
    arcade_manpage_init(&game.help, config_get_string("App.Name"), "resources/manpages", FB_W, FB_H,
                        COL_INK, COL_MUTED, COL_PAC, COL_CYAN);
    if (game.help.page_count == 0) log_warn("no help pages in resources/manpages");
    char window_title[96]; // "MAZE CHOMP v00.21"
    snprintf(window_title, sizeof(window_title), "%s v%02d.%02d", config_get_string("App.Name"), MAJOR, MINOR);
    game.window = arcade_window_create(window_title, FB_W, FB_H, PIXEL_SCALE);
    if (!game.window) return 1;

    start_new_game(&game); // set up the maze so the title page has something to show behind it
    game.state = ST_TITLE;
    arcade_window_run(game.window, update, render, &game);

    arcade_window_destroy(game.window);
    arcade_leaderboard_shutdown(&game.lb);
    arcade_sfx_shutdown(); // stops the music before its clips go
    wav_free(&game.music_beginning);
    wav_free(&game.music_intermission);
    arcade_manpage_shutdown(&game.help);
    log_info("%s exited", APP_NAME);
    return 0;
}

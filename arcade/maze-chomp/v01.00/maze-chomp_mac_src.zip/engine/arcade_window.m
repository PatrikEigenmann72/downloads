// -----------------------------------------------------------------------------------------------
// arcade_window.m - Implements arcade_window.h and arcade_input.h directly against Cocoa and
// CoreGraphics. No SDL, no raylib — this is the whole platform layer: open a window, drive a
// ~60Hz loop, track key state, and blit a raw pixel buffer to the screen every frame.
//
// The rest of the engine (arcade_gfx.c) and every game are plain C. This is the one file that
// has to know it's talking to macOS.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Fri 2026-08-21 File created.                                                     Version: 00.01
// Fri 2026-08-21 Added mouse position + button tracking (arcade_mouse_*()).         Version: 00.02
// Fri 2026-08-21 Added scrollWheel: handling and mouse-event debug tracing.         Version: 00.03
// Fri 2026-08-21 Replaced #ifdef DEBUG printfs with arcade_debug_*() — off by        Version: 00.04
//                default, turned on with --debug/ARCADE_DEBUG, no recompile needed.
// Tue 2026-08-25 arcade_debug.h retired in favor of the canonical                    Version: 00.05
//                shared/toolbox/logging/debug.h - arcade_debug_info()/_verbose()
//                calls became debug_info_tag()/debug_verbose_tag().
// Sat 2026-10-10 Maps P (keyCode 35) and M (keyCode 46) to                           Version: 00.06
//                ARCADE_KEY_P/ARCADE_KEY_M.
// Sat 2026-10-10 Maps Z (keyCode 6) to ARCADE_KEY_Z.                                 Version: 00.07
// Sat 2026-10-10 Fixed: arcade_key_pressed()/arcade_mouse_pressed()/released() were  Version: 00.08
//                never true - the timer snapshotted the previous-frame state after
//                the events were applied, so prev always equaled now. The snapshot
//                now runs at the end of each tick (arcade_input_end_frame()), and
//                fresh keyDowns (not auto-repeat) and clicks are latched so a tap
//                shorter than one frame still counts.
// Sun 2026-10-11 Maps Y (keyCode 16) to ARCADE_KEY_Y.                                Version: 00.09
// Mon 2026-10-12 Maps Tab (keyCode 48) and the main row's 1-9 to ARCADE_KEY_TAB/     Version: 00.10
//                ARCADE_KEY_1..9 (the manpage viewer).
// -----------------------------------------------------------------------------------------------
#import <Cocoa/Cocoa.h>
#include <mach/mach_time.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "arcade_window.h"
#include "arcade_input.h"
#include "logging/debug.h"

// ------------------------------------------------------------------------------------------
// Key state - written by ArcadeView's keyDown:/keyUp:, read by arcade_key_down/pressed.
// s_key_down_prev is the state as of the previous frame's update(), snapshotted at the END of
// each timer tick - so "pressed" means "down now, wasn't down last frame". (Snapshotting at the
// start of the tick, after the key events had already been applied, made prev == now and
// "pressed" never true.) s_key_tapped latches every fresh keyDown: between two ticks, so a key
// pressed and released inside one frame still counts as pressed once; auto-repeat doesn't.
// ------------------------------------------------------------------------------------------
static bool s_key_down[ARCADE_KEY_COUNT];
static bool s_key_down_prev[ARCADE_KEY_COUNT];
static bool s_key_tapped[ARCADE_KEY_COUNT];

// macOS virtual keycodes (hardware position, not layout-dependent). Values from
// <HIToolbox/Events.h> (kVK_*), hardcoded here so the engine doesn't need to link Carbon
// just for a handful of integer constants.
static int arcade_map_keycode(unsigned short keyCode) {
    switch (keyCode) {
        case 123: return ARCADE_KEY_LEFT;
        case 124: return ARCADE_KEY_RIGHT;
        case 125: return ARCADE_KEY_DOWN;
        case 126: return ARCADE_KEY_UP;
        case 49:  return ARCADE_KEY_SPACE;
        case 53:  return ARCADE_KEY_ESCAPE;
        case 36:  return ARCADE_KEY_ENTER;
        case 13:  return ARCADE_KEY_W;
        case 0:   return ARCADE_KEY_A;
        case 1:   return ARCADE_KEY_S;
        case 2:   return ARCADE_KEY_D;
        case 11:  return ARCADE_KEY_B;
        case 14:  return ARCADE_KEY_E;
        case 3:   return ARCADE_KEY_F;
        case 45:  return ARCADE_KEY_N;
        case 12:  return ARCADE_KEY_Q;
        case 122: return ARCADE_KEY_F1;
        case 35:  return ARCADE_KEY_P;
        case 46:  return ARCADE_KEY_M;
        case 6:   return ARCADE_KEY_Z;
        case 16:  return ARCADE_KEY_Y;
        case 48:  return ARCADE_KEY_TAB;
        case 18:  return ARCADE_KEY_1;
        case 19:  return ARCADE_KEY_2;
        case 20:  return ARCADE_KEY_3;
        case 21:  return ARCADE_KEY_4;
        case 23:  return ARCADE_KEY_5;
        case 22:  return ARCADE_KEY_6;
        case 26:  return ARCADE_KEY_7;
        case 28:  return ARCADE_KEY_8;
        case 25:  return ARCADE_KEY_9;
        default:  return -1;
    }
}

bool arcade_key_down(ArcadeKey key) {
    if (key < 0 || key >= ARCADE_KEY_COUNT) return false;
    return s_key_down[key];
}

bool arcade_key_pressed(ArcadeKey key) {
    if (key < 0 || key >= ARCADE_KEY_COUNT) return false;
    // The latch covers taps shorter than a frame; the edge covers modifiers, which flagsChanged:
    // sets directly rather than latching.
    return s_key_tapped[key] || (s_key_down[key] && !s_key_down_prev[key]);
}

// ------------------------------------------------------------------------------------------
// Mouse state - written by ArcadeView's mouse event handlers, read by arcade_mouse_*(). Same
// "snapshot previous frame's state at the end of each tick" pattern as the keyboard, with a
// latch for each direction so a click shorter than a frame still registers both edges.
// ------------------------------------------------------------------------------------------
static bool s_mouse_down[ARCADE_MOUSE_COUNT];
static bool s_mouse_down_prev[ARCADE_MOUSE_COUNT];
static bool s_mouse_tapped_down[ARCADE_MOUSE_COUNT];
static bool s_mouse_tapped_up[ARCADE_MOUSE_COUNT];
static int s_mouse_x = 0;
static int s_mouse_y = 0;

ArcadePoint arcade_mouse_position(void) {
    ArcadePoint p = { s_mouse_x, s_mouse_y };
    return p;
}

bool arcade_mouse_down(ArcadeMouseButton button) {
    if (button < 0 || button >= ARCADE_MOUSE_COUNT) return false;
    return s_mouse_down[button];
}

bool arcade_mouse_pressed(ArcadeMouseButton button) {
    if (button < 0 || button >= ARCADE_MOUSE_COUNT) return false;
    return s_mouse_tapped_down[button] || (s_mouse_down[button] && !s_mouse_down_prev[button]);
}

bool arcade_mouse_released(ArcadeMouseButton button) {
    if (button < 0 || button >= ARCADE_MOUSE_COUNT) return false;
    return s_mouse_tapped_up[button] || (!s_mouse_down[button] && s_mouse_down_prev[button]);
}

// End of a tick: this frame's state becomes "previous", and the latches are consumed.
static void arcade_input_end_frame(void) {
    memcpy(s_key_down_prev, s_key_down, sizeof(s_key_down));
    memcpy(s_mouse_down_prev, s_mouse_down, sizeof(s_mouse_down));
    memset(s_key_tapped, 0, sizeof(s_key_tapped));
    memset(s_mouse_tapped_down, 0, sizeof(s_mouse_tapped_down));
    memset(s_mouse_tapped_up, 0, sizeof(s_mouse_tapped_up));
}

// s_scroll_accum collects scrollWheel: events as they arrive between frames; s_scroll_frame is
// the snapshot arcade_mouse_scroll_delta() actually returns, taken once per tick (same pattern
// as the key/mouse-button previous-state snapshot).
static double s_scroll_accum = 0.0;
static double s_scroll_frame = 0.0;

double arcade_mouse_scroll_delta(void) {
    return s_scroll_frame;
}

static double arcade_mach_to_seconds(uint64_t elapsed) {
    static mach_timebase_info_data_t info;
    if (info.denom == 0) mach_timebase_info(&info);
    return (double)elapsed * (double)info.numer / (double)info.denom / 1e9;
}

// ------------------------------------------------------------------------------------------
// ArcadeView - draws the framebuffer and captures keyboard events.
// ------------------------------------------------------------------------------------------
@interface ArcadeView : NSView
@property (nonatomic) ArcadeFramebuffer fb;
@end

@implementation ArcadeView

- (BOOL)acceptsFirstResponder {
    return YES;
}

// Control/function keys (Esc, arrows, F-keys, ...) report their raw control character via
// charactersIgnoringModifiers, and printing that verbatim confuses the terminal (Esc in
// particular gets read as the start of an ANSI escape sequence). Only print real, printable
// characters; anything else prints as "(none)".
static const char *arcade_debug_safe_chars(NSEvent *event) {
    NSString *chars = [event charactersIgnoringModifiers];
    if (chars.length == 1 && isprint([chars characterAtIndex:0])) {
        return chars.UTF8String;
    }
    return "(none)";
}

- (void)keyDown:(NSEvent *)event {
    debug_info_tag("input,keyboard", "keyDown      keyCode=%3u  chars=%s", event.keyCode, arcade_debug_safe_chars(event));
    int key = arcade_map_keycode(event.keyCode);
    if (key >= 0) {
        s_key_down[key] = true;
        if (!event.isARepeat) s_key_tapped[key] = true; // held keys repeat - only the first counts
    }
}

- (void)keyUp:(NSEvent *)event {
    debug_info_tag("input,keyboard", "keyUp        keyCode=%3u", event.keyCode);
    int key = arcade_map_keycode(event.keyCode);
    if (key >= 0) s_key_down[key] = false;
}

// Shift/Control/Option/Command/Fn don't generate keyDown/keyUp at all — macOS reports them
// here instead, as a flagsChanged event. Unlike keyDown/keyUp this isn't a press/release
// signal for one key; modifierFlags is the complete, current set of modifiers, so state is
// set directly from the bitmask rather than toggled.
- (void)flagsChanged:(NSEvent *)event {
    debug_info_tag("input,keyboard", "flagsChanged keyCode=%3u  modifierFlags=0x%lx",
                       event.keyCode, (unsigned long)event.modifierFlags);
    NSEventModifierFlags flags = event.modifierFlags;
    s_key_down[ARCADE_KEY_SHIFT]   = (flags & NSEventModifierFlagShift) != 0;
    s_key_down[ARCADE_KEY_CONTROL] = (flags & NSEventModifierFlagControl) != 0;
    s_key_down[ARCADE_KEY_OPTION]  = (flags & NSEventModifierFlagOption) != 0;
    s_key_down[ARCADE_KEY_COMMAND] = (flags & NSEventModifierFlagCommand) != 0;
    s_key_down[ARCADE_KEY_FN]      = (flags & NSEventModifierFlagFunction) != 0;
}

// Converts an event's location to framebuffer pixel coordinates: the view is unflipped
// (origin bottom-left, y up) at pixel_scale-times the framebuffer's own size, while the
// framebuffer is top-down (row 0 = top, matching arcade_gfx's convention) — so this flips Y
// and divides out the scale in one step. Scale is derived from the view/framebuffer size
// ratio rather than stored separately, since the window is fixed-size (not resizable).
- (void)arcade_updateMousePosition:(NSEvent *)event {
    NSPoint viewPoint = [self convertPoint:event.locationInWindow fromView:nil];
    double scale = self.fb.width > 0 ? self.bounds.size.width / (double)self.fb.width : 1.0;
    if (scale <= 0) scale = 1.0;

    s_mouse_x = (int)(viewPoint.x / scale);
    s_mouse_y = (int)((self.bounds.size.height - viewPoint.y) / scale);
}

- (void)mouseMoved:(NSEvent *)event {
    [self arcade_updateMousePosition:event];
}

- (void)mouseDown:(NSEvent *)event {
    [self arcade_updateMousePosition:event];
    s_mouse_down[ARCADE_MOUSE_LEFT] = true;
    s_mouse_tapped_down[ARCADE_MOUSE_LEFT] = true;
    debug_info_tag("input,mouse", "mouseDown    fb=(%d,%d)", s_mouse_x, s_mouse_y);
}

- (void)mouseUp:(NSEvent *)event {
    [self arcade_updateMousePosition:event];
    s_mouse_down[ARCADE_MOUSE_LEFT] = false;
    s_mouse_tapped_up[ARCADE_MOUSE_LEFT] = true;
    debug_info_tag("input,mouse", "mouseUp      fb=(%d,%d)", s_mouse_x, s_mouse_y);
}

- (void)mouseDragged:(NSEvent *)event {
    [self arcade_updateMousePosition:event];
}

- (void)rightMouseDown:(NSEvent *)event {
    [self arcade_updateMousePosition:event];
    s_mouse_down[ARCADE_MOUSE_RIGHT] = true;
    s_mouse_tapped_down[ARCADE_MOUSE_RIGHT] = true;
}

- (void)rightMouseUp:(NSEvent *)event {
    [self arcade_updateMousePosition:event];
    s_mouse_down[ARCADE_MOUSE_RIGHT] = false;
    s_mouse_tapped_up[ARCADE_MOUSE_RIGHT] = true;
}

- (void)rightMouseDragged:(NSEvent *)event {
    [self arcade_updateMousePosition:event];
}

// Trackpad two-finger swipe / mouse scroll wheel. scrollingDeltaY is the modern API (accounts
// for trackpad momentum and the "natural scrolling" preference); legacy deltaY is for old
// physical wheel mice that don't report it.
- (void)scrollWheel:(NSEvent *)event {
    double delta = event.hasPreciseScrollingDeltas || event.scrollingDeltaY != 0
        ? event.scrollingDeltaY
        : event.deltaY;
    s_scroll_accum += delta;
    // VERBOSE, not INFO: this fires dozens of times per swipe gesture — exactly the kind of
    // per-event spam debug_* defaults to hiding. Set TOOLBOX_DEBUG=verbose to see it.
    debug_verbose_tag("input,mouse", "scrollWheel  scrollingDeltaY=%.2f  deltaY=%.2f", event.scrollingDeltaY, event.deltaY);
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    if (!self.fb.pixels) return;

    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGDataProviderRef provider = CGDataProviderCreateWithData(
        NULL, self.fb.pixels, (size_t)self.fb.width * (size_t)self.fb.height * 4, NULL);

    // Byte order R,G,B,A per pixel — matches arcade_pack() in arcade_gfx.c.
    CGBitmapInfo bitmapInfo = kCGBitmapByteOrder32Big | kCGImageAlphaPremultipliedLast;

    CGImageRef image = CGImageCreate(
        (size_t)self.fb.width, (size_t)self.fb.height,
        8, 32, (size_t)self.fb.width * 4,
        colorSpace, bitmapInfo,
        provider, NULL, false, kCGRenderingIntentDefault);

    CGContextRef ctx = [[NSGraphicsContext currentContext] CGContext];
    CGContextSetInterpolationQuality(ctx, kCGInterpolationNone);
    CGContextDrawImage(ctx, CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height), image);

    CGImageRelease(image);
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(colorSpace);
}

@end

// ------------------------------------------------------------------------------------------
// ArcadeWindow - the real struct behind the opaque handle in arcade_window.h.
// ------------------------------------------------------------------------------------------
struct ArcadeWindow {
    NSWindow *nswindow;
    ArcadeView *view;
    id appDelegate;
    NSTimer *timer;
    ArcadeFramebuffer fb;
    ArcadeUpdateFn update;
    ArcadeRenderFn render;
    void *user_data;
    bool quit;
};

@interface ArcadeAppDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate>
@property (nonatomic) ArcadeWindow *arcadeWindow;
@end

@implementation ArcadeAppDelegate

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender {
    (void)sender;
    return YES;
}

- (void)windowWillClose:(NSNotification *)notification {
    (void)notification;
    if (self.arcadeWindow) self.arcadeWindow->quit = true;
    [NSApp stop:nil];
    // [NSApp stop:] only takes effect once the run loop processes another event — post one
    // immediately so the window closes without waiting for the next keystroke.
    NSEvent *wake = [NSEvent otherEventWithType:NSEventTypeApplicationDefined
                                        location:NSZeroPoint
                                   modifierFlags:0
                                       timestamp:0
                                    windowNumber:0
                                         context:nil
                                         subtype:0
                                           data1:0
                                           data2:0];
    [NSApp postEvent:wake atStart:YES];
}

@end

ArcadeWindow *arcade_window_create(const char *title, int width, int height, int pixel_scale) {
    if (width <= 0 || height <= 0 || pixel_scale <= 0) return NULL;

    @autoreleasepool {
        [NSApplication sharedApplication];
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];

        ArcadeWindow *window = calloc(1, sizeof(ArcadeWindow));
        if (!window) return NULL;

        window->fb.width = width;
        window->fb.height = height;
        window->fb.pixels = calloc((size_t)width * (size_t)height, sizeof(uint32_t));

        NSRect frame = NSMakeRect(0, 0, width * pixel_scale, height * pixel_scale);
        NSUInteger style = NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable;
        NSWindow *nswindow = [[NSWindow alloc] initWithContentRect:frame
                                                          styleMask:style
                                                            backing:NSBackingStoreBuffered
                                                              defer:NO];
        [nswindow setTitle:[NSString stringWithUTF8String:title ? title : "arcade"]];
        [nswindow center];
        [nswindow setAcceptsMouseMovedEvents:YES];

        ArcadeView *view = [[ArcadeView alloc] initWithFrame:frame];
        view.fb = window->fb;
        [nswindow setContentView:view];
        [nswindow makeFirstResponder:view];

        ArcadeAppDelegate *delegate = [[ArcadeAppDelegate alloc] init];
        delegate.arcadeWindow = window;
        [nswindow setDelegate:delegate];
        [NSApp setDelegate:delegate];

        window->nswindow = nswindow;
        window->view = view;
        window->appDelegate = delegate;

        [nswindow makeKeyAndOrderFront:nil];
        [NSApp activateIgnoringOtherApps:YES];

        return window;
    }
}

void arcade_window_run(ArcadeWindow *window, ArcadeUpdateFn update, ArcadeRenderFn render, void *user_data) {
    if (!window) return;

    window->update = update;
    window->render = render;
    window->user_data = user_data;
    window->quit = false;

    __block uint64_t last = mach_absolute_time();
    __block ArcadeWindow *w = window;

    window->timer = [NSTimer scheduledTimerWithTimeInterval:1.0 / 60.0
                                                      repeats:YES
                                                        block:^(NSTimer *timer) {
        if (w->quit) {
            [timer invalidate];
            [NSApp stop:nil];
            return;
        }

        uint64_t now = mach_absolute_time();
        double dt = arcade_mach_to_seconds(now - last);
        last = now;
        if (dt > 0.25) dt = 0.25; // clamp after a stall (e.g. a breakpoint) so games don't jump

        s_scroll_frame = s_scroll_accum;
        s_scroll_accum = 0.0;

        if (w->update) w->update(w->user_data, dt);
        if (w->render) w->render(w->user_data, &w->fb);
        arcade_input_end_frame(); // after update(), so it saw this frame's edges

        [w->view setNeedsDisplay:YES];
    }];

    [[NSRunLoop currentRunLoop] addTimer:window->timer forMode:NSRunLoopCommonModes];

    [NSApp run];
}

void arcade_window_request_quit(ArcadeWindow *window) {
    if (window) window->quit = true;
}

void arcade_window_destroy(ArcadeWindow *window) {
    if (!window) return;
    if (window->timer) [window->timer invalidate];
    free(window->fb.pixels);
    free(window);
}

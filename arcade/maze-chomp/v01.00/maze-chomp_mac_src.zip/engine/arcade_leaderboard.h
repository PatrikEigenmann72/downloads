// -----------------------------------------------------------------------------------------------
// arcade_leaderboard.h - The leaderboard every arcade game shares - the standard for all of them.
//
// This module owns the leaderboard's rules; storing them is toolbox/db/persistence's job (the
// flat-file database - opening, reading, saving the stream). The rules:
//   - leaderboard.dat holds exactly four fields per entry: RANK, NAME, POINTS, TIMESTAMP;
//   - at most ARCADE_LEADERBOARD_MAX (100) entries, ranked by points - a finished run only gets
//     on the board if there's room or it beats the last entry; equal points rank the earlier
//     entry higher, like the cabinets did;
//   - a player name is 1 to ARCADE_LEADERBOARD_NAME_MAX (5) characters: A-Z, 0-9 and blank -
//     blanks at either end are trimmed, and at least one character must be a letter or digit;
//   - settings.dat holds the active player name (player_name), set once and reused for every run.
// The files are named .dat the way 80s games did - a file a player doesn't recognize is a file a
// player leaves alone - and a downloadable game ships no database.
//
// The overlays draw and handle their own input: the full leaderboard, scrollable
// ARCADE_LEADERBOARD_PAGE rows at a time ('D' from a game's own title screen), name entry ('N' to
// set/change anytime, or automatic when a run makes the board and no name is set yet), and the
// "continue with the name ___?" YES/NO chooser before a session's first game.
//
// Each game owns exactly one ArcadeLeaderboard instance and three integration points:
//   1. arcade_leaderboard_init() in main(), arcade_leaderboard_shutdown() on exit.
//   2. arcade_leaderboard_update() first thing in the game's own update() - if it returns true, an
//      overlay is active and has consumed this frame's input; the game should return immediately
//      rather than also processing its own input. Right after it, arcade_leaderboard_start_ready().
//   3. arcade_leaderboard_draw() last thing in the game's own render(), so the overlay (if active)
//      draws on top of everything else.
// Plus the calls at the moments that matter: arcade_leaderboard_request_start() when the player asks
// to start a game, arcade_leaderboard_offer() when a run ends, and arcade_leaderboard_show()/
// edit_name() wired to 'D'/'N' from the game's own title-screen input handling (state-gating stays
// the game's job, since only the game knows its own state enum).
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-10-11 File created - outsourced from maze-chomp/sky-raider's own nearly  Version: 00.01
//                identical, separately-hand-written high_scores_open()/close()/
//                top()/insert() into one shared engine module, plus the new
//                persistent-name and overlay UI neither game had yet.
// Sun 2026-10-11 Replaced the top-10-qualifies gate with a simple rolling-history   Version: 00.02
//                model: every run is recorded (ARCADE_HIGHSCORE_RETAIN = 100,
//                oldest pruned beyond that) rather than only ones that beat the
//                current cutoff. The board overlay now scrolls
//                ARCADE_HIGHSCORE_PAGE (10) rows at a time through however many
//                of those 100 exist, still ranked by score.
// Sun 2026-10-11 Direct report: there was no way to lock a letter in - LEFT/RIGHT  Version: 00.03
//                moved freely between slots and ENTER submitted all 3 letters at
//                once regardless of slot, with no per-letter confirm. ENTER now
//                advances to the next slot (locking the current letter) and only
//                submits on the 3rd slot's confirm, the classic arcade pattern.
//                Also fixed the board/entry overlays' own hint text overflowing
//                their panel width (same class of bug as maze-chomp's footer
//                clipping earlier - text sized for a wider panel than it got).
// Sun 2026-10-11 Direct report: highscores_prune() used a real DELETE - caught     Version: 00.04
//                only after it (and a separate manual mistake) destroyed two
//                real rows in maze-chomp's live db. Pruning is now a soft delete
//                (is_deleted=1, both high_scores.sql and settings.sql gained the
//                column) matching legacy/cobs's own data-integrity discipline -
//                automated code never issues a real DELETE; a genuine purge
//                stays a manual, deliberate SQL-shell operation. arcade_
//                highscores_top()'s query now filters WHERE is_deleted = 0.
// Sun 2026-10-11 Direct report: the overlay used fixed pixel sizes, so it looked   Version: 00.05
//                tiny on sky-raider's much bigger canvas (630x720) despite being
//                correctly sized for maze-chomp's (~304x388). Both overlays now
//                scale off a single ui_scale(fb_h) factor (2x at fb_h >= 500,
//                1x otherwise) instead of hardcoded constants - maze-chomp is
//                untouched (still scale 1, byte-identical layout), sky-raider's
//                panel/text/spacing all roughly double.
// Sun 2026-10-11 New "continue with the name ___? Y/N" question before the first   Version: 00.06
//                game of a session, when a player name is already saved (new mode
//                ARCADE_HS_CONFIRM_NAME): arcade_highscores_request_start() asks,
//                arcade_highscores_start_ready() tells the game when to start. Y
//                (either Y key position, so it works on QWERTY and QWERTZ alike),
//                Enter or Space continue; N opens name entry, whose confirm then
//                starts the game; Esc goes back. Asked once per launch - saving a
//                name through any path counts as confirmed.
// Sun 2026-10-11 Renamed from arcade_highscores.h - "leaderboard" is the standard   Version: 00.07
//                for every arcade game (ArcadeLeaderboard, arcade_leaderboard_*,
//                ARCADE_LEADERBOARD_*, ARCADE_LB_*; show_board() is now show()).
//                Storage moved from SQLite to two flat files through the new
//                toolbox/db/persistence (the mechanism); this module keeps the
//                rules: entries are RANK/NAME/POINTS/TIMESTAMP, at most 100,
//                ranked by points (a real leaderboard again, not a rolling
//                history), names 1-5 characters A-Z/0-9/blank (was 3 letters),
//                settings.dat holds the active name. offer() takes points only -
//                the level/wave isn't part of an entry anymore. The Y/N question
//                is a chooser: YES/NO
//                side by side, the active one framed, LEFT/RIGHT switch,
//                SPACE/ENTER lock it in (no letter keys - N means "new name").
// Mon 2026-10-12 The board scrolls itself, arcade attract-mode style: holds        Version: 00.08
//                ARCADE_LB_HOLD_SECS at the top, glides down ARCADE_LB_SCROLL_RATE
//                rows a second to the last page, holds there, starts over from
//                the top. UP/DOWN still step a row by hand and hold the auto-
//                scroll for ARCADE_LB_MANUAL_SECS. board_scroll is a double now
//                (fractional rows, clipped to the list). The "^"/"v" markers are
//                gone - the font has no '^' (it never showed), and the "v" read
//                as a letter V; the "1-10 OF 37" line already says there's more.
// -----------------------------------------------------------------------------------------------
#ifndef ARCADE_LEADERBOARD_H
#define ARCADE_LEADERBOARD_H

#include "arcade.h"
#include "db/persistence.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ARCADE_LEADERBOARD_MAX      100 // entries on the board - a run below #100 doesn't make it
#define ARCADE_LEADERBOARD_PAGE     10  // rows visible at once in the leaderboard overlay
#define ARCADE_LB_HOLD_SECS        2.5  // auto-scroll pause at the top and at the last page
#define ARCADE_LB_SCROLL_RATE      2.0  // auto-scroll speed, rows per second
#define ARCADE_LB_MANUAL_SECS      5.0  // after UP/DOWN, the auto-scroll waits this long
#define ARCADE_LEADERBOARD_NAME_MAX 5   // characters in a player name (1 to 5: A-Z, 0-9, blank)

// One leaderboard entry - exactly what leaderboard.dat stores.
typedef struct {
    int rank;                                 // 1 = best
    char name[ARCADE_LEADERBOARD_NAME_MAX + 1];
    int points;
    char timestamp[24];                       // ISO 8601 UTC, "2026-10-11T18:38:43Z"
} ArcadeLeaderboardEntry;

typedef enum {
    ARCADE_LB_INACTIVE,    // no overlay - game's own update()/render() run as normal
    ARCADE_LB_BOARD,       // full scrollable leaderboard showing
    ARCADE_LB_ENTER_NAME,  // name entry showing
    ARCADE_LB_CONFIRM_NAME // "continue with the name ___?" YES/NO chooser before the session's first game
} ArcadeLeaderboardMode;

typedef struct {
    Persistence board_file;     // leaderboard.dat
    Persistence settings_file;  // settings.dat
    ArcadeLeaderboardEntry entries[ARCADE_LEADERBOARD_MAX]; // ranked, entries[0] = rank 1
    int entry_count;
    char player_name[ARCADE_LEADERBOARD_NAME_MAX + 1];      // "" if never set

    ArcadeLeaderboardMode mode;
    char entry_letters[ARCADE_LEADERBOARD_NAME_MAX];        // name entry: 'A'-'Z', '0'-'9' or ' ' (blank)
    int entry_slot;           // which letter is currently selected
    bool pending_insert;      // confirming the name should also record pending_points
    int pending_points;
    double board_scroll;      // row offset into the board (fractional while gliding), ARCADE_LB_BOARD only
    double board_hold;        // seconds before the auto-scroll moves (again)
    bool choice_no;           // ARCADE_LB_CONFIRM_NAME: false = YES is framed, true = NO
    bool name_confirmed;      // the player confirmed (or just chose) the name this session
    bool entry_for_start;     // name entry was opened from the chooser - its confirm starts a game
    bool start_ready;         // poll-and-clear via arcade_leaderboard_start_ready()

    ArcadeColor col_text, col_muted, col_accent, col_panel, col_panel_line;
} ArcadeLeaderboard;

// Opens leaderboard.dat and settings.dat (both optional - a missing file is an empty board / no
// name yet; persistence creates them, and their folder, on the first save). Entries that break the
// rules (bad name, more than 100) are dropped on the next save.
//
// @param leaderboard_path  e.g. "data/leaderboard.dat"
// @param settings_path     e.g. "data/settings.dat"
// @param text/muted/accent Colors the overlays draw with, so they read as part of this game's
//                          own palette rather than a generic bolt-on.
void arcade_leaderboard_init(ArcadeLeaderboard *lb, const char *leaderboard_path, const char *settings_path,
                             ArcadeColor text, ArcadeColor muted, ArcadeColor accent);

void arcade_leaderboard_shutdown(ArcadeLeaderboard *lb);

// Call first thing in the game's own update(), every frame.
//
// @return true if an overlay is active and just consumed this frame's input - the game should
//         return immediately rather than also running its own input handling/game logic.
bool arcade_leaderboard_update(ArcadeLeaderboard *lb, double dt);

// Call last in the game's own render(), every frame - safe to call unconditionally, draws
// nothing when no overlay is active.
void arcade_leaderboard_draw(ArcadeLeaderboard *lb, ArcadeFramebuffer *fb, int fb_w, int fb_h);

// Call when a run ends. If the points don't make the board (it's full and they don't beat the last
// entry), nothing happens. Otherwise: with a player name set, the entry is recorded immediately;
// without one, name entry opens first - confirming saves the name (reused from then on) and
// records the entry; cancelling (ESC) discards it without saving a name.
void arcade_leaderboard_offer(ArcadeLeaderboard *lb, int points);

// Opens the full leaderboard overlay - wire to 'D' from the game's own title-screen input.
void arcade_leaderboard_show(ArcadeLeaderboard *lb);

// Opens name entry directly, to set or change the stored name anytime (nothing recorded) - wire to
// 'N' from the game's own title-screen input.
void arcade_leaderboard_edit_name(ArcadeLeaderboard *lb);

// Call when the player asks to start a game (SPACE on the title or game-over screen). If a name is
// saved and hasn't been confirmed yet this session, opens the "continue with the name ___?" YES/NO
// chooser and returns false - the game then starts once arcade_leaderboard_start_ready() says so.
// Otherwise (no name saved, or already confirmed) returns true: start right away.
bool arcade_leaderboard_request_start(ArcadeLeaderboard *lb);

// Poll-and-clear, every frame right after arcade_leaderboard_update(): true exactly once after the
// player locked in YES, or NO and then confirmed a new name - start the game. ESC at either step
// returns to the game's own screen without starting.
bool arcade_leaderboard_start_ready(ArcadeLeaderboard *lb);

// For a game's own brief "peek" (e.g. the top 3 beneath PRESS SPACE TO START) - copies the best
// entries into out, rank order, up to max.
//
// @return How many were copied - 0 if the board is empty.
int arcade_leaderboard_top(ArcadeLeaderboard *lb, ArcadeLeaderboardEntry *out, int max);

#ifdef __cplusplus
}
#endif

#endif // ARCADE_LEADERBOARD_H

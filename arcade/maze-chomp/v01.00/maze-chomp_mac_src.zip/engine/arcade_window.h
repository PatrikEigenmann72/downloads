// -----------------------------------------------------------------------------------------------
// arcade_window.h - Owns the window, the main loop, and the framebuffer that every game draws
// into. No third-party libraries here — the macOS backend talks directly to Cocoa and
// CoreGraphics. A game only ever sees a width x height array of pixels and two callbacks.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Fri 2026-08-21 File created.                                                     Version: 00.01
// -----------------------------------------------------------------------------------------------
#ifndef ARCADE_WINDOW_H
#define ARCADE_WINDOW_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// Opaque handle to a running arcade window. The real definition (Cocoa objects and all)
// lives in engine/arcade_window.m — nothing outside that file needs to know what's in it.
typedef struct ArcadeWindow ArcadeWindow;

// The pixels a game draws into, one uint32_t per pixel packed as R,G,B,A (see arcade_gfx.h
// for the packing helper). The window backend uploads this buffer to the screen every frame.
typedef struct {
    uint32_t *pixels;
    int width;
    int height;
} ArcadeFramebuffer;

// Called once per frame before rendering. dt is the seconds elapsed since the previous frame.
typedef void (*ArcadeUpdateFn)(void *user_data, double dt);

// Called once per frame after update, with the framebuffer to draw into.
typedef void (*ArcadeRenderFn)(void *user_data, ArcadeFramebuffer *fb);

// Creates a window sized (width * pixel_scale) x (height * pixel_scale) on screen, backed by
// a width x height framebuffer. pixel_scale lets you work in small, chunky arcade coordinates
// (e.g. 224x288 for a Pac-Man-sized playfield) while still getting a window you can see.
ArcadeWindow *arcade_window_create(const char *title, int width, int height, int pixel_scale);

// Runs the main loop at a fixed ~60Hz until the window is closed or arcade_window_request_quit()
// is called. Blocks until the game ends.
void arcade_window_run(ArcadeWindow *window, ArcadeUpdateFn update, ArcadeRenderFn render, void *user_data);

// Signals the main loop to stop after the current frame.
void arcade_window_request_quit(ArcadeWindow *window);

// Releases the framebuffer and the window itself. Call after arcade_window_run() returns.
void arcade_window_destroy(ArcadeWindow *window);

#ifdef __cplusplus
}
#endif

#endif // ARCADE_WINDOW_H

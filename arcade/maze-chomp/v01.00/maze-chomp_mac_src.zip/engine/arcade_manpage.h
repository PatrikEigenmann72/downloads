// -----------------------------------------------------------------------------------------------
// arcade_manpage.h - The in-game help viewer: renders resources/manpages/*.man files as an overlay
// on the game's own canvas. The same small markup as legacy/engine/legacy_dlg_manpage.h, so a
// .man file reads the same in every app of this family:
//
//     {title:"..."}              a full-width title bar
//     {link:"label","file.man"}  "[label]" - Tab highlights it, Enter goes to that page
//     {navigation}               "[...] [01] [02] [...]" - one segment per page found, the
//                                current one in the accent color
//     {image:"file.png"}         a picture from resources/pictures/ (PNG, JPEG or BMP), scaled
//                                to the text width - the python viewer's directive; the legacy
//                                ncurses one has nowhere to draw it
//     {u} ... {/u}               lines in between keep their own line breaks (not reflowed),
//                                each on its own line - also the python viewer's
//     plain lines                joined into paragraphs, reflowed to the panel's width; a blank
//                                line ends a paragraph
//
// Pages are every *.man in the folder, sorted by filename ("01_maze-chomp.man", "02_...", ...),
// and help always opens on the first one. The built-in font is uppercase only, so the text shows
// in capitals however the .man file is written.
//
// Like arcade_leaderboard, it's modal: while it's showing, arcade_manpage_update() returns true
// and the game skips its own input and logic for that frame.
//
// Keys while showing: LEFT/RIGHT turn the page, UP/DOWN scroll a long one (held keys repeat), TAB
// cycles the page's links, ENTER follows the highlighted one, 1-9 jump to that page, ESC or F1
// closes - Fn+F1 on the keyboard, since the bare F keys belong to the OS (brightness, volume).
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-10-12 File created - the arcade engine's port of legacy_dlg_manpage     Version: 00.01
//                (same directives, same page discovery and {navigation}
//                windowing with fixed-position ellipses), drawn on the
//                framebuffer with the 5x7 font instead of ncurses.
// Mon 2026-10-12 Comment only: F1 is Fn+F1 on a Mac (F1 alone is the OS's        Version: 00.02
//                brightness key) - the key code the viewer reads is the same.
// Mon 2026-10-12 Comment only: Fn+F1 on Windows too, not just on a Mac.          Version: 00.03
// Mon 2026-10-12 {image:"file.png"} and {u}...{/u} - the rest of the family's       Version: 00.04
//                markup, from python/toolbox/help/manpage_viewer.py. Pictures
//                load from the manpage folder's sibling pictures/ through the
//                toolbox's pictures module (stb_image), are scaled once to the
//                text width when their page loads, take as many rows as they
//                are tall, and scroll with the text. New
//                arcade_manpage_shutdown() frees the current page's pictures.
// -----------------------------------------------------------------------------------------------
#ifndef ARCADE_MANPAGE_H
#define ARCADE_MANPAGE_H

#include "arcade.h"
#include "pictures/pictures.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ARCADE_MANPAGE_MAX_PAGES    32
#define ARCADE_MANPAGE_MAX_PATH     128
#define ARCADE_MANPAGE_MAX_LINES    256
#define ARCADE_MANPAGE_MAX_LINE_LEN 96
#define ARCADE_MANPAGE_MAX_LINKS    16
#define ARCADE_MANPAGE_MAX_IMAGES   8   // pictures on one page

typedef enum {
    ARCADE_MANPAGE_LINE_TEXT,  // reflowed paragraph text
    ARCADE_MANPAGE_LINE_TITLE, // {title:} - drawn as a solid bar
    ARCADE_MANPAGE_LINE_LINK,  // {link:} - text is "[label]", see link_index
    ARCADE_MANPAGE_LINE_NAV,   // {navigation} - regenerated from page_count/active_page when drawn
    ARCADE_MANPAGE_LINE_IMAGE, // {image:} - one of the rows a picture covers, see image_row
    ARCADE_MANPAGE_LINE_BLANK  // a paragraph break
} ArcadeManPageLineType;

typedef struct {
    ArcadeManPageLineType type;
    char text[ARCADE_MANPAGE_MAX_LINE_LEN];
    int link_index; // LINE_LINK: index into links[]; LINE_IMAGE: index into images[]
    int image_row;  // LINE_IMAGE: which of the picture's rows this is (0 = its top)
} ArcadeManPageLine;

typedef struct {
    char label[64];
    char file[ARCADE_MANPAGE_MAX_PATH]; // a filename in dir, e.g. "02_fruit.man"
} ArcadeManPageLink;

typedef struct {
    bool active;
    char title[64];                     // "<app name> HELP", the panel's header
    char dir[ARCADE_MANPAGE_MAX_PATH];
    char pages[ARCADE_MANPAGE_MAX_PAGES][ARCADE_MANPAGE_MAX_PATH]; // sorted filenames
    int page_count;
    int active_page;

    ArcadeManPageLine lines[ARCADE_MANPAGE_MAX_LINES]; // active_page, parsed and wrapped
    int line_count;
    Picture images[ARCADE_MANPAGE_MAX_IMAGES]; // active_page's pictures, already scaled to fit
    int image_count;
    char pictures_dir[ARCADE_MANPAGE_MAX_PATH]; // dir's sibling pictures/
    ArcadeManPageLink links[ARCADE_MANPAGE_MAX_LINKS];
    int link_count;
    int highlighted_link;               // -1 without links
    int scroll;                         // first line shown

    int fb_w, fb_h;                     // the canvas the panel is laid out for
    int wrap_cols;                      // characters per line at that size
    int visible_rows;                   // lines shown at once
    int repeat_key;                     // UP/DOWN held: which one (-1 none) ...
    double repeat_timer;                // ... and when it repeats next

    ArcadeColor col_text, col_muted, col_accent, col_link, col_panel, col_panel_line;
} ArcadeManPage;

// Finds dir's *.man files (sorted by filename) and lays the panel out for an fb_w x fb_h canvas.
// Nothing is shown yet - arcade_manpage_show() opens it.
//
// @param app_name  The header reads "<app_name> HELP".
// @param dir       Usually "resources/manpages". A missing or empty folder is a help panel that
//                  says so, not an error.
// @param text/muted/accent/link  Colors, so the panel reads as part of the game's own palette.
void arcade_manpage_init(ArcadeManPage *mp, const char *app_name, const char *dir, int fb_w, int fb_h,
                         ArcadeColor text, ArcadeColor muted, ArcadeColor accent, ArcadeColor link);

// Opens help on its first page, wherever it was left last time.
void arcade_manpage_show(ArcadeManPage *mp);

// Call first thing in the game's own update(), every frame.
//
// @return true while help is showing - it took this frame's input, the game should return.
bool arcade_manpage_update(ArcadeManPage *mp, double dt);

// Call last in the game's own render(), every frame - draws nothing while help is closed.
void arcade_manpage_draw(ArcadeManPage *mp, ArcadeFramebuffer *fb);

// Frees the current page's pictures - call once at shutdown.
void arcade_manpage_shutdown(ArcadeManPage *mp);

#ifdef __cplusplus
}
#endif

#endif // ARCADE_MANPAGE_H

// -----------------------------------------------------------------------------------------------
// arcade_leaderboard.c - Implements arcade_leaderboard.h: the leaderboard's rules on top of
// toolbox/db/persistence (the flat-file database that does the actual reading and writing).
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-10-11 File created.                                                     Version: 00.01
// Sun 2026-10-11 The "continue with the name ___? Y/N" question (ARCADE_HS_CONFIRM_  Version: 00.02
//                NAME, arcade_highscores_request_start()/start_ready()) - see
//                arcade_highscores.h 00.06.
// Sun 2026-10-11 Renamed from arcade_highscores.c. Rules on top of toolbox/db/      Version: 00.03
//                persistence instead of SQLite: RANK/NAME/POINTS/TIMESTAMP, top
//                100 by points, 1-5 character names (A-Z, 0-9, blank),
//                settings.dat's player_name; the YES/NO chooser - see
//                arcade_leaderboard.h 00.07.
// Mon 2026-10-12 The board auto-scrolls (board_tick()), smooth rows clipped to      Version: 00.04
//                the list - see arcade_leaderboard.h 00.08.
// Mon 2026-10-12 Writes to the toolbox's log file (log.h): a failed save of        Version: 00.05
//                leaderboard.dat/settings.dat is a log_err with the path (it
//                used to fail silently - the score just wasn't there next
//                launch), and init logs both paths and how many entries loaded.
// -----------------------------------------------------------------------------------------------
#include "arcade_leaderboard.h"

#include "logging/log.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static const char *BOARD_HEADER = "leaderboard.dat - rank, name, points, timestamp (TAB-separated)";
static const char *SETTINGS_HEADER = "settings.dat - key, value (TAB-separated)";

// persistence_save(), logged when it fails - otherwise a score or name just isn't there next launch
// and nothing says why.
static void save_logged(Persistence *p, const char *header) {
    if (!persistence_save(p, header)) log_err("could not write %s", p->path);
}

static void draw_text_centered(ArcadeFramebuffer *fb, const char *text, int cx, int y,
                               ArcadeColor color, int scale) {
    arcade_draw_text(fb, text, cx - arcade_text_width(text, scale) / 2, y, color, scale);
}

// ------------------------------------------------------------------------------------------
// Rules: names.
// ------------------------------------------------------------------------------------------
static bool name_char_ok(char c) {
    return (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ';
}

// Copies raw into out as a valid player name - blanks at either end trimmed, 1 to
// ARCADE_LEADERBOARD_NAME_MAX characters of A-Z/0-9/blank with at least one letter or digit.
//
// @return false (out left empty) if raw can't be a valid name.
static bool name_normalize(const char *raw, char *out) {
    out[0] = '\0';
    if (!raw) return false;
    while (*raw == ' ') raw++;
    size_t len = strlen(raw);
    while (len > 0 && raw[len - 1] == ' ') len--;
    if (len == 0 || len > ARCADE_LEADERBOARD_NAME_MAX) return false;
    for (size_t i = 0; i < len; i++) if (!name_char_ok(raw[i])) return false;
    memcpy(out, raw, len);
    out[len] = '\0';
    return true;
}

// The name-entry wheel: A-Z, then 0-9, then blank, then around again.
static char wheel_next(char c) {
    if (c >= 'A' && c < 'Z') return (char)(c + 1);
    if (c == 'Z') return '0';
    if (c >= '0' && c < '9') return (char)(c + 1);
    if (c == '9') return ' ';
    return 'A'; // blank -> A
}

static char wheel_prev(char c) {
    if (c > 'A' && c <= 'Z') return (char)(c - 1);
    if (c == 'A') return ' ';
    if (c > '0' && c <= '9') return (char)(c - 1);
    if (c == '0') return 'Z';
    return '9'; // blank -> 9
}

// ------------------------------------------------------------------------------------------
// settings.dat - the active player name.
// ------------------------------------------------------------------------------------------
static void settings_load(ArcadeLeaderboard *lb) {
    lb->player_name[0] = '\0';
    for (int i = 0; i < persistence_count(&lb->settings_file); i++) {
        const char *key = persistence_get(&lb->settings_file, i, 0);
        if (key && strcmp(key, "player_name") == 0) {
            name_normalize(persistence_get(&lb->settings_file, i, 1), lb->player_name);
        }
    }
}

static void settings_save(ArcadeLeaderboard *lb) {
    const char *fields[2] = { "player_name", lb->player_name };
    for (int i = 0; i < persistence_count(&lb->settings_file); i++) {
        const char *key = persistence_get(&lb->settings_file, i, 0);
        if (key && strcmp(key, "player_name") == 0) {
            persistence_replace(&lb->settings_file, i, fields, 2);
            save_logged(&lb->settings_file, SETTINGS_HEADER);
            return;
        }
    }
    persistence_append(&lb->settings_file, fields, 2);
    save_logged(&lb->settings_file, SETTINGS_HEADER);
}

// ------------------------------------------------------------------------------------------
// leaderboard.dat - the ranked entries.
// ------------------------------------------------------------------------------------------

// Highest points first; equal points keep the earlier entry ahead (timestamps sort as text).
static int entry_compare(const void *a, const void *b) {
    const ArcadeLeaderboardEntry *ea = a, *eb = b;
    if (ea->points != eb->points) return eb->points > ea->points ? 1 : -1;
    return strcmp(ea->timestamp, eb->timestamp);
}

static void board_rerank(ArcadeLeaderboard *lb) {
    qsort(lb->entries, (size_t)lb->entry_count, sizeof(lb->entries[0]), entry_compare);
    for (int i = 0; i < lb->entry_count; i++) lb->entries[i].rank = i + 1;
}

// Reads every valid record (name passes the rules, points is a number) and keeps the best 100.
static void board_load(ArcadeLeaderboard *lb) {
    static ArcadeLeaderboardEntry all[1000]; // tolerate a hand-edited file with too many lines
    int n = 0;
    for (int i = 0; i < persistence_count(&lb->board_file) && n < 1000; i++) {
        ArcadeLeaderboardEntry e = { 0 };
        const char *points = persistence_get(&lb->board_file, i, 2);
        if (!points || !name_normalize(persistence_get(&lb->board_file, i, 1), e.name)) continue;
        e.points = atoi(points);
        const char *ts = persistence_get(&lb->board_file, i, 3);
        snprintf(e.timestamp, sizeof(e.timestamp), "%s", ts ? ts : "");
        all[n++] = e;
    }
    qsort(all, (size_t)n, sizeof(all[0]), entry_compare);
    lb->entry_count = n < ARCADE_LEADERBOARD_MAX ? n : ARCADE_LEADERBOARD_MAX;
    memcpy(lb->entries, all, (size_t)lb->entry_count * sizeof(all[0]));
    board_rerank(lb);
}

static void board_save(ArcadeLeaderboard *lb) {
    persistence_clear(&lb->board_file);
    for (int i = 0; i < lb->entry_count; i++) {
        const ArcadeLeaderboardEntry *e = &lb->entries[i];
        char rank[16], points[16];
        snprintf(rank, sizeof(rank), "%d", e->rank);
        snprintf(points, sizeof(points), "%d", e->points);
        const char *fields[4] = { rank, e->name, points, e->timestamp };
        persistence_append(&lb->board_file, fields, 4);
    }
    save_logged(&lb->board_file, BOARD_HEADER);
}

// Would points make the board? Room left, or better than the last entry (a tie doesn't push an
// earlier entry off - it ranks below it).
static bool board_qualifies(const ArcadeLeaderboard *lb, int points) {
    return lb->entry_count < ARCADE_LEADERBOARD_MAX || points > lb->entries[lb->entry_count - 1].points;
}

static void board_record(ArcadeLeaderboard *lb, const char *name, int points) {
    if (!board_qualifies(lb, points)) return;
    ArcadeLeaderboardEntry e = { 0 };
    snprintf(e.name, sizeof(e.name), "%s", name);
    e.points = points;
    time_t now = time(NULL);
    strftime(e.timestamp, sizeof(e.timestamp), "%Y-%m-%dT%H:%M:%SZ", gmtime(&now));

    if (lb->entry_count < ARCADE_LEADERBOARD_MAX) lb->entries[lb->entry_count++] = e;
    else lb->entries[lb->entry_count - 1] = e; // replaces #100, which it beats
    board_rerank(lb);
    board_save(lb);
}

// ------------------------------------------------------------------------------------------
// Lifecycle.
// ------------------------------------------------------------------------------------------
void arcade_leaderboard_init(ArcadeLeaderboard *lb, const char *leaderboard_path, const char *settings_path,
                             ArcadeColor text, ArcadeColor muted, ArcadeColor accent) {
    memset(lb, 0, sizeof(*lb));
    persistence_open(&lb->board_file, leaderboard_path ? leaderboard_path : "leaderboard.dat");
    persistence_open(&lb->settings_file, settings_path ? settings_path : "settings.dat");
    board_load(lb);
    settings_load(lb);
    log_info("leaderboard %s (%d entries), settings %s", lb->board_file.path, lb->entry_count,
             lb->settings_file.path);

    lb->col_text = text;
    lb->col_muted = muted;
    lb->col_accent = accent;
    lb->col_panel = ARCADE_RGB(0x14, 0x14, 0x1c);
    lb->col_panel_line = ARCADE_RGB(0x3a, 0x3a, 0x4a);
    lb->mode = ARCADE_LB_INACTIVE;
}

void arcade_leaderboard_shutdown(ArcadeLeaderboard *lb) {
    // Every change was saved as it happened - only memory is left to release.
    persistence_close(&lb->board_file);
    persistence_close(&lb->settings_file);
}

// See arcade_leaderboard.h for the full contract.
int arcade_leaderboard_top(ArcadeLeaderboard *lb, ArcadeLeaderboardEntry *out, int max) {
    int count = lb->entry_count < max ? lb->entry_count : max;
    if (count > 0) memcpy(out, lb->entries, (size_t)count * sizeof(out[0]));
    return count < 0 ? 0 : count;
}

// ------------------------------------------------------------------------------------------
// Offering a run, opening overlays.
// ------------------------------------------------------------------------------------------
void arcade_leaderboard_offer(ArcadeLeaderboard *lb, int points) {
    if (!board_qualifies(lb, points)) return;
    if (lb->player_name[0] != '\0') {
        board_record(lb, lb->player_name, points);
        return;
    }
    arcade_leaderboard_edit_name(lb);
    lb->pending_insert = true;
    lb->pending_points = points;
}

void arcade_leaderboard_show(ArcadeLeaderboard *lb) {
    lb->mode = ARCADE_LB_BOARD;
    lb->board_scroll = 0;
    lb->board_hold = ARCADE_LB_HOLD_SECS;
}

// The board's auto-scroll: hold at the top, glide to the last page, hold, back to the top. A
// board that fits on one page never moves.
static void board_tick(ArcadeLeaderboard *lb, double dt) {
    double max_scroll = lb->entry_count > ARCADE_LEADERBOARD_PAGE ? lb->entry_count - ARCADE_LEADERBOARD_PAGE : 0;
    if (max_scroll <= 0) { lb->board_scroll = 0; return; }
    if (lb->board_hold > 0) { lb->board_hold -= dt; return; }
    if (lb->board_scroll >= max_scroll) { // held at the last page - start over
        lb->board_scroll = 0;
        lb->board_hold = ARCADE_LB_HOLD_SECS;
        return;
    }
    lb->board_scroll += ARCADE_LB_SCROLL_RATE * dt;
    if (lb->board_scroll >= max_scroll) {
        lb->board_scroll = max_scroll;
        lb->board_hold = ARCADE_LB_HOLD_SECS;
    }
}

void arcade_leaderboard_edit_name(ArcadeLeaderboard *lb) {
    lb->mode = ARCADE_LB_ENTER_NAME;
    lb->pending_insert = false;
    lb->entry_for_start = false;
    lb->entry_letters[0] = 'A';                                    // "A----": a short name is
    for (int i = 1; i < ARCADE_LEADERBOARD_NAME_MAX; i++) lb->entry_letters[i] = ' '; // just ENTERs
    lb->entry_slot = 0;
}

bool arcade_leaderboard_request_start(ArcadeLeaderboard *lb) {
    if (lb->player_name[0] == '\0' || lb->name_confirmed) return true;
    lb->mode = ARCADE_LB_CONFIRM_NAME;
    lb->choice_no = false; // YES framed by default - continuing is the common case
    return false;
}

bool arcade_leaderboard_start_ready(ArcadeLeaderboard *lb) {
    if (!lb->start_ready) return false;
    lb->start_ready = false;
    return true;
}

// ------------------------------------------------------------------------------------------
// Update.
// ------------------------------------------------------------------------------------------
static bool lock_in_pressed(void) {
    return arcade_key_pressed(ARCADE_KEY_ENTER) || arcade_key_pressed(ARCADE_KEY_SPACE);
}

// Name entry's last ENTER: the composed name, if valid, becomes the player name.
static void entry_finish(ArcadeLeaderboard *lb) {
    char raw[ARCADE_LEADERBOARD_NAME_MAX + 1];
    memcpy(raw, lb->entry_letters, ARCADE_LEADERBOARD_NAME_MAX);
    raw[ARCADE_LEADERBOARD_NAME_MAX] = '\0';
    char name[ARCADE_LEADERBOARD_NAME_MAX + 1];
    if (!name_normalize(raw, name)) { // all blank - back to the first slot, nothing saved
        lb->entry_slot = 0;
        return;
    }
    snprintf(lb->player_name, sizeof(lb->player_name), "%s", name);
    settings_save(lb);
    lb->name_confirmed = true; // just chosen - no need to ask about it this session
    if (lb->pending_insert) board_record(lb, lb->player_name, lb->pending_points);
    if (lb->entry_for_start) lb->start_ready = true;
    lb->pending_insert = false;
    lb->entry_for_start = false;
    lb->mode = ARCADE_LB_INACTIVE;
}

bool arcade_leaderboard_update(ArcadeLeaderboard *lb, double dt) {

    if (lb->mode == ARCADE_LB_CONFIRM_NAME) {
        if (arcade_key_pressed(ARCADE_KEY_LEFT) || arcade_key_pressed(ARCADE_KEY_RIGHT)) {
            lb->choice_no = !lb->choice_no; // two choices - either arrow flips between them
        }
        if (lock_in_pressed()) {
            if (!lb->choice_no) { // YES - continue with the saved name
                lb->name_confirmed = true;
                lb->start_ready = true;
                lb->mode = ARCADE_LB_INACTIVE;
            } else {              // NO - pick a new name; confirming it starts the game
                arcade_leaderboard_edit_name(lb);
                lb->entry_for_start = true;
            }
        } else if (arcade_key_pressed(ARCADE_KEY_ESCAPE)) {
            lb->mode = ARCADE_LB_INACTIVE; // back to the game's own screen, no game started
        }
        return true;
    }

    if (lb->mode == ARCADE_LB_BOARD) {
        if (lock_in_pressed() || arcade_key_pressed(ARCADE_KEY_ESCAPE)) {
            lb->mode = ARCADE_LB_INACTIVE;
            return true;
        }
        // By hand: a whole row from wherever the glide is, then the auto-scroll waits.
        int max_scroll = lb->entry_count > ARCADE_LEADERBOARD_PAGE ? lb->entry_count - ARCADE_LEADERBOARD_PAGE : 0;
        bool down = arcade_key_pressed(ARCADE_KEY_DOWN), up = arcade_key_pressed(ARCADE_KEY_UP);
        if (down || up) {
            int row = down ? (int)floor(lb->board_scroll) + 1 : (int)ceil(lb->board_scroll) - 1;
            lb->board_scroll = row < 0 ? 0 : row > max_scroll ? max_scroll : row;
            lb->board_hold = ARCADE_LB_MANUAL_SECS;
        } else {
            board_tick(lb, dt);
        }
        return true;
    }

    if (lb->mode == ARCADE_LB_ENTER_NAME) {
        const int last = ARCADE_LEADERBOARD_NAME_MAX - 1;
        if (arcade_key_pressed(ARCADE_KEY_LEFT))  lb->entry_slot = (lb->entry_slot + last) % ARCADE_LEADERBOARD_NAME_MAX;
        if (arcade_key_pressed(ARCADE_KEY_RIGHT)) lb->entry_slot = (lb->entry_slot + 1) % ARCADE_LEADERBOARD_NAME_MAX;
        if (arcade_key_pressed(ARCADE_KEY_UP))    lb->entry_letters[lb->entry_slot] = wheel_next(lb->entry_letters[lb->entry_slot]);
        if (arcade_key_pressed(ARCADE_KEY_DOWN))  lb->entry_letters[lb->entry_slot] = wheel_prev(lb->entry_letters[lb->entry_slot]);
        if (lock_in_pressed()) {
            if (lb->entry_slot < last) lb->entry_slot++; // lock this character in, on to the next
            else entry_finish(lb);
        }
        if (arcade_key_pressed(ARCADE_KEY_ESCAPE)) {
            lb->pending_insert = false; // cancelling discards this run, no name saved
            lb->entry_for_start = false;
            lb->mode = ARCADE_LB_INACTIVE;
        }
        return true;
    }

    return false;
}

// ------------------------------------------------------------------------------------------
// Draw.
// ------------------------------------------------------------------------------------------
static void draw_panel(ArcadeFramebuffer *fb, int x, int y, int w, int h, ArcadeColor fill,
                       ArcadeColor border) {
    arcade_fill_rect(fb, x, y, w, h, fill);
    arcade_draw_rect(fb, x, y, w, h, border);
}

// Both overlays are sized off this one factor rather than fixed pixel constants, so a game with a
// much bigger canvas (sky-raider: 630x720) gets a proportionally bigger overlay instead of the
// same fixed size as a much smaller one (maze-chomp: ~304x388) - the threshold is fb_h since
// that's where the two games' canvases actually diverge most.
static int ui_scale(int fb_h) {
    return fb_h >= 500 ? 2 : 1;
}

// One choice of the YES/NO chooser: the active one is framed and drawn in the accent color.
static void draw_choice(ArcadeLeaderboard *lb, ArcadeFramebuffer *fb, const char *label, int cx, int y,
                        bool active, int s) {
    int w = 40 * s, h = 16 * s;
    if (active) {
        arcade_draw_rect(fb, cx - w / 2, y, w, h, lb->col_accent);
        arcade_draw_rect(fb, cx - w / 2 + 1, y + 1, w - 2, h - 2, lb->col_accent); // 2 px frame
    }
    draw_text_centered(fb, label, cx, y + h / 2 - 3 * s, active ? lb->col_accent : lb->col_muted, s);
}

void arcade_leaderboard_draw(ArcadeLeaderboard *lb, ArcadeFramebuffer *fb, int fb_w, int fb_h) {
    int cx = fb_w / 2;
    int s = ui_scale(fb_h);
    char buf[48];

    if (lb->mode == ARCADE_LB_BOARD) {
        int first = (int)floor(lb->board_scroll);           // topmost row, maybe partly scrolled off
        int top = (int)lround(lb->board_scroll);            // the row the "1-10 OF 37" line counts from
        int visible = lb->entry_count - top;
        if (visible > ARCADE_LEADERBOARD_PAGE) visible = ARCADE_LEADERBOARD_PAGE;
        if (visible < 0) visible = 0;

        int row_h = 11 * s;
        int panel_w_wanted = 200 * s;
        int panel_w = fb_w > panel_w_wanted + 24 ? panel_w_wanted : fb_w - 24;
        int panel_h = 30 * s + ARCADE_LEADERBOARD_PAGE * row_h + 20 * s;
        int x = cx - panel_w / 2, y = fb_h / 2 - panel_h / 2;

        draw_panel(fb, x, y, panel_w, panel_h, lb->col_panel, lb->col_panel_line);
        draw_text_centered(fb, "LEADERBOARD", cx, y + 8 * s, lb->col_accent, s);

        if (lb->entry_count == 0) {
            draw_text_centered(fb, "NO ENTRIES YET", cx, y + 24 * s, lb->col_muted, s);
        } else {
            // One page of rows plus the one sliding in, clipped to the list so a row half
            // scrolled off is cut at the edge rather than drawn over the title or the footer.
            int list_y = y + 24 * s;
            int offset = (int)lround((lb->board_scroll - first) * row_h);
            arcade_set_clip_rect(x + 1, list_y - 2 * s, panel_w - 2, ARCADE_LEADERBOARD_PAGE * row_h);
            for (int i = 0; i <= ARCADE_LEADERBOARD_PAGE && first + i < lb->entry_count; i++) {
                const ArcadeLeaderboardEntry *e = &lb->entries[first + i];
                snprintf(buf, sizeof(buf), "%3d. %-5s %7d", e->rank, e->name, e->points);
                draw_text_centered(fb, buf, cx, list_y + i * row_h - offset, lb->col_text, s);
            }
            arcade_clear_clip_rect();
            snprintf(buf, sizeof(buf), "%d-%d OF %d", top + 1, top + visible, lb->entry_count);
            draw_text_centered(fb, buf, cx, y + panel_h - 22 * s, lb->col_muted, s);
        }
        draw_text_centered(fb, "ARROWS SCROLL  SPACE ESC CLOSE", cx, y + panel_h - 12 * s, lb->col_muted, s);
        return;
    }

    if (lb->mode == ARCADE_LB_CONFIRM_NAME) {
        int panel_w_wanted = 190 * s;
        int panel_w = fb_w > panel_w_wanted + 24 ? panel_w_wanted : fb_w - 24;
        int panel_h = 112 * s;
        int x = cx - panel_w / 2, y = fb_h / 2 - panel_h / 2;

        draw_panel(fb, x, y, panel_w, panel_h, lb->col_panel, lb->col_panel_line);
        draw_text_centered(fb, "WELCOME BACK", cx, y + 8 * s, lb->col_accent, s);
        draw_text_centered(fb, "WOULD YOU LIKE TO CONTINUE", cx, y + 24 * s, lb->col_text, s);
        draw_text_centered(fb, "WITH THE NAME:", cx, y + 34 * s, lb->col_text, s);

        snprintf(buf, sizeof(buf), "%s?", lb->player_name);
        draw_text_centered(fb, buf, cx, y + 48 * s, lb->col_accent, 2 * s);

        draw_choice(lb, fb, "YES", cx - 30 * s, y + 70 * s, !lb->choice_no, s);
        draw_choice(lb, fb, "NO",  cx + 30 * s, y + 70 * s, lb->choice_no, s);

        draw_text_centered(fb, "ARROWS CHOOSE  SPACE LOCKS IN", cx, y + panel_h - 13 * s, lb->col_muted, s);
        return;
    }

    if (lb->mode == ARCADE_LB_ENTER_NAME) {
        int panel_w_wanted = 170 * s;
        int panel_w = fb_w > panel_w_wanted + 24 ? panel_w_wanted : fb_w - 24;
        int panel_h = 86 * s;
        int x = cx - panel_w / 2, y = fb_h / 2 - panel_h / 2;

        draw_panel(fb, x, y, panel_w, panel_h, lb->col_panel, lb->col_panel_line);
        draw_text_centered(fb, "ENTER YOUR NAME", cx, y + 8 * s, lb->col_accent, s);

        const int spacing = 22 * s;
        int first_x = cx - spacing * (ARCADE_LEADERBOARD_NAME_MAX - 1) / 2;
        for (int i = 0; i < ARCADE_LEADERBOARD_NAME_MAX; i++) {
            char shown[2] = { lb->entry_letters[i] == ' ' ? '-' : lb->entry_letters[i], '\0' }; // blank as '-'
            ArcadeColor c = (i == lb->entry_slot) ? lb->col_accent : lb->col_text;
            int slot_x = first_x + i * spacing;
            draw_text_centered(fb, shown, slot_x, y + 28 * s, c, 2 * s);
            if (i == lb->entry_slot) {
                arcade_fill_rect(fb, slot_x - 6 * s, y + 46 * s, 12 * s, 1 * s, lb->col_accent);
            }
        }
        draw_text_centered(fb, "UP DOWN: A-Z 0-9 BLANK", cx, y + panel_h - 30 * s, lb->col_muted, s);
        draw_text_centered(fb, "ENTER LOCKS IN", cx, y + panel_h - 20 * s, lb->col_muted, s);
        draw_text_centered(fb, "ESC CANCELS", cx, y + panel_h - 10 * s, lb->col_muted, s);
    }
}

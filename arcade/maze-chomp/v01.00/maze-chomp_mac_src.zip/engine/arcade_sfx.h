// -----------------------------------------------------------------------------------------------
// arcade_sfx.h - Sound effects for arcade games: short synthesized beeps and glides (square,
// sawtooth or noise, with an exponential fade-out), mixed in real time on top of the toolbox's
// audio driver (shared/toolbox/audio/audio.h - CoreAudio on macOS, waveOut on Windows).
//
// Effects are queued from the game loop and played by the audio driver's own thread; each can
// start after a delay, which is how multi-note jingles are sequenced. If no audio device can be
// opened, every function here quietly does nothing - a game never has to check.
//
// One music track plays underneath the effects: a WAV clip the game loaded with the toolbox's
// wav_load() (shared/toolbox/audio/wav.h - which is then also linked), looped or once, paused
// and resumed in place.
//
// A game using this links ../shared/toolbox/audio/audio.c (plus, on macOS, the AudioToolbox,
// AudioUnit and CoreAudio frameworks; on Windows, -lwinmm).
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sat 2026-10-10 File created as maze-chomp/sfx.h - ported from maze-chomp.html's   Version: 00.01
//                beep()/sfx*().
// Sat 2026-10-10 Moved into the engine as arcade_sfx.h so every arcade game shares   Version: 00.02
//                it (Sky Raider is the second). arcade_ prefix on everything, a
//                noise wave for explosions, and arcade_sfx_slide() for pitch glides.
// Mon 2026-10-12 Music track: arcade_sfx_music_play()/stop()/set_paused() mix one     Version: 00.03
//                WavClip (toolbox wav_load()) under the effects - wav.c's own
//                wav_sample() would take over the whole output instead.
// -----------------------------------------------------------------------------------------------
#ifndef ARCADE_SFX_H
#define ARCADE_SFX_H

#include <stdbool.h>

#include "audio/wav.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    ARCADE_SFX_SQUARE,   // hollow, classic chip-tune beep
    ARCADE_SFX_SAWTOOTH, // brighter, buzzier
    ARCADE_SFX_NOISE     // explosions and crashes - freq sets how fast the noise changes (low = rumble)
} ArcadeSfxWave;

// Opens the audio device. Returns false (and leaves sound off) if there is none.
bool arcade_sfx_init(void);

// Queues one beep: freq Hz for dur seconds at volume vol (0..1), starting delay seconds from now.
// Dropped silently while muted or if all voices are busy.
void arcade_sfx_beep(double freq, double dur, ArcadeSfxWave wave, double vol, double delay);

// Like arcade_sfx_beep(), but the pitch glides from freq_start to freq_end over the beep's
// duration (exponentially, the way pitch is heard) - a laser "pew", a falling whistle.
void arcade_sfx_slide(double freq_start, double freq_end, double dur, ArcadeSfxWave wave, double vol,
                      double delay);

// Plays clip as the music track at volume vol (0..1), from its first frame, replacing whatever
// music was playing. Asking for the clip that's already playing changes nothing - it keeps its
// place - so a game can call this every frame with the music its state wants. NULL, or a clip that
// failed to load, stops the music. clip must stay loaded until the music is stopped or replaced,
// or until arcade_sfx_shutdown().
void arcade_sfx_music_play(const WavClip *clip, bool loop, double vol);
void arcade_sfx_music_stop(void);

// Holds the music where it is (true) and lets it continue from there (false).
void arcade_sfx_music_set_paused(bool paused);

// Mutes the effects and the music alike.
void arcade_sfx_set_muted(bool muted);
bool arcade_sfx_is_muted(void);

// Closes the audio device.
void arcade_sfx_shutdown(void);

#ifdef __cplusplus
}
#endif

#endif // ARCADE_SFX_H

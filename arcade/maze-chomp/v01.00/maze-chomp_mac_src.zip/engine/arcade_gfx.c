// -----------------------------------------------------------------------------------------------
// arcade_gfx.c - Implements arcade_gfx.h. Pure C, no Cocoa in sight — just reading and writing
// a uint32_t array.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Fri 2026-08-21 File created.                                                     Version: 00.01
// Fri 2026-08-21 Added the built-in 5x7 font, arcade_draw_text(),                    Version: 00.02
//                arcade_text_width().
// Mon 2026-10-12 More punctuation for the manpage viewer's running text and its    Version: 00.03
//                "[01]" page row: [ ] ( ) / " + = ; _ < > % # & * ^. Still
//                uppercase only.
// -----------------------------------------------------------------------------------------------
#include "arcade_gfx.h"
#include <stdlib.h>
#include <ctype.h>

// Packs a color into the framebuffer's uint32_t pixel format. All current Mac hardware (Intel
// and Apple Silicon) is little-endian, so building the integer this way puts the bytes in memory
// in R,G,B,A order — which is exactly the byte order the window backend tells CoreGraphics to
// expect (kCGBitmapByteOrder32Big | kCGImageAlphaPremultipliedLast, see arcade_window.m).
static inline uint32_t arcade_pack(ArcadeColor c) {
    return (uint32_t)c.r | ((uint32_t)c.g << 8) | ((uint32_t)c.b << 16) | ((uint32_t)c.a << 24);
}

// ------------------------------------------------------------------------------------------
// Clip rect: an optional extra bound every drawing primitive below respects, on top of the
// framebuffer's own edges. Global state (there's one framebuffer, one frame being drawn at a
// time), so it persists until changed — set it before drawing into a sub-region (a scroll
// viewport, a dialog box, ...) and clear it when you're done, or it'll keep constraining
// everything drawn afterward. arcade_clear() ignores it deliberately; clearing the whole
// framebuffer is a different operation from constrained drawing.
// ------------------------------------------------------------------------------------------
static int s_clip_x = 0, s_clip_y = 0, s_clip_w = -1, s_clip_h = -1; // w < 0 means "no clip"

void arcade_set_clip_rect(int x, int y, int w, int h) {
    s_clip_x = x;
    s_clip_y = y;
    s_clip_w = w;
    s_clip_h = h;
}

void arcade_clear_clip_rect(void) {
    s_clip_w = -1;
    s_clip_h = -1;
}

// Intersects the requested (x,y,w,h) rect with both the framebuffer bounds and the active clip
// rect (if any), returning it as [x0,x1) x [y0,y1) — ready to loop over directly.
static void arcade_clip_bounds(const ArcadeFramebuffer *fb, int x, int y, int w, int h,
                                int *out_x0, int *out_y0, int *out_x1, int *out_y1) {
    int x0 = x, y0 = y, x1 = x + w, y1 = y + h;

    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > fb->width) x1 = fb->width;
    if (y1 > fb->height) y1 = fb->height;

    if (s_clip_w >= 0) {
        if (x0 < s_clip_x) x0 = s_clip_x;
        if (y0 < s_clip_y) y0 = s_clip_y;
        if (x1 > s_clip_x + s_clip_w) x1 = s_clip_x + s_clip_w;
        if (y1 > s_clip_y + s_clip_h) y1 = s_clip_y + s_clip_h;
    }

    *out_x0 = x0;
    *out_y0 = y0;
    *out_x1 = x1;
    *out_y1 = y1;
}

static bool arcade_clip_contains(int x, int y) {
    if (s_clip_w < 0) return true;
    return x >= s_clip_x && y >= s_clip_y && x < s_clip_x + s_clip_w && y < s_clip_y + s_clip_h;
}

void arcade_clear(ArcadeFramebuffer *fb, ArcadeColor color) {
    if (!fb || !fb->pixels) return;
    uint32_t packed = arcade_pack(color);
    int count = fb->width * fb->height;
    for (int i = 0; i < count; i++) fb->pixels[i] = packed;
}

void arcade_set_pixel(ArcadeFramebuffer *fb, int x, int y, ArcadeColor color) {
    if (!fb || !fb->pixels) return;
    if (x < 0 || y < 0 || x >= fb->width || y >= fb->height) return;
    if (!arcade_clip_contains(x, y)) return;
    fb->pixels[y * fb->width + x] = arcade_pack(color);
}

void arcade_fill_rect(ArcadeFramebuffer *fb, int x, int y, int w, int h, ArcadeColor color) {
    if (!fb || !fb->pixels) return;
    uint32_t packed = arcade_pack(color);

    int x0, y0, x1, y1;
    arcade_clip_bounds(fb, x, y, w, h, &x0, &y0, &x1, &y1);

    for (int py = y0; py < y1; py++) {
        uint32_t *row = fb->pixels + (size_t)py * fb->width;
        for (int px = x0; px < x1; px++) row[px] = packed;
    }
}

void arcade_draw_rect(ArcadeFramebuffer *fb, int x, int y, int w, int h, ArcadeColor color) {
    if (!fb || !fb->pixels || w <= 0 || h <= 0) return;
    arcade_fill_rect(fb, x, y, w, 1, color);
    arcade_fill_rect(fb, x, y + h - 1, w, 1, color);
    arcade_fill_rect(fb, x, y, 1, h, color);
    arcade_fill_rect(fb, x + w - 1, y, 1, h, color);
}

void arcade_fill_circle(ArcadeFramebuffer *fb, int cx, int cy, int radius, ArcadeColor color) {
    if (!fb || !fb->pixels || radius <= 0) return;

    int x0, y0, x1, y1;
    arcade_clip_bounds(fb, cx - radius, cy - radius, radius * 2 + 1, radius * 2 + 1, &x0, &y0, &x1, &y1);

    int r2 = radius * radius;
    uint32_t packed = arcade_pack(color);
    for (int py = y0; py < y1; py++) {
        uint32_t *row = fb->pixels + (size_t)py * fb->width;
        int dy = py - cy;
        for (int px = x0; px < x1; px++) {
            int dx = px - cx;
            if (dx * dx + dy * dy <= r2) row[px] = packed;
        }
    }
}

ArcadeSprite *arcade_sprite_create(int width, int height) {
    if (width <= 0 || height <= 0) return NULL;
    ArcadeSprite *sprite = calloc(1, sizeof(ArcadeSprite));
    if (!sprite) return NULL;
    sprite->pixels = calloc((size_t)width * height, sizeof(ArcadeColor));
    if (!sprite->pixels) {
        free(sprite);
        return NULL;
    }
    sprite->width = width;
    sprite->height = height;
    return sprite;
}

void arcade_sprite_free(ArcadeSprite *sprite) {
    if (!sprite) return;
    free(sprite->pixels);
    free(sprite);
}

void arcade_sprite_set_pixel(ArcadeSprite *sprite, int x, int y, ArcadeColor color) {
    if (!sprite || !sprite->pixels) return;
    if (x < 0 || y < 0 || x >= sprite->width || y >= sprite->height) return;
    sprite->pixels[y * sprite->width + x] = color;
}

void arcade_draw_sprite(ArcadeFramebuffer *fb, const ArcadeSprite *sprite, int x, int y) {
    if (!fb || !fb->pixels || !sprite || !sprite->pixels) return;

    for (int sy = 0; sy < sprite->height; sy++) {
        int py = y + sy;
        if (py < 0 || py >= fb->height) continue;

        for (int sx = 0; sx < sprite->width; sx++) {
            int px = x + sx;
            if (px < 0 || px >= fb->width) continue;
            if (!arcade_clip_contains(px, py)) continue;

            ArcadeColor c = sprite->pixels[sy * sprite->width + sx];
            if (c.a == 0) continue;

            uint32_t *dst = &fb->pixels[py * fb->width + px];
            if (c.a == 255) {
                *dst = arcade_pack(c);
                continue;
            }

            // Alpha-composite over whatever is already in the framebuffer.
            uint32_t bg = *dst;
            uint8_t bg_r = (uint8_t)(bg & 0xFF);
            uint8_t bg_g = (uint8_t)((bg >> 8) & 0xFF);
            uint8_t bg_b = (uint8_t)((bg >> 16) & 0xFF);

            uint8_t out_r = (uint8_t)((c.r * c.a + bg_r * (255 - c.a)) / 255);
            uint8_t out_g = (uint8_t)((c.g * c.a + bg_g * (255 - c.a)) / 255);
            uint8_t out_b = (uint8_t)((c.b * c.a + bg_b * (255 - c.a)) / 255);

            *dst = arcade_pack(ARCADE_RGB(out_r, out_g, out_b));
        }
    }
}

// ------------------------------------------------------------------------------------------
// Built-in 5x7 font. Each glyph is 7 rows of 5 bits (bit 4 = leftmost column, bit 0 =
// rightmost). Uppercase + digits + a handful of punctuation only — see arcade_gfx.h.
// ------------------------------------------------------------------------------------------
typedef struct {
    char ch;
    uint8_t rows[7];
} ArcadeGlyph;

static const ArcadeGlyph ARCADE_FONT[] = {
    { ' ', { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 } },
    { 'A', { 0x0E, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11 } },
    { 'B', { 0x1E, 0x11, 0x11, 0x1E, 0x11, 0x11, 0x1E } },
    { 'C', { 0x0F, 0x10, 0x10, 0x10, 0x10, 0x10, 0x0F } },
    { 'D', { 0x1E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x1E } },
    { 'E', { 0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x1F } },
    { 'F', { 0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x10 } },
    { 'G', { 0x0F, 0x10, 0x10, 0x17, 0x11, 0x11, 0x0F } },
    { 'H', { 0x11, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11 } },
    { 'I', { 0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x1F } },
    { 'J', { 0x01, 0x01, 0x01, 0x01, 0x11, 0x11, 0x0E } },
    { 'K', { 0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11 } },
    { 'L', { 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1F } },
    { 'M', { 0x11, 0x1B, 0x15, 0x11, 0x11, 0x11, 0x11 } },
    { 'N', { 0x11, 0x19, 0x15, 0x13, 0x11, 0x11, 0x11 } },
    { 'O', { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E } },
    { 'P', { 0x1E, 0x11, 0x11, 0x1E, 0x10, 0x10, 0x10 } },
    { 'Q', { 0x0E, 0x11, 0x11, 0x11, 0x11, 0x12, 0x0D } },
    { 'R', { 0x1E, 0x11, 0x11, 0x1E, 0x14, 0x12, 0x11 } },
    { 'S', { 0x0F, 0x10, 0x10, 0x0E, 0x01, 0x01, 0x1E } },
    { 'T', { 0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04 } },
    { 'U', { 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E } },
    { 'V', { 0x11, 0x11, 0x11, 0x11, 0x11, 0x0A, 0x04 } },
    { 'W', { 0x11, 0x11, 0x11, 0x15, 0x15, 0x1B, 0x11 } },
    { 'X', { 0x11, 0x0A, 0x04, 0x04, 0x04, 0x0A, 0x11 } },
    { 'Y', { 0x11, 0x0A, 0x04, 0x04, 0x04, 0x04, 0x04 } },
    { 'Z', { 0x1F, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1F } },
    { '0', { 0x0E, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0E } },
    { '1', { 0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x1F } },
    { '2', { 0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F } },
    { '3', { 0x0E, 0x11, 0x01, 0x06, 0x01, 0x11, 0x0E } },
    { '4', { 0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02 } },
    { '5', { 0x1F, 0x10, 0x10, 0x1E, 0x01, 0x01, 0x1E } },
    { '6', { 0x0E, 0x10, 0x10, 0x1E, 0x11, 0x11, 0x0E } },
    { '7', { 0x1F, 0x01, 0x02, 0x04, 0x04, 0x04, 0x04 } },
    { '8', { 0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E } },
    { '9', { 0x0E, 0x11, 0x11, 0x0F, 0x01, 0x01, 0x0E } },
    { '.', { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04 } },
    { ',', { 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x08 } },
    { '!', { 0x04, 0x04, 0x04, 0x04, 0x04, 0x00, 0x04 } },
    { '?', { 0x0E, 0x11, 0x01, 0x02, 0x04, 0x00, 0x04 } },
    { ':', { 0x00, 0x04, 0x00, 0x00, 0x04, 0x00, 0x00 } },
    { '-', { 0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00 } },
    { '\'', { 0x04, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00 } },
    { '[', { 0x0E, 0x08, 0x08, 0x08, 0x08, 0x08, 0x0E } },
    { ']', { 0x0E, 0x02, 0x02, 0x02, 0x02, 0x02, 0x0E } },
    { '(', { 0x02, 0x04, 0x08, 0x08, 0x08, 0x04, 0x02 } },
    { ')', { 0x08, 0x04, 0x02, 0x02, 0x02, 0x04, 0x08 } },
    { '/', { 0x01, 0x01, 0x02, 0x04, 0x08, 0x10, 0x10 } },
    { '"', { 0x0A, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x00 } },
    { '+', { 0x00, 0x04, 0x04, 0x1F, 0x04, 0x04, 0x00 } },
    { '=', { 0x00, 0x00, 0x1F, 0x00, 0x1F, 0x00, 0x00 } },
    { ';', { 0x00, 0x04, 0x00, 0x00, 0x04, 0x04, 0x08 } },
    { '_', { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F } },
    { '<', { 0x02, 0x04, 0x08, 0x10, 0x08, 0x04, 0x02 } },
    { '>', { 0x08, 0x04, 0x02, 0x01, 0x02, 0x04, 0x08 } },
    { '%', { 0x18, 0x19, 0x02, 0x04, 0x08, 0x13, 0x03 } },
    { '#', { 0x0A, 0x0A, 0x1F, 0x0A, 0x1F, 0x0A, 0x0A } },
    { '&', { 0x0C, 0x12, 0x14, 0x08, 0x15, 0x12, 0x0D } },
    { '*', { 0x00, 0x04, 0x15, 0x0E, 0x15, 0x04, 0x00 } },
    { '^', { 0x04, 0x0A, 0x11, 0x00, 0x00, 0x00, 0x00 } },
};
#define ARCADE_FONT_COUNT (sizeof(ARCADE_FONT) / sizeof(ARCADE_FONT[0]))

static const uint8_t *arcade_font_find(char c) {
    if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
    for (size_t i = 0; i < ARCADE_FONT_COUNT; i++) {
        if (ARCADE_FONT[i].ch == c) return ARCADE_FONT[i].rows;
    }
    return NULL;
}

#define ARCADE_GLYPH_ADVANCE(scale) (6 * (scale)) // 5 wide + 1 spacing
#define ARCADE_LINE_HEIGHT(scale)   (9 * (scale)) // 7 tall + 2 spacing

static void arcade_draw_glyph(ArcadeFramebuffer *fb, char c, int x, int y, ArcadeColor color, int scale) {
    const uint8_t *rows = arcade_font_find(c);
    if (!rows) return;

    for (int row = 0; row < 7; row++) {
        uint8_t bits = rows[row];
        for (int col = 0; col < 5; col++) {
            if (bits & (1u << (4 - col))) {
                arcade_fill_rect(fb, x + col * scale, y + row * scale, scale, scale, color);
            }
        }
    }
}

void arcade_draw_text(ArcadeFramebuffer *fb, const char *text, int x, int y, ArcadeColor color, int scale) {
    if (!fb || !text || scale <= 0) return;

    int pen_x = x;
    int pen_y = y;

    for (const char *p = text; *p; p++) {
        if (*p == '\n') {
            pen_x = x;
            pen_y += ARCADE_LINE_HEIGHT(scale);
            continue;
        }

        arcade_draw_glyph(fb, *p, pen_x, pen_y, color, scale);
        pen_x += ARCADE_GLYPH_ADVANCE(scale);
    }
}

void arcade_draw_text_wrapped(ArcadeFramebuffer *fb, const char *text, int x, int y, int max_width,
                               ArcadeColor color, int scale) {
    if (!fb || !text || scale <= 0 || max_width <= 0) return;

    int pen_x = x;
    int pen_y = y;

    const char *p = text;
    while (*p) {
        if (*p == '\n') {
            pen_x = x;
            pen_y += ARCADE_LINE_HEIGHT(scale);
            p++;
            continue;
        }
        if (*p == ' ') {
            pen_x += ARCADE_GLYPH_ADVANCE(scale);
            p++;
            continue;
        }

        // Measure the next whole word so it never gets split across a line break.
        const char *word_start = p;
        while (*p && *p != ' ' && *p != '\n') p++;
        int word_len = (int)(p - word_start);
        int word_width = word_len * ARCADE_GLYPH_ADVANCE(scale) - scale; // no trailing gap

        if (pen_x != x && pen_x - x + word_width > max_width) {
            pen_x = x;
            pen_y += ARCADE_LINE_HEIGHT(scale);
        }

        for (int i = 0; i < word_len; i++) {
            arcade_draw_glyph(fb, word_start[i], pen_x, pen_y, color, scale);
            pen_x += ARCADE_GLYPH_ADVANCE(scale);
        }
    }
}

int arcade_text_width(const char *text, int scale) {
    if (!text || scale <= 0) return 0;

    int max_width = 0;
    int line_width = 0;
    for (const char *p = text; *p; p++) {
        if (*p == '\n') {
            if (line_width > max_width) max_width = line_width;
            line_width = 0;
            continue;
        }
        line_width += ARCADE_GLYPH_ADVANCE(scale);
    }
    if (line_width > max_width) max_width = line_width;

    // Drop the trailing inter-character gap so the width matches the glyphs themselves.
    return max_width > 0 ? max_width - scale : 0;
}

// Total pixel height arcade_draw_text_wrapped() would need for `text` at the given max_width
// and scale — i.e. how many lines the word-wrap produces. Mirrors that function's line-break
// decisions exactly; needed to clamp a scroll offset to the real content height.
int arcade_text_wrapped_height(const char *text, int max_width, int scale) {
    if (!text || scale <= 0 || max_width <= 0) return 0;

    int lines = 1;
    int pen_x = 0;

    const char *p = text;
    while (*p) {
        if (*p == '\n') {
            lines++;
            pen_x = 0;
            p++;
            continue;
        }
        if (*p == ' ') {
            pen_x += ARCADE_GLYPH_ADVANCE(scale);
            p++;
            continue;
        }

        const char *word_start = p;
        while (*p && *p != ' ' && *p != '\n') p++;
        int word_len = (int)(p - word_start);
        int word_width = word_len * ARCADE_GLYPH_ADVANCE(scale) - scale;

        if (pen_x != 0 && pen_x + word_width > max_width) {
            lines++;
            pen_x = 0;
        }
        pen_x += word_len * ARCADE_GLYPH_ADVANCE(scale);
    }

    return lines * ARCADE_LINE_HEIGHT(scale);
}


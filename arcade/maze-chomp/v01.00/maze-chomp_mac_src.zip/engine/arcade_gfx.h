// -----------------------------------------------------------------------------------------------
// arcade_gfx.h - Software drawing primitives that operate directly on an ArcadeFramebuffer:
// pixels, rectangles, circles, and simple sprites. Everything here is plain C running against a
// plain pixel array — the Cocoa/CoreGraphics side of the engine never appears in this header.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Fri 2026-08-21 File created.                                                     Version: 00.01
// Fri 2026-08-21 Added arcade_draw_text()/arcade_text_width() and the built-in       Version: 00.02
//                5x7 font.
// Fri 2026-08-21 Added arcade_draw_text_wrapped() for word-wrapped body text.        Version: 00.03
// Fri 2026-08-21 Added arcade_text_wrapped_height() for scroll clamping.             Version: 00.04
// Fri 2026-08-21 Added arcade_set_clip_rect()/arcade_clear_clip_rect(), respected     Version: 00.05
//                by every primitive except arcade_clear(). Widened line spacing
//                by 1px (all text functions).
// Mon 2026-10-12 The font gained [ ] ( ) / " + = ; _ < > % # & * ^ (see          Version: 00.06
//                arcade_gfx.c 00.03).
// -----------------------------------------------------------------------------------------------
#ifndef ARCADE_GFX_H
#define ARCADE_GFX_H

#include "arcade_window.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint8_t r, g, b, a;
} ArcadeColor;

#define ARCADE_RGB(r, g, b)     ((ArcadeColor){ (uint8_t)(r), (uint8_t)(g), (uint8_t)(b), 255 })
#define ARCADE_RGBA(r, g, b, a) ((ArcadeColor){ (uint8_t)(r), (uint8_t)(g), (uint8_t)(b), (uint8_t)(a) })

void arcade_clear(ArcadeFramebuffer *fb, ArcadeColor color);
void arcade_set_pixel(ArcadeFramebuffer *fb, int x, int y, ArcadeColor color);
void arcade_fill_rect(ArcadeFramebuffer *fb, int x, int y, int w, int h, ArcadeColor color);
void arcade_draw_rect(ArcadeFramebuffer *fb, int x, int y, int w, int h, ArcadeColor color);
void arcade_fill_circle(ArcadeFramebuffer *fb, int cx, int cy, int radius, ArcadeColor color);

// Constrains every drawing primitive below (except arcade_clear()) to within this rect, in
// addition to the framebuffer's own edges — for a scroll viewport, a dialog box, anything that
// shouldn't paint outside its own region. This is global state that persists until changed:
// set it before drawing the constrained content, then arcade_clear_clip_rect() when done, or
// it'll keep applying to everything drawn afterward too.
void arcade_set_clip_rect(int x, int y, int w, int h);
void arcade_clear_clip_rect(void);

// A small owned image: an array of ArcadeColor, blitted onto a framebuffer with alpha
// compositing. Build these procedurally in code for now (arcade_sprite_set_pixel) — there's no
// PNG/BMP decoder in the engine yet.
typedef struct {
    ArcadeColor *pixels;
    int width;
    int height;
} ArcadeSprite;

ArcadeSprite *arcade_sprite_create(int width, int height);
void arcade_sprite_free(ArcadeSprite *sprite);
void arcade_sprite_set_pixel(ArcadeSprite *sprite, int x, int y, ArcadeColor color);
void arcade_draw_sprite(ArcadeFramebuffer *fb, const ArcadeSprite *sprite, int x, int y);

// Built-in 5x7 monospace font: space, A-Z, 0-9, and . , ! ? : - ' [ ] ( ) / " + = ; _ < > % # & * ^
// — uppercase only, matching
// how real arcade cabinet text generators worked. Lowercase input is folded to uppercase
// automatically; any other unsupported character just draws blank. `scale` is the pixel size
// of one font dot (1 = actual 5x7 pixels, 2 = doubled, etc.). '\n' starts a new line.
void arcade_draw_text(ArcadeFramebuffer *fb, const char *text, int x, int y, ArcadeColor color, int scale);

// Same as arcade_draw_text(), but wraps at word boundaries to stay within max_width pixels —
// for flowing prose (manpages, dialogue) rather than short fixed-layout labels. Existing '\n'
// in the input still forces a line break.
void arcade_draw_text_wrapped(ArcadeFramebuffer *fb, const char *text, int x, int y, int max_width,
                               ArcadeColor color, int scale);

// Pixel width the longest line of `text` would occupy if drawn with arcade_draw_text() at the
// given scale. Useful for centering text.
int arcade_text_width(const char *text, int scale);

// Total pixel height arcade_draw_text_wrapped() would need to draw `text` at the given
// max_width and scale. Use this to clamp a scroll offset to the real content height.
int arcade_text_wrapped_height(const char *text, int max_width, int scale);

#ifdef __cplusplus
}
#endif

#endif // ARCADE_GFX_H

// -----------------------------------------------------------------------------------------------
// arcade.h - Umbrella header. Include just this one file to get the window, input, and gfx APIs.
// Logging/debug used to come along too (arcade_log.h/arcade_debug.h), but that was this repo's
// own copy of a system every project in this family duplicated separately - see debug.h/log.h
// under shared/toolbox/logging instead, included directly by whichever file actually needs them.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Fri 2026-08-21 File created.                                                     Version: 00.01
// Fri 2026-08-21 Added arcade_log.h.                                                Version: 00.02
// Fri 2026-08-21 Split arcade_log.h into arcade_log.h (file, permanent) +           Version: 00.03
//                arcade_debug.h (console, --debug flag).
// Tue 2026-08-25 Dropped arcade_log.h/arcade_debug.h - retired in favor of the      Version: 00.04
//                canonical shared/toolbox/logging debug.h/log.h.
// -----------------------------------------------------------------------------------------------
#ifndef ARCADE_H
#define ARCADE_H

#include "arcade_window.h"
#include "arcade_input.h"
#include "arcade_gfx.h"

#endif // ARCADE_H

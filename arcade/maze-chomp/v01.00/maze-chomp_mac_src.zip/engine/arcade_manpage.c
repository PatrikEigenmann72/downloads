// -----------------------------------------------------------------------------------------------
// arcade_manpage.c - Implements arcade_manpage.h: finding the *.man files, the directive parser
// (title/link/navigation, paragraphs reflowed to the panel), page navigation and drawing. The
// parser and the {navigation} windowing follow legacy/engine/legacy_dlg_manpage.c line for line
// where they can, so a fix in one is easy to carry to the other.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-10-12 File created - see arcade_manpage.h 00.01.                        Version: 00.01
// Mon 2026-10-12 {image:} (add_image(), draw_picture()) and {u}...{/u} - see       Version: 00.02
//                arcade_manpage.h 00.04.
// -----------------------------------------------------------------------------------------------
#include "arcade_manpage.h"

#include <dirent.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define REPEAT_DELAY 0.35 // UP/DOWN held: first repeat after this long ...
#define REPEAT_RATE  0.06 // ... then one line every this long

// ------------------------------------------------------------------------------------------
// Layout - everything derives from the canvas size and one scale factor, like the leaderboard's
// overlays (a 300-ish px canvas draws at 1, a 500+ px one at 2).
// ------------------------------------------------------------------------------------------
typedef struct {
    int s;                    // font scale
    int x, y, w, h;           // the panel
    int text_x, content_y;    // first character of the first content row
    int row_h;
    int bar_x;                // the scrollbar's column
} Layout;

static Layout layout_for(int fb_w, int fb_h) {
    Layout l;
    l.s = fb_h >= 500 ? 2 : 1;
    l.x = 8; l.y = 8; l.w = fb_w - 16; l.h = fb_h - 16;
    l.row_h = 10 * l.s;
    l.text_x = l.x + 6 * l.s;
    l.content_y = l.y + 22 * l.s;
    l.bar_x = l.x + l.w - 6 * l.s;
    return l;
}

static int layout_cols(const Layout *l) { return (l->bar_x - 2 * l->s - l->text_x) / (6 * l->s); }
static int layout_rows(const Layout *l) { return (l->y + l->h - 16 * l->s - l->content_y) / l->row_h; }

// ------------------------------------------------------------------------------------------
// Parsing
// ------------------------------------------------------------------------------------------
static int compare_names(const void *a, const void *b) { return strcmp((const char *)a, (const char *)b); }

// Appends one display line, silently dropping it past ARCADE_MANPAGE_MAX_LINES - a page that long
// is a content problem to fix in the .man file, not something to crash over.
static void add_line(ArcadeManPage *mp, ArcadeManPageLineType type, const char *text, int link_index) {
    if (mp->line_count >= ARCADE_MANPAGE_MAX_LINES) return;
    ArcadeManPageLine *line = &mp->lines[mp->line_count++];
    line->type = type;
    line->link_index = link_index;
    line->image_row = 0;
    snprintf(line->text, sizeof(line->text), "%s", text ? text : "");
}

// Word-wraps one joined paragraph to wrap_cols, breaking at the last space that fits.
static void wrap_paragraph(ArcadeManPage *mp, const char *paragraph) {
    size_t width = (size_t)mp->wrap_cols;
    if (width == 0) return;
    size_t len = strlen(paragraph), start = 0;
    while (start < len && paragraph[start] == ' ') start++;

    while (start < len) {
        size_t take = len - start < width ? len - start : width;
        size_t end = start + take;
        if (take == width && end < len && paragraph[end] != ' ') {
            size_t cut = end;
            while (cut > start && paragraph[cut] != ' ') cut--;
            if (cut > start) end = cut;
        }
        char buf[ARCADE_MANPAGE_MAX_LINE_LEN];
        size_t n = end - start < sizeof(buf) - 1 ? end - start : sizeof(buf) - 1;
        memcpy(buf, paragraph + start, n);
        buf[n] = '\0';
        add_line(mp, ARCADE_MANPAGE_LINE_TEXT, buf, -1);
        start = end;
        while (start < len && paragraph[start] == ' ') start++;
    }
}

// Pulls the quoted argument(s) out of {title:"..."} or {link:"label","file"}. Forgiving on purpose -
// it reads hand-written .man files, not arbitrary input.
static void parse_directive(const char *line, const char *prefix, char *out1, size_t out1_size,
                            char *out2, size_t out2_size) {
    out1[0] = '\0';
    if (out2) out2[0] = '\0';
    const char *q1 = strchr(line + strlen(prefix), '"');
    if (!q1) return;
    const char *q2 = strchr(++q1, '"');
    if (!q2) return;
    size_t n = (size_t)(q2 - q1) < out1_size - 1 ? (size_t)(q2 - q1) : out1_size - 1;
    memcpy(out1, q1, n);
    out1[n] = '\0';
    if (!out2) return;

    const char *q3 = strchr(q2 + 1, '"');
    if (!q3) return;
    const char *q4 = strchr(++q3, '"');
    if (!q4) return;
    n = (size_t)(q4 - q3) < out2_size - 1 ? (size_t)(q4 - q3) : out2_size - 1;
    memcpy(out2, q3, n);
    out2[n] = '\0';
}

static void free_images(ArcadeManPage *mp) {
    for (int i = 0; i < mp->image_count; i++) picture_free(&mp->images[i]);
    mp->image_count = 0;
}

// {image:"file"}: decodes pictures_dir/file, scales it (nearest neighbour - these are pixel
// pictures on a pixel canvas) to the text width, and adds one LINE_IMAGE per text row it covers so
// it scrolls like the text around it. A missing or unreadable picture is a line that says so.
static void add_image(ArcadeManPage *mp, const char *file) {
    char path[ARCADE_MANPAGE_MAX_PATH * 2 + 2];
    snprintf(path, sizeof(path), "%s/%s", mp->pictures_dir, file);
    Picture src;
    if (mp->image_count >= ARCADE_MANPAGE_MAX_IMAGES || picture_load(&src, path) != 0) {
        char msg[ARCADE_MANPAGE_MAX_LINE_LEN];
        snprintf(msg, sizeof(msg), "[Missing picture: %s]", file);
        wrap_paragraph(mp, msg);
        return;
    }
    Layout l = layout_for(mp->fb_w, mp->fb_h);
    int w = mp->wrap_cols * 6 * l.s;
    int h = (int)lround((double)src.height * w / src.width);
    if (h < 1) h = 1;
    Picture *dst = &mp->images[mp->image_count];
    dst->width = w;
    dst->height = h;
    dst->pixels = malloc((size_t)w * (size_t)h * 4);
    if (!dst->pixels) { picture_free(&src); return; }
    for (int y = 0; y < h; y++) {
        int sy = y * src.height / h;
        for (int x = 0; x < w; x++) {
            int sx = x * src.width / w;
            memcpy(dst->pixels + ((size_t)y * w + x) * 4, src.pixels + ((size_t)sy * src.width + sx) * 4, 4);
        }
    }
    picture_free(&src);

    int rows = (h + l.row_h - 1) / l.row_h;
    for (int r = 0; r < rows; r++) {
        add_line(mp, ARCADE_MANPAGE_LINE_IMAGE, "", mp->image_count);
        if (mp->line_count > 0) mp->lines[mp->line_count - 1].image_row = r;
    }
    mp->image_count++;
}

// Reads and wraps pages[active_page] into lines[]. An unreadable file is a page that says so.
static void load_page(ArcadeManPage *mp) {
    free_images(mp);
    mp->line_count = 0;
    mp->link_count = 0;
    mp->highlighted_link = -1;
    mp->scroll = 0;

    char path[ARCADE_MANPAGE_MAX_PATH * 2 + 2];
    snprintf(path, sizeof(path), "%s/%s", mp->dir, mp->pages[mp->active_page]);
    FILE *f = fopen(path, "r");
    if (!f) {
        add_line(mp, ARCADE_MANPAGE_LINE_TEXT, "[Could not read this page.]", -1);
        return;
    }

    char paragraph[4096] = "";
    size_t paragraph_len = 0;
    char line[512];
    bool untouched = false; // inside {u}...{/u}
#define FLUSH_PARAGRAPH() \
    do { if (paragraph_len > 0) { wrap_paragraph(mp, paragraph); paragraph[0] = '\0'; paragraph_len = 0; } } while (0)

    while (fgets(line, sizeof(line), f)) {
        size_t len = strlen(line);
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = '\0';
        char *trimmed = line;
        while (*trimmed == ' ' || *trimmed == '\t') trimmed++;

        if (strncmp(trimmed, "{u}", 3) == 0) { FLUSH_PARAGRAPH(); untouched = true; continue; }
        if (untouched) { // verbatim, one line each - cut at the text width rather than reflowed
            if (strncmp(trimmed, "{/u}", 4) == 0) { untouched = false; continue; }
            line[mp->wrap_cols < (int)sizeof(line) ? mp->wrap_cols : (int)sizeof(line) - 1] = '\0';
            add_line(mp, line[0] ? ARCADE_MANPAGE_LINE_TEXT : ARCADE_MANPAGE_LINE_BLANK, line, -1);
            continue;
        }

        if (trimmed[0] == '\0') {
            FLUSH_PARAGRAPH();
            add_line(mp, ARCADE_MANPAGE_LINE_BLANK, "", -1);
        } else if (strncmp(trimmed, "{title:", 7) == 0) {
            FLUSH_PARAGRAPH();
            char title[ARCADE_MANPAGE_MAX_LINE_LEN];
            parse_directive(trimmed, "{title:", title, sizeof(title), NULL, 0);
            add_line(mp, ARCADE_MANPAGE_LINE_TITLE, title, -1);
        } else if (strncmp(trimmed, "{link:", 6) == 0) {
            FLUSH_PARAGRAPH();
            if (mp->link_count < ARCADE_MANPAGE_MAX_LINKS) {
                ArcadeManPageLink *link = &mp->links[mp->link_count];
                parse_directive(trimmed, "{link:", link->label, sizeof(link->label), link->file, sizeof(link->file));
                char text[ARCADE_MANPAGE_MAX_LINE_LEN];
                snprintf(text, sizeof(text), "[%s]", link->label);
                add_line(mp, ARCADE_MANPAGE_LINE_LINK, text, mp->link_count);
                mp->link_count++;
            }
        } else if (strncmp(trimmed, "{image:", 7) == 0) {
            FLUSH_PARAGRAPH();
            char file[ARCADE_MANPAGE_MAX_PATH];
            parse_directive(trimmed, "{image:", file, sizeof(file), NULL, 0);
            add_image(mp, file);
        } else if (strcmp(trimmed, "{navigation}") == 0) {
            FLUSH_PARAGRAPH();
            add_line(mp, ARCADE_MANPAGE_LINE_NAV, "", -1);
        } else { // prose - joins the paragraph with a single space
            if (paragraph_len > 0 && paragraph_len < sizeof(paragraph) - 1) {
                paragraph[paragraph_len++] = ' ';
                paragraph[paragraph_len] = '\0';
            }
            size_t room = sizeof(paragraph) - 1 - paragraph_len, n = strlen(trimmed);
            if (n > room) n = room;
            memcpy(paragraph + paragraph_len, trimmed, n);
            paragraph_len += n;
            paragraph[paragraph_len] = '\0';
        }
    }
    FLUSH_PARAGRAPH();
#undef FLUSH_PARAGRAPH
    fclose(f);
    if (mp->link_count > 0) mp->highlighted_link = 0;
}

static void goto_page(ArcadeManPage *mp, int index) {
    if (mp->page_count == 0) return;
    if (index < 0) index = 0;
    if (index >= mp->page_count) index = mp->page_count - 1;
    mp->active_page = index;
    load_page(mp);
}

// A link to a file that isn't one of the pages found is ignored - a typo shouldn't break help.
static void follow_link(ArcadeManPage *mp, const ArcadeManPageLink *link) {
    for (int i = 0; i < mp->page_count; i++) {
        if (strcmp(mp->pages[i], link->file) == 0) { goto_page(mp, i); return; }
    }
}

// ------------------------------------------------------------------------------------------
// Public API
// ------------------------------------------------------------------------------------------
void arcade_manpage_init(ArcadeManPage *mp, const char *app_name, const char *dir, int fb_w, int fb_h,
                         ArcadeColor text, ArcadeColor muted, ArcadeColor accent, ArcadeColor link) {
    memset(mp, 0, sizeof(*mp));
    snprintf(mp->title, sizeof(mp->title), "%s HELP", app_name);
    snprintf(mp->dir, sizeof(mp->dir), "%s", dir);
    // resources/manpages -> resources/pictures, wherever resources/ is.
    const char *slash = strrchr(dir, '/');
    if (slash) snprintf(mp->pictures_dir, sizeof(mp->pictures_dir), "%.*s/pictures", (int)(slash - dir), dir);
    else snprintf(mp->pictures_dir, sizeof(mp->pictures_dir), "pictures");
    mp->fb_w = fb_w;
    mp->fb_h = fb_h;
    Layout l = layout_for(fb_w, fb_h);
    mp->wrap_cols = layout_cols(&l);
    if (mp->wrap_cols >= ARCADE_MANPAGE_MAX_LINE_LEN) mp->wrap_cols = ARCADE_MANPAGE_MAX_LINE_LEN - 1;
    mp->visible_rows = layout_rows(&l);
    mp->highlighted_link = -1;
    mp->repeat_key = -1;
    mp->col_text = text;
    mp->col_muted = muted;
    mp->col_accent = accent;
    mp->col_link = link;
    mp->col_panel = ARCADE_RGB(0x10, 0x12, 0x24);
    mp->col_panel_line = muted;

    DIR *d = opendir(dir);
    if (d) {
        struct dirent *entry;
        while ((entry = readdir(d)) != NULL && mp->page_count < ARCADE_MANPAGE_MAX_PAGES) {
            size_t len = strlen(entry->d_name);
            if (len > 4 && strcmp(entry->d_name + len - 4, ".man") == 0) {
                snprintf(mp->pages[mp->page_count++], ARCADE_MANPAGE_MAX_PATH, "%s", entry->d_name);
            }
        }
        closedir(d);
    }
    qsort(mp->pages, (size_t)mp->page_count, ARCADE_MANPAGE_MAX_PATH, compare_names);
}

void arcade_manpage_show(ArcadeManPage *mp) {
    mp->active = true;
    mp->repeat_key = -1;
    if (mp->page_count > 0) goto_page(mp, 0);
}

static void scroll_by(ArcadeManPage *mp, int delta) {
    int max_scroll = mp->line_count - mp->visible_rows;
    if (max_scroll < 0) max_scroll = 0;
    mp->scroll += delta;
    if (mp->scroll < 0) mp->scroll = 0;
    if (mp->scroll > max_scroll) mp->scroll = max_scroll;
}

bool arcade_manpage_update(ArcadeManPage *mp, double dt) {
    if (!mp->active) return false;

    if (arcade_key_pressed(ARCADE_KEY_ESCAPE) || arcade_key_pressed(ARCADE_KEY_F1)) {
        mp->active = false;
        return true;
    }
    if (arcade_key_pressed(ARCADE_KEY_LEFT))  goto_page(mp, mp->active_page - 1);
    if (arcade_key_pressed(ARCADE_KEY_RIGHT)) goto_page(mp, mp->active_page + 1);
    for (int i = 0; i < 9; i++) {
        if (arcade_key_pressed((ArcadeKey)(ARCADE_KEY_1 + i)) && i < mp->page_count) goto_page(mp, i);
    }
    if (arcade_key_pressed(ARCADE_KEY_TAB) && mp->link_count > 0) {
        mp->highlighted_link = (mp->highlighted_link + 1) % mp->link_count;
    }
    if (arcade_key_pressed(ARCADE_KEY_ENTER) && mp->highlighted_link >= 0) {
        follow_link(mp, &mp->links[mp->highlighted_link]);
    }

    // UP/DOWN: a line per press, repeating while held.
    if (arcade_key_pressed(ARCADE_KEY_UP) || arcade_key_pressed(ARCADE_KEY_DOWN)) {
        mp->repeat_key = arcade_key_pressed(ARCADE_KEY_UP) ? ARCADE_KEY_UP : ARCADE_KEY_DOWN;
        mp->repeat_timer = REPEAT_DELAY;
        scroll_by(mp, mp->repeat_key == ARCADE_KEY_UP ? -1 : 1);
    } else if (mp->repeat_key >= 0 && arcade_key_down((ArcadeKey)mp->repeat_key)) {
        mp->repeat_timer -= dt;
        while (mp->repeat_timer <= 0) {
            mp->repeat_timer += REPEAT_RATE;
            scroll_by(mp, mp->repeat_key == ARCADE_KEY_UP ? -1 : 1);
        }
    } else {
        mp->repeat_key = -1;
    }
    return true;
}

void arcade_manpage_shutdown(ArcadeManPage *mp) {
    free_images(mp);
    mp->active = false;
}

// ------------------------------------------------------------------------------------------
// Drawing
// ------------------------------------------------------------------------------------------

// A picture at (x, y), alpha-blended onto the panel, only the rows inside [clip_top, clip_bottom) -
// a picture half scrolled off is cut at the text area's edge like a line of text would be.
static void draw_picture(ArcadeFramebuffer *fb, const Picture *pic, int x, int y, int clip_top, int clip_bottom) {
    for (int py = 0; py < pic->height; py++) {
        int fy = y + py;
        if (fy < clip_top || fy >= clip_bottom || fy < 0 || fy >= fb->height) continue;
        for (int px = 0; px < pic->width; px++) {
            int fx = x + px;
            if (fx < 0 || fx >= fb->width) continue;
            const unsigned char *s = pic->pixels + ((size_t)py * pic->width + px) * 4;
            if (s[3] == 0) continue;
            uint32_t *d = &fb->pixels[fy * fb->width + fx];
            int a = s[3];
            int r = ((s[0] * a) + (int)(*d & 0xFF) * (255 - a)) / 255;
            int g = ((s[1] * a) + (int)((*d >> 8) & 0xFF) * (255 - a)) / 255;
            int b = ((s[2] * a) + (int)((*d >> 16) & 0xFF) * (255 - a)) / 255;
            *d = (uint32_t)r | ((uint32_t)g << 8) | ((uint32_t)b << 16) | 0xFF000000u;
        }
    }
}

// How many "[NN]" segments fit beside the two "[...]" markers - a fixed budget, so the row's width
// never depends on whether an ellipsis is needed.
static int nav_window(const ArcadeManPage *mp) {
    int segment = 5, ellipsis = 6; // "[NN] " and "[...] "
    int n = (mp->wrap_cols - 2 * ellipsis) / segment;
    if (n < 1) n = 1;
    if (n > mp->page_count) n = mp->page_count;
    return n;
}

// "[...] [01] [02] [03] [...]" - windowed to keep active_page in view, both ellipses always drawn
// in the same place (dimmed when nothing is hidden on that side) so the row never shifts while
// paging; the current page in the accent color, the others in the link color.
static void draw_navigation(const ArcadeManPage *mp, ArcadeFramebuffer *fb, int x, int y, int s) {
    int window = nav_window(mp), start = 0, end = mp->page_count - 1;
    if (mp->page_count > window) {
        int ideal = mp->active_page - window + 1, max_start = mp->page_count - window;
        start = ideal < 0 ? 0 : ideal > max_start ? max_start : ideal;
        end = start + window - 1;
    }
    int adv = 6 * s;
    arcade_draw_text(fb, "[...]", x, y, start > 0 ? mp->col_link : mp->col_muted, s);
    x += 6 * adv;
    for (int i = start; i <= end; i++) {
        char seg[16];
        snprintf(seg, sizeof(seg), "[%02d]", i + 1);
        arcade_draw_text(fb, seg, x, y, i == mp->active_page ? mp->col_accent : mp->col_link, s);
        x += ((int)strlen(seg) + 1) * adv;
    }
    arcade_draw_text(fb, "[...]", x, y, end < mp->page_count - 1 ? mp->col_link : mp->col_muted, s);
}

void arcade_manpage_draw(ArcadeManPage *mp, ArcadeFramebuffer *fb) {
    if (!mp->active) return;
    Layout l = layout_for(mp->fb_w, mp->fb_h);
    int s = l.s;

    arcade_fill_rect(fb, l.x, l.y, l.w, l.h, mp->col_panel);
    arcade_draw_rect(fb, l.x, l.y, l.w, l.h, mp->col_panel_line);
    int title_x = l.x + l.w / 2 - arcade_text_width(mp->title, s) / 2;
    arcade_draw_text(fb, mp->title, title_x, l.y + 6 * s, mp->col_accent, s);
    arcade_fill_rect(fb, l.x + 1, l.y + 17 * s, l.w - 2, 1, mp->col_panel_line);

    if (mp->page_count == 0) {
        arcade_draw_text(fb, "NO HELP PAGES FOUND", l.text_x, l.content_y, mp->col_muted, s);
    }

    for (int row = 0; row < mp->visible_rows; row++) {
        int index = mp->scroll + row;
        if (index >= mp->line_count) break;
        const ArcadeManPageLine *line = &mp->lines[index];
        int y = l.content_y + row * l.row_h;
        switch (line->type) {
            case ARCADE_MANPAGE_LINE_TITLE: // one solid bar, up to the scrollbar
                arcade_fill_rect(fb, l.text_x - 2 * s, y - 2 * s, l.bar_x - 4 * s - (l.text_x - 2 * s), 11 * s, mp->col_accent);
                arcade_draw_text(fb, line->text, l.text_x, y, mp->col_panel, s);
                break;
            case ARCADE_MANPAGE_LINE_LINK:
                if (line->link_index == mp->highlighted_link) { // highlighted: inverted
                    int w = arcade_text_width(line->text, s);
                    arcade_fill_rect(fb, l.text_x - 1 * s, y - 2 * s, w + 2 * s, 11 * s, mp->col_link);
                    arcade_draw_text(fb, line->text, l.text_x, y, mp->col_panel, s);
                } else {
                    arcade_draw_text(fb, line->text, l.text_x, y, mp->col_link, s);
                }
                break;
            case ARCADE_MANPAGE_LINE_NAV:
                draw_navigation(mp, fb, l.text_x, y, s);
                break;
            case ARCADE_MANPAGE_LINE_TEXT:
                arcade_draw_text(fb, line->text, l.text_x, y, mp->col_text, s);
                break;
            case ARCADE_MANPAGE_LINE_IMAGE: // drawn once, from its top row or the first row shown
                if (line->image_row == 0 || row == 0) {
                    int clip_top = l.content_y - 2 * s;
                    draw_picture(fb, &mp->images[line->link_index], l.text_x,
                                 y - line->image_row * l.row_h - 2 * s, clip_top,
                                 clip_top + mp->visible_rows * l.row_h);
                }
                break;
            default:
                break;
        }
    }

    // Scrollbar, only for a page longer than the panel: the thumb's size is the share of the page
    // shown, its position follows the scroll continuously.
    if (mp->line_count > mp->visible_rows) {
        int track_y = l.content_y - 2 * s, track_h = mp->visible_rows * l.row_h;
        int thumb_h = track_h * mp->visible_rows / mp->line_count;
        if (thumb_h < 6 * s) thumb_h = 6 * s;
        int max_scroll = mp->line_count - mp->visible_rows;
        int thumb_y = track_y + (track_h - thumb_h) * mp->scroll / max_scroll;
        arcade_fill_rect(fb, l.bar_x, track_y, 2 * s, track_h, mp->col_panel_line);
        arcade_fill_rect(fb, l.bar_x - s, thumb_y, 4 * s, thumb_h, mp->col_accent);
    }

    const char *hint = mp->link_count > 0 ? "ARROWS MOVE  TAB ENTER LINKS  ESC CLOSE" : "ARROWS MOVE  ESC CLOSE";
    int hint_x = l.x + l.w / 2 - arcade_text_width(hint, s) / 2;
    arcade_draw_text(fb, hint, hint_x, l.y + l.h - 11 * s, mp->col_muted, s);
}

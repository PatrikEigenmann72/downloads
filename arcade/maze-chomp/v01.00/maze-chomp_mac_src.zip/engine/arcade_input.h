// -----------------------------------------------------------------------------------------------
// arcade_input.h - Keyboard state, polled rather than event-driven. A game asks "is this key
// down right now" or "was this key pressed this frame" — no event queue to manage.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Fri 2026-08-21 File created.                                                     Version: 00.01
// Fri 2026-08-21 Added B/E/F/N/Q, F1, and the four modifier keys + Fn for the         Version: 00.02
//                menu/quit/in-game control scheme.
// Fri 2026-08-21 Added mouse position + button state (arcade_mouse_*()) for          Version: 00.03
//                scrollbar dragging and other pointer interaction.
// Fri 2026-08-21 Added arcade_mouse_scroll_delta() for trackpad/wheel scrolling.      Version: 00.04
// Sat 2026-10-10 Added ARCADE_KEY_P and ARCADE_KEY_M (Maze Chomp's pause and sound    Version: 00.05
//                toggle).
// Sat 2026-10-10 Added ARCADE_KEY_Z (Sky Raider's loop maneuver). Like every letter   Version: 00.06
//                it's a physical key position: on a QWERTZ keyboard it's the key
//                labeled Y.
// Sun 2026-10-11 Added ARCADE_KEY_Y (the high-score 'continue with this name?'        Version: 00.07
//                prompt). A physical position like every letter - on QWERTZ it's the
//                key labeled Z; the prompt accepts both positions.
// Mon 2026-10-12 Added ARCADE_KEY_TAB and ARCADE_KEY_1..ARCADE_KEY_9 (the manpage     Version: 00.08
//                viewer: Tab cycles a page's links, a digit jumps to that page).
//                Digits are the main row's, by physical position like the letters.
// -----------------------------------------------------------------------------------------------
#ifndef ARCADE_INPUT_H
#define ARCADE_INPUT_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    ARCADE_KEY_LEFT,
    ARCADE_KEY_RIGHT,
    ARCADE_KEY_UP,
    ARCADE_KEY_DOWN,
    ARCADE_KEY_SPACE,
    ARCADE_KEY_ESCAPE,
    ARCADE_KEY_ENTER,
    ARCADE_KEY_W,
    ARCADE_KEY_A,
    ARCADE_KEY_S,
    ARCADE_KEY_D,
    ARCADE_KEY_B,
    ARCADE_KEY_E,
    ARCADE_KEY_F,
    ARCADE_KEY_N,
    ARCADE_KEY_Q,
    ARCADE_KEY_F1,
    ARCADE_KEY_P,
    ARCADE_KEY_M,
    ARCADE_KEY_Z,
    ARCADE_KEY_Y,
    ARCADE_KEY_TAB,
    ARCADE_KEY_1, ARCADE_KEY_2, ARCADE_KEY_3, ARCADE_KEY_4, ARCADE_KEY_5, // main row, consecutive
    ARCADE_KEY_6, ARCADE_KEY_7, ARCADE_KEY_8, ARCADE_KEY_9,               // so ARCADE_KEY_1 + n works
    // Modifiers: reported by macOS via a different event than regular keys (flagsChanged,
    // not keyDown/keyUp), but exposed through the same arcade_key_down()/arcade_key_pressed()
    // API so game code doesn't need to care about the difference.
    ARCADE_KEY_SHIFT,
    ARCADE_KEY_CONTROL,
    ARCADE_KEY_OPTION,
    ARCADE_KEY_COMMAND,
    ARCADE_KEY_FN,
    ARCADE_KEY_COUNT
} ArcadeKey;

// True every frame the key is held down.
bool arcade_key_down(ArcadeKey key);

// True only on the frame the key transitioned from up to down.
bool arcade_key_pressed(ArcadeKey key);

typedef struct {
    int x, y;
} ArcadePoint;

typedef enum {
    ARCADE_MOUSE_LEFT,
    ARCADE_MOUSE_RIGHT,
    ARCADE_MOUSE_COUNT
} ArcadeMouseButton;

// Current mouse position in framebuffer pixel coordinates — the same space you draw into, not
// window points. Updated on move, drag, or click; holds its last value while the mouse is
// outside the window.
ArcadePoint arcade_mouse_position(void);

// Same semantics as the key functions above, but for mouse buttons.
bool arcade_mouse_down(ArcadeMouseButton button);
bool arcade_mouse_pressed(ArcadeMouseButton button);
bool arcade_mouse_released(ArcadeMouseButton button);

// Vertical trackpad two-finger swipe / mouse scroll wheel movement accumulated since last
// frame, in points. Resets to 0 every frame whether or not you read it. Sign follows whatever
// macOS's "natural scrolling" setting currently reports — untested which way that nets out in
// practice, so treat the first try as a coin flip and flip the sign at the call site if it
// feels backwards.
double arcade_mouse_scroll_delta(void);

#ifdef __cplusplus
}
#endif

#endif // ARCADE_INPUT_H

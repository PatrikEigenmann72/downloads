// -----------------------------------------------------------------------------------------------
// arcade_sfx.c - Implements arcade_sfx.h: a tiny polyphonic synthesizer behind the toolbox audio
// driver.
//
// Threading: arcade_sfx_beep()/slide() run on the game thread, the render functions on the audio
// driver's real-time thread. They share a fixed array of voices with one atomic flag each - the
// game thread only writes a voice whose flag is free and sets the flag last (release); the audio
// thread only reads a voice whose flag is set (acquire) and frees it when the sound has finished.
// No locks, no allocation, no rand() (not thread-safe) on the audio thread - noise comes from a
// small xorshift generator owned by that thread.
//
// The music track works the same way: the game thread publishes the clip, its loop flag and
// volume, then bumps s_music_gen last; the audio thread sees the new generation, starts that clip
// from frame 0 and keeps the play position to itself.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sat 2026-10-10 File created as maze-chomp/sfx.c - ported from maze-chomp.html's   Version: 00.01
//                beep()/sfx*().
// Sat 2026-10-10 Moved into the engine as arcade_sfx.c. Noise wave (sample-and-hold  Version: 00.02
//                white noise from an audio-thread xorshift), pitch glides (a
//                per-sample step multiplier), 24 voices instead of 16.
// Mon 2026-10-12 Music track (arcade_sfx_music_play()/stop()/set_paused()): one     Version: 00.03
//                WavClip mixed under the voices, handed to the audio thread by
//                generation number - same lock-free handoff as the voices.
// -----------------------------------------------------------------------------------------------
#include "arcade_sfx.h"

#include <math.h>
#include <stdatomic.h>
#include <stdint.h>

#include "audio/audio.h"

#define SFX_VOICES 24

typedef struct {
    atomic_int active;  // 0 = free (game thread may write), 1 = owned by the audio thread
    double phase;       // 0..1 through the current wave cycle
    double step;        // phase advance per sample (freq / sample rate)
    double step_mul;    // step multiplier per sample - 1.0 for a beep, != 1.0 for a glide
    double gain;        // current amplitude
    double decay;       // gain multiplier per sample - reaches 1/10000 of vol at the end
    double held;        // noise: the current random value, held until the phase wraps
    long delay;         // samples to wait before sounding
    long remaining;     // samples left to sound
    ArcadeSfxWave wave;
} SfxVoice;

static SfxVoice s_voices[SFX_VOICES];
static bool s_ready = false;
static atomic_bool s_muted = false;
static double s_last = 0.0;          // the left channel's latest sample, repeated on the right
static uint32_t s_noise = 0x9E3779B9u; // xorshift32 state - touched by the audio thread only

// Music: written by the game thread, s_music_gen last (release).
static const WavClip *_Atomic s_music = NULL;
static atomic_bool s_music_loop = false;
static atomic_bool s_music_paused = false;
static _Atomic double s_music_vol = 0.0;
static atomic_uint s_music_gen = 0;
static const WavClip *s_music_requested = NULL; // game thread only - what was last asked for
// Audio thread only.
static unsigned s_music_seen_gen = 0;
static size_t s_music_pos = 0;

// The music track's next sample - silent while stopped, paused or past the end of a one-shot clip.
static double sfx_music_sample(void) {
    unsigned gen = atomic_load_explicit(&s_music_gen, memory_order_acquire);
    if (gen != s_music_seen_gen) { s_music_seen_gen = gen; s_music_pos = 0; }
    const WavClip *clip = atomic_load_explicit(&s_music, memory_order_relaxed);
    if (!clip || atomic_load_explicit(&s_music_paused, memory_order_relaxed)) return 0.0;
    if (s_music_pos >= clip->frame_count) {
        if (!atomic_load_explicit(&s_music_loop, memory_order_relaxed)) return 0.0;
        s_music_pos = 0;
    }
    return clip->samples[s_music_pos++] * atomic_load_explicit(&s_music_vol, memory_order_relaxed);
}

static double sfx_noise_sample(void) {
    s_noise ^= s_noise << 13;
    s_noise ^= s_noise >> 17;
    s_noise ^= s_noise << 5;
    return (double)s_noise / 2147483647.5 - 1.0; // [-1, 1]
}

// One mono sample of every active voice, summed - called once per output sample by the driver.
static double sfx_render_left(void) {
    double mix = sfx_music_sample();
    if (atomic_load_explicit(&s_muted, memory_order_relaxed)) mix = 0.0; // keeps its place, silently
    for (int i = 0; i < SFX_VOICES; i++) {
        SfxVoice *v = &s_voices[i];
        if (!atomic_load_explicit(&v->active, memory_order_acquire)) continue;

        if (v->delay > 0) { v->delay--; continue; }

        double wave;
        switch (v->wave) {
            case ARCADE_SFX_SQUARE:   wave = v->phase < 0.5 ? 1.0 : -1.0; break;
            case ARCADE_SFX_SAWTOOTH: wave = 2.0 * v->phase - 1.0; break;
            default:                  wave = v->held; break;
        }
        mix += wave * v->gain;

        v->phase += v->step;
        if (v->phase >= 1.0) {
            v->phase -= 1.0;
            if (v->wave == ARCADE_SFX_NOISE) v->held = sfx_noise_sample();
        }
        v->step *= v->step_mul;
        v->gain *= v->decay;

        if (--v->remaining <= 0) atomic_store_explicit(&v->active, 0, memory_order_release);
    }
    if (mix > 1.0) mix = 1.0;
    if (mix < -1.0) mix = -1.0;
    s_last = mix;
    return mix;
}

// The driver calls left then right for each frame - right just repeats left (mono effects), so
// the voices advance exactly once per frame.
static double sfx_render_right(void) {
    return s_last;
}

// See arcade_sfx.h for the full contract.
bool arcade_sfx_init(void) {
    if (s_ready) return true;
    if (audio_start() != 0) return false;
    audio_set_channels(sfx_render_left, sfx_render_right);
    s_ready = true;
    return true;
}

// See arcade_sfx.h for the full contract.
void arcade_sfx_slide(double freq_start, double freq_end, double dur, ArcadeSfxWave wave, double vol,
                      double delay) {
    if (!s_ready || atomic_load(&s_muted) || freq_start <= 0.0 || freq_end <= 0.0 || dur <= 0.0 || vol <= 0.0) return;

    for (int i = 0; i < SFX_VOICES; i++) {
        SfxVoice *v = &s_voices[i];
        if (atomic_load_explicit(&v->active, memory_order_acquire)) continue;

        long samples = (long)(dur * AUDIO_SAMPLE_RATE);
        if (samples < 1) samples = 1;
        v->phase = 0.0;
        v->step = freq_start / AUDIO_SAMPLE_RATE;
        v->step_mul = pow(freq_end / freq_start, 1.0 / (double)samples);
        v->gain = vol;
        // WebAudio's exponentialRampToValueAtTime(0.0001, end): the same curve, one multiply per sample.
        v->decay = pow(0.0001 / vol, 1.0 / (double)samples);
        v->held = 0.0;
        v->delay = (long)(delay * AUDIO_SAMPLE_RATE);
        v->remaining = samples;
        v->wave = wave;
        atomic_store_explicit(&v->active, 1, memory_order_release); // hand it to the audio thread
        return;
    }
}

// See arcade_sfx.h for the full contract.
void arcade_sfx_beep(double freq, double dur, ArcadeSfxWave wave, double vol, double delay) {
    arcade_sfx_slide(freq, freq, dur, wave, vol, delay);
}

// See arcade_sfx.h for the full contract.
void arcade_sfx_music_play(const WavClip *clip, bool loop, double vol) {
    if (clip && (!clip->samples || clip->frame_count == 0)) clip = NULL;
    if (clip == s_music_requested) return; // already the music - keep its place
    s_music_requested = clip;
    atomic_store_explicit(&s_music, clip, memory_order_relaxed);
    atomic_store_explicit(&s_music_loop, loop, memory_order_relaxed);
    atomic_store_explicit(&s_music_vol, vol, memory_order_relaxed);
    atomic_store_explicit(&s_music_paused, false, memory_order_relaxed);
    atomic_fetch_add_explicit(&s_music_gen, 1, memory_order_release);
}

void arcade_sfx_music_stop(void) { arcade_sfx_music_play(NULL, false, 0.0); }

void arcade_sfx_music_set_paused(bool paused) { atomic_store(&s_music_paused, paused); }

void arcade_sfx_set_muted(bool muted) { atomic_store(&s_muted, muted); }
bool arcade_sfx_is_muted(void) { return atomic_load(&s_muted); }

// See arcade_sfx.h for the full contract.
void arcade_sfx_shutdown(void) {
    if (!s_ready) return;
    arcade_sfx_music_stop();
    audio_set_channels(NULL, NULL);
    audio_stop();
    s_ready = false;
}

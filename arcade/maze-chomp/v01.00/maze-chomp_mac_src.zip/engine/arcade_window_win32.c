// -----------------------------------------------------------------------------------------------
// arcade_window_win32.c - Implements arcade_window.h and arcade_input.h directly against Win32
// and GDI - the Windows twin of arcade_window.m. Same contract, same behavior: open a fixed-size
// window, drive a ~60Hz loop, track key/mouse state, and blit the raw pixel buffer to the screen
// every frame. No SDL, no raylib, nothing to install - user32, gdi32 and winmm ship with Windows.
//
// The whole file is wrapped in #ifdef _WIN32: the macOS build compiles ../engine/*.c too (and
// arcade_window.m next to it), so on macOS this file compiles to nothing.
//
// Differences from the macOS version that a game can notice, all deliberate:
//   - Pixel format: arcade_pack() lays out R,G,B,A in memory; a GDI 32-bit DIB wants B,G,R,x.
//     Every frame is converted into a scratch buffer (red/blue swapped) before StretchDIBits.
//   - Letter keys map by scan code (physical key position), like macOS's keyCode, so W/A/S/D
//     stay where they are on a QWERTZ or AZERTY keyboard too.
//   - Modifiers: OPTION = Alt, COMMAND = the Windows key. FN never reaches software on
//     Windows (the keyboard handles it in hardware), so ARCADE_KEY_FN is always false.
//   - High-DPI screens: the process is DPI-aware and multiplies pixel_scale by the display's
//     exact scale factor (1.25 at 125%, 2 at 200%) - the same size every other app on that
//     screen gets, like a Mac's points vs. pixels. If that window wouldn't fit the screen's work
//     area, it falls back to the largest whole factor that does. A whole factor is drawn
//     nearest-neighbor (crisp squares); a fractional one is smoothed (HALFTONE), since game
//     pixels can't all be the same width at 1.25x.
//   - Losing focus releases every key and button, so nothing stays "held" after an Alt+Tab.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sat 2026-10-10 File created - Windows port of arcade_window.m.                   Version: 00.01
// Sat 2026-10-10 Maps P (scan code 0x19) and M (scan code 0x32) to                 Version: 00.02
//                ARCADE_KEY_P/ARCADE_KEY_M.
// Sat 2026-10-10 Maps Z (scan code 0x2C) to ARCADE_KEY_Z.                          Version: 00.03
// Sat 2026-10-10 Fixed: arcade_key_pressed()/arcade_mouse_pressed()/released()     Version: 00.04
//                were never true - the previous-frame snapshot ran after the
//                events were applied, so prev always equaled now (Space, P, M, Esc
//                and the loop key did nothing). The snapshot now runs at the end
//                of each tick (arcade_input_end_frame()), and fresh
//                key-downs/clicks are latched so a tap shorter than one frame
//                still counts; auto-repeat doesn't.
// Sun 2026-10-11 Follows the exact Windows display scaling instead of rounding it   Version: 00.05
//                down - at 125% every arcade window came out 25% smaller than
//                other apps. Falls back to the largest whole factor that fits the
//                work area; fractional factors are drawn smoothed (HALFTONE). The
//                window is centered in the work area, not the whole screen.
// Sun 2026-10-11 Maps Y (scan code 0x15) to ARCADE_KEY_Y.                           Version: 00.06
// Mon 2026-10-12 Window icon (title bar, taskbar, Alt+Tab) from                    Version: 00.07
//                resources\icons\<exe name>.ico next to the .exe, read at runtime
//                (arcade_load_icons()) - not compiled into the binary, the way
//                macOS keeps it in the .app bundle. compile.ps1 makes the .ico
//                from resources\icons\<tool>.png.
// Mon 2026-10-12 Comment only: install.ps1 makes the .ico now (on every            Version: 00.08
//                install, from the source PNG), not compile.ps1 - like
//                install.sh's .icns on macOS.
// Mon 2026-10-12 Maps VK_TAB and the main row's 1-9 (scan codes 0x02-0x0A) to       Version: 00.09
//                ARCADE_KEY_TAB/ARCADE_KEY_1..9 (the manpage viewer).
// -----------------------------------------------------------------------------------------------
#ifdef _WIN32

#include <windows.h>
#include <mmsystem.h> // timeBeginPeriod() - 1 ms Sleep() resolution for the frame pacing
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "arcade_window.h"
#include "arcade_input.h"
#include "logging/debug.h"

#define ARCADE_TARGET_FPS 60.0

// ------------------------------------------------------------------------------------------
// Key state - written by the window procedure, read by arcade_key_down/pressed.
// s_key_down_prev is the state as of the previous frame's update(), snapshotted at the END of
// each tick - so "pressed" means "down now, wasn't down last frame". (Snapshotting at the start
// of the tick, after the events were already applied, made prev == now and "pressed" never
// true.) s_key_tapped latches every fresh key-down between two frames, so a key pressed and
// released inside one frame still counts as pressed once; auto-repeat doesn't count.
// ------------------------------------------------------------------------------------------
static bool s_key_down[ARCADE_KEY_COUNT];
static bool s_key_down_prev[ARCADE_KEY_COUNT];
static bool s_key_tapped[ARCADE_KEY_COUNT];

// Maps a key message to an ArcadeKey. Letters go by scan code (bits 16-23 of lParam - the
// physical key, layout-independent, like macOS's keyCode); everything else by virtual key,
// which is layout-independent for those keys anyway.
static int arcade_map_key(WPARAM vk, LPARAM lparam) {
    switch (vk) {
        case VK_LEFT:   return ARCADE_KEY_LEFT;
        case VK_RIGHT:  return ARCADE_KEY_RIGHT;
        case VK_UP:     return ARCADE_KEY_UP;
        case VK_DOWN:   return ARCADE_KEY_DOWN;
        case VK_SPACE:  return ARCADE_KEY_SPACE;
        case VK_ESCAPE: return ARCADE_KEY_ESCAPE;
        case VK_RETURN: return ARCADE_KEY_ENTER;
        case VK_F1:     return ARCADE_KEY_F1;
        case VK_TAB:    return ARCADE_KEY_TAB;
        default: break;
    }

    switch ((lparam >> 16) & 0xFF) { // set-1 scan codes, US QWERTY positions
        case 0x11: return ARCADE_KEY_W;
        case 0x1E: return ARCADE_KEY_A;
        case 0x1F: return ARCADE_KEY_S;
        case 0x20: return ARCADE_KEY_D;
        case 0x30: return ARCADE_KEY_B;
        case 0x12: return ARCADE_KEY_E;
        case 0x21: return ARCADE_KEY_F;
        case 0x31: return ARCADE_KEY_N;
        case 0x10: return ARCADE_KEY_Q;
        case 0x19: return ARCADE_KEY_P;
        case 0x32: return ARCADE_KEY_M;
        case 0x2C: return ARCADE_KEY_Z;
        case 0x15: return ARCADE_KEY_Y;
        case 0x02: case 0x03: case 0x04: case 0x05: case 0x06: // main-row 1-9, in order
        case 0x07: case 0x08: case 0x09: case 0x0A:
            return ARCADE_KEY_1 + (int)(((lparam >> 16) & 0xFF) - 0x02);
        default:   return -1;
    }
}

// Modifiers arrive as ordinary key messages on Windows (unlike macOS's flagsChanged), but
// left/right variants and Alt's WM_SYSKEY* messages make reading the live state simpler and
// more reliable than tracking down/up pairs - so it's re-read on every key message instead.
static void arcade_update_modifiers(void) {
    s_key_down[ARCADE_KEY_SHIFT]   = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
    s_key_down[ARCADE_KEY_CONTROL] = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    s_key_down[ARCADE_KEY_OPTION]  = (GetKeyState(VK_MENU) & 0x8000) != 0;
    s_key_down[ARCADE_KEY_COMMAND] = ((GetKeyState(VK_LWIN) | GetKeyState(VK_RWIN)) & 0x8000) != 0;
    s_key_down[ARCADE_KEY_FN]      = false; // never visible to software on Windows
}

bool arcade_key_down(ArcadeKey key) {
    if (key < 0 || key >= ARCADE_KEY_COUNT) return false;
    return s_key_down[key];
}

bool arcade_key_pressed(ArcadeKey key) {
    if (key < 0 || key >= ARCADE_KEY_COUNT) return false;
    // The latch covers taps shorter than a frame; the edge covers modifiers, which are read from
    // live state (arcade_update_modifiers()) rather than latched.
    return s_key_tapped[key] || (s_key_down[key] && !s_key_down_prev[key]);
}

// ------------------------------------------------------------------------------------------
// Mouse state - same pattern as the keyboard, for pressed/released edge detection, with a
// latch for each direction so a click shorter than a frame still registers both edges.
// ------------------------------------------------------------------------------------------
static bool s_mouse_down[ARCADE_MOUSE_COUNT];
static bool s_mouse_down_prev[ARCADE_MOUSE_COUNT];
static bool s_mouse_tapped_down[ARCADE_MOUSE_COUNT];
static bool s_mouse_tapped_up[ARCADE_MOUSE_COUNT];
static int s_mouse_x = 0;
static int s_mouse_y = 0;

ArcadePoint arcade_mouse_position(void) {
    ArcadePoint p = { s_mouse_x, s_mouse_y };
    return p;
}

bool arcade_mouse_down(ArcadeMouseButton button) {
    if (button < 0 || button >= ARCADE_MOUSE_COUNT) return false;
    return s_mouse_down[button];
}

bool arcade_mouse_pressed(ArcadeMouseButton button) {
    if (button < 0 || button >= ARCADE_MOUSE_COUNT) return false;
    return s_mouse_tapped_down[button] || (s_mouse_down[button] && !s_mouse_down_prev[button]);
}

bool arcade_mouse_released(ArcadeMouseButton button) {
    if (button < 0 || button >= ARCADE_MOUSE_COUNT) return false;
    return s_mouse_tapped_up[button] || (!s_mouse_down[button] && s_mouse_down_prev[button]);
}

// End of a tick: this frame's state becomes "previous", and the latches are consumed.
static void arcade_input_end_frame(void) {
    memcpy(s_key_down_prev, s_key_down, sizeof(s_key_down));
    memcpy(s_mouse_down_prev, s_mouse_down, sizeof(s_mouse_down));
    memset(s_key_tapped, 0, sizeof(s_key_tapped));
    memset(s_mouse_tapped_down, 0, sizeof(s_mouse_tapped_down));
    memset(s_mouse_tapped_up, 0, sizeof(s_mouse_tapped_up));
}

// Wheel notches accumulate between frames and are snapshotted once per tick, like macOS. One
// notch (WHEEL_DELTA = 120) counts as 1.0 - the same scale a classic wheel mouse reports on
// macOS - positive away from the user, matching macOS without "natural scrolling".
static double s_scroll_accum = 0.0;
static double s_scroll_frame = 0.0;

double arcade_mouse_scroll_delta(void) {
    return s_scroll_frame;
}

// ------------------------------------------------------------------------------------------
// ArcadeWindow - the real struct behind the opaque handle in arcade_window.h.
// ------------------------------------------------------------------------------------------
struct ArcadeWindow {
    HWND hwnd;
    HDC hdc;                 // CS_OWNDC - kept for the window's whole lifetime
    ArcadeFramebuffer fb;    // what the game draws into (R,G,B,A per pixel)
    uint32_t *blit;          // the same frame converted to GDI's B,G,R,x layout
    BITMAPINFO bmi;
    int client_width;        // fb size * effective scale, in physical pixels
    int client_height;
    bool smooth;             // fractional scale factor - drawn with HALFTONE instead of nearest-neighbor
    ArcadeUpdateFn update;
    ArcadeRenderFn render;
    void *user_data;
    bool quit;
    HICON icon_big;          // resources\icons\<exe name>.ico, if there is one - see arcade_load_icons()
    HICON icon_small;
};

static const wchar_t *ARCADE_WINDOW_CLASS = L"ArcadeWindow";

// Sets the window's icon (title bar, taskbar, Alt+Tab) from resources\icons\<exe name>.ico next
// to the running .exe - e.g. ~\apps\maze-chomp\maze-chomp.exe loads
// ~\apps\maze-chomp\resources\icons\maze-chomp.ico. Read at runtime, not compiled into the binary:
// on macOS the icon lives in the .app bundle next to the binary too, never inside it.
// scripts\install.ps1 makes that .ico from resources\icons\<tool>.png on every install. No .ico
// (e.g. a build run straight from bin\, like a bare macOS binary outside its bundle) keeps the
// default icon - not an error.
static void arcade_load_icons(ArcadeWindow *window) {
    wchar_t path[MAX_PATH];
    DWORD len = GetModuleFileNameW(NULL, path, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) return;

    wchar_t *slash = wcsrchr(path, L'\\');
    if (!slash) return;
    wchar_t name[MAX_PATH];
    wcscpy(name, slash + 1);
    wchar_t *dot = wcsrchr(name, L'.');
    if (dot) *dot = L'\0';

    *(slash + 1) = L'\0';
    if (wcslen(path) + wcslen(L"resources\\icons\\") + wcslen(name) + wcslen(L".ico") >= MAX_PATH) return;
    wcscat(path, L"resources\\icons\\");
    wcscat(path, name);
    wcscat(path, L".ico");

    window->icon_big = (HICON)LoadImageW(NULL, path, IMAGE_ICON, GetSystemMetrics(SM_CXICON),
                                         GetSystemMetrics(SM_CYICON), LR_LOADFROMFILE);
    window->icon_small = (HICON)LoadImageW(NULL, path, IMAGE_ICON, GetSystemMetrics(SM_CXSMICON),
                                           GetSystemMetrics(SM_CYSMICON), LR_LOADFROMFILE);
    if (window->icon_big) SendMessageW(window->hwnd, WM_SETICON, ICON_BIG, (LPARAM)window->icon_big);
    if (window->icon_small) SendMessageW(window->hwnd, WM_SETICON, ICON_SMALL, (LPARAM)window->icon_small);
}

// Converts the game's framebuffer into GDI's layout and stretches it onto the window -
// nearest-neighbor (COLORONCOLOR) at a whole scale factor, so every game pixel stays a crisp
// square; smoothed (HALFTONE) at a fractional one, where nearest-neighbor would make some game
// pixels one screen pixel wide and others two.
static void arcade_present(ArcadeWindow *w) {
    if (!w->fb.pixels || !w->blit) return;

    int count = w->fb.width * w->fb.height;
    for (int i = 0; i < count; i++) {
        uint32_t p = w->fb.pixels[i]; // memory R,G,B,A -> value 0xAABBGGRR
        w->blit[i] = ((p & 0x000000FFu) << 16) | (p & 0x0000FF00u) | ((p >> 16) & 0x000000FFu);
    }

    if (w->smooth) {
        SetStretchBltMode(w->hdc, HALFTONE);
        SetBrushOrgEx(w->hdc, 0, 0, NULL); // HALFTONE requires resetting the brush origin
    } else {
        SetStretchBltMode(w->hdc, COLORONCOLOR);
    }
    StretchDIBits(w->hdc, 0, 0, w->client_width, w->client_height,
                  0, 0, w->fb.width, w->fb.height, w->blit, &w->bmi, DIB_RGB_COLORS, SRCCOPY);
}

// Client-area pixel position -> framebuffer pixel. The framebuffer is top-down like the client
// area, so unlike macOS there's no Y flip - just the scale divided out.
static void arcade_update_mouse_position(ArcadeWindow *w, LPARAM lparam) {
    int x = (short)LOWORD(lparam);
    int y = (short)HIWORD(lparam);
    s_mouse_x = w->client_width  > 0 ? x * w->fb.width  / w->client_width  : x;
    s_mouse_y = w->client_height > 0 ? y * w->fb.height / w->client_height : y;
}

static void arcade_release_all_input(void) {
    memset(s_key_down, 0, sizeof(s_key_down));
    memset(s_mouse_down, 0, sizeof(s_mouse_down));
    memset(s_key_tapped, 0, sizeof(s_key_tapped));
    memset(s_mouse_tapped_down, 0, sizeof(s_mouse_tapped_down));
}

static LRESULT CALLBACK arcade_window_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    ArcadeWindow *w = (ArcadeWindow *)GetWindowLongPtrW(hwnd, GWLP_USERDATA);

    switch (msg) {
        case WM_KEYDOWN:
        case WM_SYSKEYDOWN: {
            int key = arcade_map_key(wparam, lparam);
            debug_info_tag("input,keyboard", "keyDown      vk=0x%02x  scan=0x%02x",
                           (unsigned)wparam, (unsigned)((lparam >> 16) & 0xFF));
            if (key >= 0) {
                s_key_down[key] = true;
                if (!(lparam & (1L << 30))) s_key_tapped[key] = true; // bit 30 set = auto-repeat
            }
            arcade_update_modifiers();
            // Alt (and F10) arrive as WM_SYSKEYDOWN; handing those to DefWindowProc opens the
            // window menu and freezes the game loop. Only Alt+F4 keeps its usual meaning.
            if (msg == WM_SYSKEYDOWN && wparam == VK_F4) break;
            return 0;
        }
        case WM_KEYUP:
        case WM_SYSKEYUP: {
            int key = arcade_map_key(wparam, lparam);
            debug_info_tag("input,keyboard", "keyUp        vk=0x%02x", (unsigned)wparam);
            if (key >= 0) s_key_down[key] = false;
            arcade_update_modifiers();
            return 0;
        }
        case WM_SYSCHAR: // swallow the beep a bare Alt+letter would otherwise make
            return 0;

        case WM_MOUSEMOVE:
            if (w) arcade_update_mouse_position(w, lparam);
            return 0;
        case WM_LBUTTONDOWN:
        case WM_RBUTTONDOWN:
            // Capture keeps mouse messages coming while a button is held outside the window -
            // the equivalent of macOS's mouseDragged: (a scrollbar drag that leaves the window).
            SetCapture(hwnd);
            if (w) arcade_update_mouse_position(w, lparam);
            s_mouse_down[msg == WM_LBUTTONDOWN ? ARCADE_MOUSE_LEFT : ARCADE_MOUSE_RIGHT] = true;
            s_mouse_tapped_down[msg == WM_LBUTTONDOWN ? ARCADE_MOUSE_LEFT : ARCADE_MOUSE_RIGHT] = true;
            debug_info_tag("input,mouse", "mouseDown    fb=(%d,%d)", s_mouse_x, s_mouse_y);
            return 0;
        case WM_LBUTTONUP:
        case WM_RBUTTONUP:
            if (w) arcade_update_mouse_position(w, lparam);
            s_mouse_down[msg == WM_LBUTTONUP ? ARCADE_MOUSE_LEFT : ARCADE_MOUSE_RIGHT] = false;
            s_mouse_tapped_up[msg == WM_LBUTTONUP ? ARCADE_MOUSE_LEFT : ARCADE_MOUSE_RIGHT] = true;
            if (!s_mouse_down[ARCADE_MOUSE_LEFT] && !s_mouse_down[ARCADE_MOUSE_RIGHT]) ReleaseCapture();
            debug_info_tag("input,mouse", "mouseUp      fb=(%d,%d)", s_mouse_x, s_mouse_y);
            return 0;
        case WM_MOUSEWHEEL:
            s_scroll_accum += (double)GET_WHEEL_DELTA_WPARAM(wparam) / (double)WHEEL_DELTA;
            debug_verbose_tag("input,mouse", "scrollWheel  delta=%d", (int)GET_WHEEL_DELTA_WPARAM(wparam));
            return 0;

        case WM_KILLFOCUS:
            arcade_release_all_input();
            return 0;

        case WM_PAINT: {
            PAINTSTRUCT ps;
            BeginPaint(hwnd, &ps);
            if (w) arcade_present(w);
            EndPaint(hwnd, &ps);
            return 0;
        }
        case WM_ERASEBKGND:
            return 1; // the framebuffer covers the whole client area - no flicker from erasing

        case WM_CLOSE:
            if (w) w->quit = true; // arcade_window_destroy() destroys the window itself
            return 0;
        default:
            break;
    }
    return DefWindowProcW(hwnd, msg, wparam, lparam);
}

// The display's exact scale factor (1.0 at 100%, 1.25 at 125%, 2.0 at 200%). Needs the process
// to be DPI-aware first; see arcade_window_create().
static double arcade_display_scale(void) {
    HDC screen = GetDC(NULL);
    int dpi = GetDeviceCaps(screen, LOGPIXELSX);
    ReleaseDC(NULL, screen);
    double scale = dpi / 96.0;
    return scale < 1.0 ? 1.0 : scale;
}

// How many screen pixels one game pixel becomes: pixel_scale times the display scaling, so the
// game is as big as every other app on that screen - unless that window wouldn't fit the work
// area (screen minus taskbar), in which case the largest whole factor that does fit. A whole
// factor keeps nearest-neighbor's crisp pixels, so it's preferred over a fractional squeeze.
static double arcade_choose_scale(int width, int height, int pixel_scale, DWORD style, const RECT *work) {
    double want = pixel_scale * arcade_display_scale();

    RECT frame = { 0, 0, 0, 0 };
    AdjustWindowRect(&frame, style, FALSE); // title bar + borders at this DPI
    double fit_w = (double)((work->right - work->left) - (frame.right - frame.left)) / width;
    double fit_h = (double)((work->bottom - work->top) - (frame.bottom - frame.top)) / height;
    double fit = fit_w < fit_h ? fit_w : fit_h;

    if (want <= fit) return want;
    double whole = floor(fit);
    return whole < 1.0 ? 1.0 : whole; // never below one screen pixel per game pixel
}

ArcadeWindow *arcade_window_create(const char *title, int width, int height, int pixel_scale) {
    if (width <= 0 || height <= 0 || pixel_scale <= 0) return NULL;

    // Without this, Windows pretends to be 96 DPI and then bitmap-stretches the whole window on a
    // high-DPI screen - blurring every pixel. Vista+ API; harmless if already set.
    SetProcessDPIAware();

    ArcadeWindow *window = calloc(1, sizeof(ArcadeWindow));
    if (!window) return NULL;

    window->fb.width = width;
    window->fb.height = height;
    window->fb.pixels = calloc((size_t)width * (size_t)height, sizeof(uint32_t));
    window->blit = calloc((size_t)width * (size_t)height, sizeof(uint32_t));
    if (!window->fb.pixels || !window->blit) {
        free(window->fb.pixels);
        free(window->blit);
        free(window);
        return NULL;
    }

    window->bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    window->bmi.bmiHeader.biWidth = width;
    window->bmi.bmiHeader.biHeight = -height; // negative = top-down rows, like the framebuffer
    window->bmi.bmiHeader.biPlanes = 1;
    window->bmi.bmiHeader.biBitCount = 32;
    window->bmi.bmiHeader.biCompression = BI_RGB;

    // Fixed size, like the macOS window: title bar, close and minimize, no resize/maximize.
    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
    RECT work;
    if (!SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0)) {
        SetRect(&work, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
    }

    double scale = arcade_choose_scale(width, height, pixel_scale, style, &work);
    window->client_width = (int)lround(width * scale);
    window->client_height = (int)lround(height * scale);
    window->smooth = fabs(scale - lround(scale)) > 1e-6;

    HINSTANCE instance = GetModuleHandleW(NULL);
    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(wc);
    wc.style = CS_OWNDC;
    wc.lpfnWndProc = arcade_window_proc;
    wc.hInstance = instance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpszClassName = ARCADE_WINDOW_CLASS;
    RegisterClassExW(&wc); // fails harmlessly if a previous window already registered it

    RECT rect = { 0, 0, window->client_width, window->client_height };
    AdjustWindowRect(&rect, style, FALSE);
    int outer_w = rect.right - rect.left;
    int outer_h = rect.bottom - rect.top;
    int x = work.left + ((work.right - work.left) - outer_w) / 2; // centered above the taskbar
    int y = work.top + ((work.bottom - work.top) - outer_h) / 2;
    if (x < work.left) x = work.left;
    if (y < work.top) y = work.top;

    wchar_t wtitle[256];
    if (!MultiByteToWideChar(CP_UTF8, 0, title ? title : "arcade", -1, wtitle, 256)) {
        wcscpy(wtitle, L"arcade");
    }

    window->hwnd = CreateWindowExW(0, ARCADE_WINDOW_CLASS, wtitle, style, x, y, outer_w, outer_h,
                                   NULL, NULL, instance, NULL);
    if (!window->hwnd) {
        free(window->fb.pixels);
        free(window->blit);
        free(window);
        return NULL;
    }
    SetWindowLongPtrW(window->hwnd, GWLP_USERDATA, (LONG_PTR)window);
    window->hdc = GetDC(window->hwnd);
    arcade_load_icons(window);

    ShowWindow(window->hwnd, SW_SHOW);
    SetForegroundWindow(window->hwnd);
    return window;
}

void arcade_window_run(ArcadeWindow *window, ArcadeUpdateFn update, ArcadeRenderFn render, void *user_data) {
    if (!window) return;

    window->update = update;
    window->render = render;
    window->user_data = user_data;
    window->quit = false;

    LARGE_INTEGER freq, last, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&last);
    double frame_time = 1.0 / ARCADE_TARGET_FPS;
    double next_frame = (double)last.QuadPart / (double)freq.QuadPart + frame_time;

    timeBeginPeriod(1); // Sleep(1) really sleeps ~1 ms instead of the default ~15.6 ms

    while (!window->quit) {
        MSG msg;
        while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        if (window->quit) break;

        QueryPerformanceCounter(&now);
        double dt = (double)(now.QuadPart - last.QuadPart) / (double)freq.QuadPart;
        last = now;
        if (dt > 0.25) dt = 0.25; // clamp after a stall (e.g. a breakpoint) so games don't jump

        s_scroll_frame = s_scroll_accum;
        s_scroll_accum = 0.0;

        if (window->update) window->update(window->user_data, dt);
        if (window->render) window->render(window->user_data, &window->fb);
        arcade_present(window);
        arcade_input_end_frame(); // after update(), so it saw this frame's edges

        // Pace to ~60Hz: sleep most of the remaining time, then spin the last millisecond. If a
        // frame ran long, resync instead of trying to catch up with a burst of frames.
        for (;;) {
            QueryPerformanceCounter(&now);
            double t = (double)now.QuadPart / (double)freq.QuadPart;
            double remaining = next_frame - t;
            if (remaining <= 0.0) {
                next_frame = (remaining < -frame_time) ? t + frame_time : next_frame + frame_time;
                break;
            }
            if (remaining > 0.002) Sleep((DWORD)((remaining - 0.001) * 1000.0));
        }
    }

    timeEndPeriod(1);
}

void arcade_window_request_quit(ArcadeWindow *window) {
    if (window) window->quit = true;
}

void arcade_window_destroy(ArcadeWindow *window) {
    if (!window) return;
    if (window->hwnd) {
        SetWindowLongPtrW(window->hwnd, GWLP_USERDATA, 0);
        if (window->hdc) ReleaseDC(window->hwnd, window->hdc);
        DestroyWindow(window->hwnd);
    }
    if (window->icon_big) DestroyIcon(window->icon_big);
    if (window->icon_small) DestroyIcon(window->icon_small);
    free(window->fb.pixels);
    free(window->blit);
    free(window);
}

#endif // _WIN32

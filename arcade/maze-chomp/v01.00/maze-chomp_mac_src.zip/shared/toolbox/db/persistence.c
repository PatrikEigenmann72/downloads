/* -------------------------------------------------------------------------------------------
 * persistence.c - Implements persistence.h: the flat-file database.
 * -------------------------------------------------------------------------------------------
 * Author:      Patrik Eigenmann
 * eMail:       p.eigenmann72@gmail.com
 * -------------------------------------------------------------------------------------------
 * Change Log:
 * Sun 2026-10-11 File created.                                                   Version: 00.01
 * ------------------------------------------------------------------------------------------- */
#include "persistence.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "platform.h" // mkdir() on Windows - last, after every system header

// ------------------------------------------------------------------------------------------
// Records.
// ------------------------------------------------------------------------------------------
static void record_free(PersistenceRecord *r) {
    for (int i = 0; i < r->field_count; i++) free(r->fields[i]);
    free(r->fields);
    r->fields = NULL;
    r->field_count = 0;
}

static bool record_fill(PersistenceRecord *r, const char *const *fields, int field_count) {
    r->fields = field_count > 0 ? calloc((size_t)field_count, sizeof(char *)) : NULL;
    r->field_count = 0;
    if (field_count > 0 && !r->fields) return false;
    for (int i = 0; i < field_count; i++) {
        const char *src = fields[i] ? fields[i] : "";
        r->fields[i] = malloc(strlen(src) + 1);
        if (!r->fields[i]) { record_free(r); return false; }
        strcpy(r->fields[i], src);
        r->field_count++;
    }
    return true;
}

static bool grow(Persistence *p) {
    if (p->count < p->capacity) return true;
    int capacity = p->capacity ? p->capacity * 2 : 64;
    PersistenceRecord *grown = realloc(p->records, (size_t)capacity * sizeof(*grown));
    if (!grown) return false;
    p->records = grown;
    p->capacity = capacity;
    return true;
}

// ------------------------------------------------------------------------------------------
// Escaping - a field may hold any text; TAB and line breaks would otherwise break the format.
// ------------------------------------------------------------------------------------------
static void write_escaped(FILE *f, const char *s) {
    for (; *s; s++) {
        switch (*s) {
            case '\\': fputs("\\\\", f); break;
            case '\t': fputs("\\t", f); break;
            case '\n': fputs("\\n", f); break;
            case '\r': fputs("\\r", f); break;
            default:   fputc(*s, f); break;
        }
    }
}

// Undoes write_escaped() in place (the result is never longer than the input).
static void unescape(char *s) {
    char *out = s;
    for (; *s; s++) {
        if (*s == '\\' && s[1]) {
            s++;
            *out++ = *s == 't' ? '\t' : *s == 'n' ? '\n' : *s == 'r' ? '\r' : *s; // '\\' -> '\'
        } else {
            *out++ = *s;
        }
    }
    *out = '\0';
}

// Splits one line into TAB-separated fields and appends it as a record.
static bool append_line(Persistence *p, char *line) {
    int field_count = 1;
    for (char *c = line; *c; c++) if (*c == '\t') field_count++;

    char **fields = malloc((size_t)field_count * sizeof(char *));
    if (!fields) return false;
    int n = 0;
    char *start = line;
    for (char *c = line;; c++) {
        if (*c == '\t' || *c == '\0') {
            bool last = *c == '\0';
            *c = '\0';
            unescape(start);
            fields[n++] = start;
            if (last) break;
            start = c + 1;
        }
    }
    bool ok = persistence_append(p, (const char *const *)fields, n) >= 0;
    free(fields);
    return ok;
}

// ------------------------------------------------------------------------------------------
// Files.
// ------------------------------------------------------------------------------------------

// Reads one whole line of any length (fgets() alone would split long ones). Caller frees.
static char *read_line(FILE *f) {
    size_t cap = 256, len = 0;
    char *buf = malloc(cap);
    if (!buf) return NULL;
    int ch;
    while ((ch = fgetc(f)) != EOF && ch != '\n') {
        if (len + 1 >= cap) {
            char *grown = realloc(buf, cap * 2);
            if (!grown) { free(buf); return NULL; }
            buf = grown;
            cap *= 2;
        }
        buf[len++] = (char)ch;
    }
    if (ch == EOF && len == 0) { free(buf); return NULL; }
    if (len > 0 && buf[len - 1] == '\r') len--; // a file edited on Windows
    buf[len] = '\0';
    return buf;
}

// Creates the folder part of path (e.g. "data" for "data/leaderboard.dat") - one level.
static void ensure_parent_dir(const char *path) {
    char dir[PERSISTENCE_PATH_MAX];
    snprintf(dir, sizeof(dir), "%s", path);
    char *slash = strrchr(dir, '/');
    char *backslash = strrchr(dir, '\\');
    if (backslash && (!slash || backslash > slash)) slash = backslash;
    if (!slash || slash == dir) return;
    *slash = '\0';
    mkdir(dir, 0755); // an existing folder is fine
}

// See persistence.h for the full contract.
bool persistence_open(Persistence *p, const char *path) {
    memset(p, 0, sizeof(*p));
    if (!path || strlen(path) >= sizeof(p->path)) return false;
    snprintf(p->path, sizeof(p->path), "%s", path);

    FILE *f = fopen(path, "rb");
    if (!f) return true; // no file yet - an empty database

    bool ok = true;
    char *line;
    while (ok && (line = read_line(f)) != NULL) {
        if (line[0] != '#' && line[0] != '\0') ok = append_line(p, line);
        free(line);
    }
    fclose(f);
    return ok;
}

// See persistence.h for the full contract.
bool persistence_save(Persistence *p, const char *header) {
    ensure_parent_dir(p->path);
    char tmp[PERSISTENCE_PATH_MAX + 8];
    snprintf(tmp, sizeof(tmp), "%s.tmp", p->path);

    FILE *f = fopen(tmp, "wb"); // binary: LF line endings on every platform, identical bytes everywhere
    if (!f) return false;
    if (header && header[0]) fprintf(f, "# %s\n", header);
    for (int i = 0; i < p->count; i++) {
        const PersistenceRecord *r = &p->records[i];
        for (int k = 0; k < r->field_count; k++) {
            if (k > 0) fputc('\t', f);
            write_escaped(f, r->fields[k]);
        }
        fputc('\n', f);
    }
    bool ok = fclose(f) == 0;
    if (!ok) { remove(tmp); return false; }

    remove(p->path); // Windows' rename() won't replace an existing file
    return rename(tmp, p->path) == 0;
}

// See persistence.h for the full contract.
void persistence_close(Persistence *p) {
    persistence_clear(p);
    free(p->records);
    p->records = NULL;
    p->capacity = 0;
}

// ------------------------------------------------------------------------------------------
// Access.
// ------------------------------------------------------------------------------------------
int persistence_count(const Persistence *p) { return p->count; }

int persistence_field_count(const Persistence *p, int index) {
    return (index >= 0 && index < p->count) ? p->records[index].field_count : 0;
}

const char *persistence_get(const Persistence *p, int index, int field) {
    if (index < 0 || index >= p->count) return NULL;
    const PersistenceRecord *r = &p->records[index];
    return (field >= 0 && field < r->field_count) ? r->fields[field] : NULL;
}

int persistence_append(Persistence *p, const char *const *fields, int field_count) {
    if (!grow(p)) return -1;
    if (!record_fill(&p->records[p->count], fields, field_count)) return -1;
    return p->count++;
}

bool persistence_replace(Persistence *p, int index, const char *const *fields, int field_count) {
    if (index < 0 || index >= p->count) return false;
    PersistenceRecord fresh;
    if (!record_fill(&fresh, fields, field_count)) return false;
    record_free(&p->records[index]);
    p->records[index] = fresh;
    return true;
}

void persistence_remove(Persistence *p, int index) {
    if (index < 0 || index >= p->count) return;
    record_free(&p->records[index]);
    memmove(&p->records[index], &p->records[index + 1], (size_t)(p->count - index - 1) * sizeof(*p->records));
    p->count--;
}

void persistence_clear(Persistence *p) {
    for (int i = 0; i < p->count; i++) record_free(&p->records[i]);
    p->count = 0;
}

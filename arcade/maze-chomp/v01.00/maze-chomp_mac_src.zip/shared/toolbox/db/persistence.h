/* -------------------------------------------------------------------------------------------
 * persistence.h - A flat-file database: records of text fields, one record per line, kept in
 * memory while open and written back as a whole. The mechanism only - it knows nothing about
 * what the records mean. Which fields a record has, how many records are allowed, what's valid:
 * all of that is the calling module's business (arcade_leaderboard, a legacy app's presets, ...).
 *
 * File format, deliberately plain:
 *   - one record per line, fields separated by a TAB;
 *   - lines starting with '#' are comments - skipped on load; save() writes an optional header
 *     comment at the top;
 *   - inside a field, a backslash, TAB, newline or carriage return is written as \\, \t, \n, \r,
 *     so any text survives the round trip (a company name with spaces, a note with line breaks).
 *
 * persistence_save() writes the whole file to "<path>.tmp" first and only then replaces the real
 * file, so a crash mid-write leaves the previous file intact. The folder the file lives in is
 * created on the first save if it's missing (one level, e.g. "data/").
 *
 * No dependencies beyond the C library and toolbox/platform.h - no SQLite, nothing to install.
 * -------------------------------------------------------------------------------------------
 * Author:      Patrik Eigenmann
 * eMail:       p.eigenmann72@gmail.com
 * -------------------------------------------------------------------------------------------
 * Change Log:
 * Sun 2026-10-11 File created - the flat-file database behind the arcade         Version: 00.01
 *                leaderboard (leaderboard.dat/settings.dat), usable by any
 *                toolbox user, legacy included.
 * ------------------------------------------------------------------------------------------- */
#ifndef PERSISTENCE_H
#define PERSISTENCE_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PERSISTENCE_PATH_MAX 512

// One record: an array of field strings (each owned by the record).
typedef struct {
    char **fields;
    int field_count;
} PersistenceRecord;

// An open flat file: its path and every record, in file order.
typedef struct {
    char path[PERSISTENCE_PATH_MAX];
    PersistenceRecord *records;
    int count;
    int capacity;
} Persistence;

// Opens path and reads every record into memory. A missing file is not an error - it's an empty
// database that save() will create.
//
// @return false only if path is NULL/too long, or memory ran out.
bool persistence_open(Persistence *p, const char *path);

// Writes every record back to the file (atomically, through "<path>.tmp").
//
// @param header  Comment written at the top as "# <header>" - NULL or "" for none.
// @return        false if the file couldn't be written.
bool persistence_save(Persistence *p, const char *header);

// Frees every record. The file itself is untouched - save() first if the changes should last.
void persistence_close(Persistence *p);

// Number of records currently held.
int persistence_count(const Persistence *p);

// Number of fields in record index, or 0 if index is out of range.
int persistence_field_count(const Persistence *p, int index);

// Field field of record index, or NULL if either is out of range. Owned by the record - valid until
// the record is removed, the database cleared, or closed.
const char *persistence_get(const Persistence *p, int index, int field);

// Appends a record holding copies of fields[0..field_count-1].
//
// @return The new record's index, or -1 if memory ran out.
int persistence_append(Persistence *p, const char *const *fields, int field_count);

// Replaces record index with copies of fields[0..field_count-1].
//
// @return false if index is out of range or memory ran out.
bool persistence_replace(Persistence *p, int index, const char *const *fields, int field_count);

// Removes record index; the records after it move up one.
void persistence_remove(Persistence *p, int index);

// Removes every record (in memory - save() to make it permanent).
void persistence_clear(Persistence *p);

#ifdef __cplusplus
}
#endif

#endif // PERSISTENCE_H

// -----------------------------------------------------------------------------------------------
// pictures.h - Loads an image file (PNG, JPEG, BMP, and anything else stb_image.h understands)
// into a plain RGBA8 pixel buffer in memory, decoded once up front - not a renderer, not tied to
// any window system. Pair this with whatever puts pixels on screen (the arcade engine's
// framebuffer, Tone3's own drawing code, ...) the same way audio.h's AudioSampleFn is paired with
// a generator - this module only decodes, it never draws.
//
// Uses stb_image.h (public domain, vendored in this folder - see its own header for the license)
// rather than a hand-rolled decoder: a correct PNG decoder means implementing zlib/DEFLATE plus
// PNG's own filtering, real surface area for a single-purpose loader to get wrong and maintain.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-10-11 File created.                                                     Version: 00.01
// -----------------------------------------------------------------------------------------------
#ifndef SHARED_PICTURES_H
#define SHARED_PICTURES_H

#ifdef __cplusplus
extern "C" {
#endif

// A decoded image, always normalized to 4 channels (RGBA, 8 bits/channel) regardless of the
// source file's own format - a fully opaque PNG still gets an alpha channel, filled with 255, so
// calling code never has to branch on channel count.
typedef struct {
    int width;
    int height;
    unsigned char *pixels; // width * height * 4 bytes, row-major, top row first, RGBA per pixel
} Picture;

// Decodes an image file into pic. PNG, JPEG, or BMP (pictures.c restricts stb_image.h to just
// these three via STBI_ONLY_* - GIF/TGA/PSD/HDR/PIC/PNM support is compiled out, unneeded surface
// area for this project) - the file's own header bytes decide how it's decoded, not its
// extension.
//
// @param pic   Filled in on success; untouched on failure.
// @param path  Path to the image file.
// @return 0 on success, -1 on failure (file missing, or not a format stb_image recognizes).
int picture_load(Picture *pic, const char *path);

// Releases the pixel buffer. Safe to call on a Picture that failed to load (pixels is NULL).
void picture_free(Picture *pic);

#ifdef __cplusplus
}
#endif

#endif // SHARED_PICTURES_H

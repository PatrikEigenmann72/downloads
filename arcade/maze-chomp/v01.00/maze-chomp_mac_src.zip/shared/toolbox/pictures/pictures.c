// -----------------------------------------------------------------------------------------------
// pictures.c - Implements pictures.h. The only file in this project that defines
// STB_IMAGE_IMPLEMENTATION - stb_image.h is a pure header everywhere else it's included, this is
// the one translation unit where its actual code gets compiled in.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-10-11 File created.                                                     Version: 00.01
// -----------------------------------------------------------------------------------------------
#include "pictures.h"

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#define STBI_ONLY_BMP
#include "stb_image.h"

// @return 0 on success, -1 on failure (file missing, or not PNG/JPEG/BMP).
int picture_load(Picture *pic, const char *path) {
    int channels_in_file;

    // Forcing 4 channels (the trailing "4" below) means pic->pixels is always RGBA, whether the
    // source file was indexed-color, grayscale, or already RGBA - no per-format branching for
    // whatever reads this buffer afterward.
    pic->pixels = stbi_load(path, &pic->width, &pic->height, &channels_in_file, 4);
    if (!pic->pixels) {
        pic->width = 0;
        pic->height = 0;
        return -1;
    }
    return 0;
}

void picture_free(Picture *pic) {
    if (pic->pixels) {
        stbi_image_free(pic->pixels);
        pic->pixels = NULL;
    }
    pic->width = 0;
    pic->height = 0;
}

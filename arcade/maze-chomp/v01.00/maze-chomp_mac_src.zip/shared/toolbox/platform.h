// ****************************************************************************************************
// platform.h — Platform‑specific compatibility layer for the Samael toolbox and all dependent modules.
//
// This file exists because Windows (MSVC / MinGW) diverges from POSIX in several small but annoying
// ways — most notably the use of `_strdup()` instead of `strdup()`. Rather than scattering conditional
// fixes across dozens of .c files, this header centralizes all OS‑specific quirks in one place.
//
// The philosophy matches the rest of the terminal ecosystem: clarity, locality, and explicit intent.
// No magic, no hidden behavior, no silent fallbacks. If a platform needs a fix, it is declared here,
// visibly, with a versioned change log and authorship — exactly the same discipline applied everywhere
// else in this codebase.
//
// This header is included only in .c files that require platform‑specific behavior. It is not a global
// dependency and does not flatten the include hierarchy. Each module remains self‑contained.
// ----------------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// ----------------------------------------------------------------------------------------------------
// Sat 2026-10-10 Initial creation. Centralized Windows strdup() fix. No other platform   Version 00.01
//                quirks yet. Sidecar changelog created: platform.changelog.txt.
// Sat 2026-10-10 Declare _strdup() under __STRICT_ANSI__ (-std=c99 hides it in MinGW's   Version 00.02
//                <string.h>), fixing implicit-declaration and int-conversion warnings.
// Sat 2026-10-10 <malloc.h> moved inside the Windows block - macOS has no <malloc.h>, so   Version 00.03
//                every Mac build including this header failed. Added three quirks found
//                porting legacy/cobs to Windows: PLATFORM_HOME_ENV (Windows has
//                USERPROFILE, not HOME), two-argument mkdir() (Windows' takes no mode), and
//                localtime_r() (Windows has localtime_s(), arguments swapped).
// Sat 2026-10-10 The _strdup() declaration is now only made on the old MinGW.org          Version 00.04
//                toolchain - MinGW-w64 (MSYS2) declares it itself even under -std=c99,
//                and our plain redeclaration warned "redeclared without dllimport".
// Sat 2026-10-10 Declares platform_documents_dir(), implemented in the new platform.c    Version 00.05
//                (not here - it needs <windows.h>, which collides with PDCurses). Use it
//                instead of building <home>/Documents by hand: Windows lets the user move
//                Documents (D:\Documents here, OneDrive elsewhere).
// Sun 2026-10-11 The storage standard (STORAGE.md): platform_bundle_dir(),             Version 00.06
//                platform_enter_bundle_dir(), platform_app_data_dir(),
//                platform_cache_dir(), platform_seed_file() - the bundle stays
//                read-only, app data/local app data take what a program writes,
//                factory defaults are seeded on first run.
// ****************************************************************************************************

#ifndef PLATFORM_H
#define PLATFORM_H

#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <stdbool.h>

#ifdef _WIN32
#include <malloc.h>
#include <direct.h>

// -std=c99 defines __STRICT_ANSI__, which makes the old MinGW.org <string.h> hide _strdup().
// Without a prototype the compiler assumes it returns int, so every strdup() result triggers
// warnings. MinGW-w64 (__MINGW64_VERSION_MAJOR, set by <string.h>'s own <_mingw.h>) always
// declares it, as a dllimport - declaring it again there only adds a warning of its own.
#if defined(__STRICT_ANSI__) && !defined(__MINGW64_VERSION_MAJOR)
char *_strdup(const char *s);
#endif
#define strdup _strdup

// The environment variable holding the user's home folder - use getenv(PLATFORM_HOME_ENV) instead
// of getenv("HOME"), which is usually unset on Windows outside of Git Bash/MSYS2.
#define PLATFORM_HOME_ENV "USERPROFILE"

// POSIX mkdir(path, mode) - Windows' mkdir() takes only the path and has no permission bits, so
// mode is dropped. Defined after <direct.h>, whose own one-argument declaration it would break.
#define mkdir(path, mode) _mkdir(path)

// POSIX localtime_r(time, result) - Windows' thread-safe equivalent is localtime_s(result, time),
// arguments swapped and returning an error code instead of the result pointer. MinGW-w64 only
// provides localtime_r itself when _POSIX_THREAD_SAFE_FUNCTIONS is defined.
#ifndef _POSIX_THREAD_SAFE_FUNCTIONS
#define localtime_r(time, result) (localtime_s((result), (time)) == 0 ? (result) : NULL)
#endif

#else
#define PLATFORM_HOME_ENV "HOME"
#endif

// The user's Documents folder, without a trailing separator - on Windows the real known folder
// (follows a relocation such as D:\Documents, or a OneDrive redirect), elsewhere <home>/Documents.
// Never build "<home>/Documents" by hand on Windows: that folder may not exist at all.
// Implemented in platform.c - a build calling this must compile that file too.
//
// @return A static buffer, resolved on the first call - copy it if you need to modify it.
const char *platform_documents_dir(void);

// ------------------------------------------------------------------------------------------------
// Storage standard (see STORAGE.md next to this file): what ships stays read-only in the bundle,
// what a program writes goes to the user's own folders. All implemented in platform.c.
// ------------------------------------------------------------------------------------------------

// The bundle: the folder holding the program's binary next to its resources/ folder (Windows
// install folder, inside a macOS .app, ...). If the binary has no resources/ beside it - running
// from a source tree during development - the current folder is the bundle.
//
// @return A static buffer, resolved on the first call, no trailing separator.
const char *platform_bundle_dir(void);

// Makes the bundle the current folder, so relative "resources/..." paths work however the program
// was started (a shortcut, Finder - which starts apps in "/" - or a terminal anywhere). Call first
// thing in main() of a GUI/TUI app; never in a command-line tool that works on the user's files.
//
// @return false if the folder couldn't be entered (the current folder is left as it was).
bool platform_enter_bundle_dir(void);

// The user's app-data folder for app (an id like "maze-chomp", never a display name), created if
// missing: %APPDATA%\<app> on Windows, ~/Library/Application Support/<app> on macOS,
// $XDG_DATA_HOME/<app> (default ~/.local/share/<app>) on Linux. Persistence lives here.
//
// @return A static buffer (one per function - the next call with another app overwrites it).
const char *platform_app_data_dir(const char *app);

// The user's local-app-data folder for app, created if missing: %LOCALAPPDATA%\<app> on Windows,
// ~/Library/Caches/<app> on macOS, $XDG_CACHE_HOME/<app> (default ~/.cache/<app>) on Linux.
// Caches, temporary files, browser profiles.
//
// @return A static buffer, like platform_app_data_dir().
const char *platform_cache_dir(const char *app);

// First-run seeding: copies default_src (a factory default in the bundle) to dest - but only if
// dest doesn't exist yet. A user's own file is never overwritten.
//
// @return true if dest exists afterwards (already there, or just copied).
bool platform_seed_file(const char *dest, const char *default_src);

#endif // PLATFORM_H

// ****************************************************************************************************
// platform.c — The parts of platform.h that can't live in a header.
//
// platform.h stays header-only on purpose (macros and declarations, no code to link), but asking an OS
// for a known folder needs real OS headers - and <windows.h> can't go into platform.h: it defines
// macros that collide with PDCurses (MOUSE_MOVED, for one), and legacy apps include both. So the
// implementation lives here, behind a plain C declaration in platform.h. Any build calling one of
// these functions has to compile this file too (see legacy/cobs/cobs*.pmake, legacy/tone3/tone3*.pmake).
// ----------------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// ----------------------------------------------------------------------------------------------------
// Sat 2026-10-10 Initial creation. platform_documents_dir() - asks Windows for the real   Version 00.01
//                Documents folder instead of assuming %USERPROFILE%\Documents.
// Sun 2026-10-11 The storage standard (STORAGE.md): platform_bundle_dir(),             Version 00.02
//                platform_enter_bundle_dir(), platform_app_data_dir(),
//                platform_cache_dir(), platform_seed_file().
// ****************************************************************************************************

#include "platform.h"

#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
#include <windows.h>
#include <shlobj.h>
#else
#include <limits.h>
#include <stdint.h>
#include <unistd.h>
#if defined(__APPLE__)
#include <mach-o/dyld.h>
#endif
#endif

#define PLATFORM_PATH_MAX 1024

// The native folder separator, for paths this file builds (Windows accepts '/', but a path shown
// to the user should look like one).
#ifdef _WIN32
#define PLATFORM_SEP "\\"
#else
#define PLATFORM_SEP "/"
#endif

// See platform.h for the full contract.
const char *platform_documents_dir(void) {
    static char path[1024];
    if (path[0] != '\0') return path; // resolved once - the folder doesn't move while we run

#ifdef _WIN32
    // CSIDL_PERSONAL is the Documents known folder - the same one Explorer opens, so it follows a
    // relocation (D:\Documents, say) or a OneDrive redirect. 0 = SHGFP_TYPE_CURRENT (the folder's
    // current location, not its default), written out because the old MinGW.org headers lack it.
    char buf[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_PERSONAL, NULL, 0, buf))) {
        snprintf(path, sizeof(path), "%s", buf);
        return path;
    }
#endif

    // Fallback, and the normal case on macOS/Linux: <home>/Documents.
    const char *home = getenv(PLATFORM_HOME_ENV);
    snprintf(path, sizeof(path), "%s/Documents", (home && home[0]) ? home : ".");
    return path;
}

// ------------------------------------------------------------------------------------------------
// Storage standard - see STORAGE.md and platform.h.
// ------------------------------------------------------------------------------------------------

static bool platform_is_dir(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && (st.st_mode & S_IFMT) == S_IFDIR;
}

// mkdir -p: creates every missing folder along path. Existing folders are fine.
static void platform_make_dirs(const char *path) {
    char buf[PLATFORM_PATH_MAX];
    snprintf(buf, sizeof(buf), "%s", path);
    for (char *p = buf + 1; *p; p++) {
        if (*p != '/' && *p != '\\') continue;
        if (*(p - 1) == ':') continue; // "C:\" itself
        char saved = *p;
        *p = '\0';
        mkdir(buf, 0755);
        *p = saved;
    }
    mkdir(buf, 0755);
}

// The folder holding this program's own binary, no trailing separator. "" if it can't be found.
static void platform_exe_dir(char *out, size_t out_len) {
    out[0] = '\0';
#ifdef _WIN32
    char exe[MAX_PATH];
    DWORD n = GetModuleFileNameA(NULL, exe, sizeof(exe));
    if (n == 0 || n >= sizeof(exe)) return;
#elif defined(__APPLE__)
    char raw[PLATFORM_PATH_MAX], exe[PLATFORM_PATH_MAX];
    uint32_t size = (uint32_t)sizeof(raw);
    if (_NSGetExecutablePath(raw, &size) != 0 || !realpath(raw, exe)) return;
#else
    char exe[PLATFORM_PATH_MAX];
    ssize_t n = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
    if (n <= 0) return;
    exe[n] = '\0';
#endif
    char *slash = strrchr(exe, '/');
    char *backslash = strrchr(exe, '\\');
    if (backslash && (!slash || backslash > slash)) slash = backslash;
    if (!slash) return;
    *slash = '\0';
    snprintf(out, out_len, "%s", exe);
}

// See platform.h for the full contract.
const char *platform_bundle_dir(void) {
    static char path[PLATFORM_PATH_MAX];
    if (path[0] != '\0') return path;

    // Installed: the binary sits next to its resources/ - a Windows install folder, inside a .app
    // (Contents/MacOS for GUI apps, Contents/Resources for the Terminal-wrapped ncurses ones).
    char exe_dir[PLATFORM_PATH_MAX], probe[PLATFORM_PATH_MAX + 16];
    platform_exe_dir(exe_dir, sizeof(exe_dir));
    if (exe_dir[0] != '\0') {
        snprintf(probe, sizeof(probe), "%s/resources", exe_dir);
        if (platform_is_dir(probe)) {
            snprintf(path, sizeof(path), "%s", exe_dir);
            return path;
        }
    }

    // Development: pmake's bin/ has no resources/ - the project folder the program was started
    // from is the bundle.
    if (!getcwd(path, sizeof(path))) snprintf(path, sizeof(path), ".");
    return path;
}

// See platform.h for the full contract.
bool platform_enter_bundle_dir(void) {
    return chdir(platform_bundle_dir()) == 0;
}

// <base>/<app>, created - the shared tail of platform_app_data_dir() and platform_cache_dir().
static const char *platform_user_dir(char *out, size_t out_len, const char *base, const char *app) {
    snprintf(out, out_len, "%s" PLATFORM_SEP "%s", base, (app && app[0]) ? app : "app");
    platform_make_dirs(out);
    return out;
}

#ifndef _WIN32
// $<xdg_var>, or <home>/<fallback> - the XDG base-directory rule, for Linux.
static void platform_xdg(char *out, size_t out_len, const char *xdg_var, const char *fallback) {
    const char *xdg = getenv(xdg_var);
    const char *home = getenv("HOME");
    if (xdg && xdg[0] == '/') snprintf(out, out_len, "%s", xdg);
    else snprintf(out, out_len, "%s/%s", (home && home[0]) ? home : ".", fallback);
}
#endif

// See platform.h for the full contract.
const char *platform_app_data_dir(const char *app) {
    static char path[PLATFORM_PATH_MAX];
    char base[PLATFORM_PATH_MAX];
#ifdef _WIN32
    if (FAILED(SHGetFolderPathA(NULL, CSIDL_APPDATA, NULL, 0, base))) { // %APPDATA% (roaming)
        const char *env = getenv("APPDATA");
        snprintf(base, sizeof(base), "%s", env ? env : ".");
    }
#elif defined(__APPLE__)
    const char *home = getenv("HOME");
    snprintf(base, sizeof(base), "%s/Library/Application Support", (home && home[0]) ? home : ".");
#else
    platform_xdg(base, sizeof(base), "XDG_DATA_HOME", ".local/share");
#endif
    return platform_user_dir(path, sizeof(path), base, app);
}

// See platform.h for the full contract.
const char *platform_cache_dir(const char *app) {
    static char path[PLATFORM_PATH_MAX];
    char base[PLATFORM_PATH_MAX];
#ifdef _WIN32
    if (FAILED(SHGetFolderPathA(NULL, CSIDL_LOCAL_APPDATA, NULL, 0, base))) { // %LOCALAPPDATA%
        const char *env = getenv("LOCALAPPDATA");
        snprintf(base, sizeof(base), "%s", env ? env : ".");
    }
#elif defined(__APPLE__)
    const char *home = getenv("HOME");
    snprintf(base, sizeof(base), "%s/Library/Caches", (home && home[0]) ? home : ".");
#else
    platform_xdg(base, sizeof(base), "XDG_CACHE_HOME", ".cache");
#endif
    return platform_user_dir(path, sizeof(path), base, app);
}

// See platform.h for the full contract.
bool platform_seed_file(const char *dest, const char *default_src) {
    FILE *existing = fopen(dest, "rb");
    if (existing) { fclose(existing); return true; } // the user's own file - never overwritten

    FILE *in = fopen(default_src, "rb");
    if (!in) return false;
    FILE *out = fopen(dest, "wb");
    if (!out) { fclose(in); return false; }

    char buf[8192];
    size_t n;
    bool ok = true;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0) {
        if (fwrite(buf, 1, n, out) != n) { ok = false; break; }
    }
    fclose(in);
    if (fclose(out) != 0) ok = false;
    if (!ok) remove(dest); // never leave a half-copied default behind
    return ok;
}

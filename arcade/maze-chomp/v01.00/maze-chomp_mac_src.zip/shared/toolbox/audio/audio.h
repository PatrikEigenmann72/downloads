// -----------------------------------------------------------------------------------------------
// audio.h - The real-time audio driver: opens the speakers and keeps them fed, sample by sample,
// from whatever functions you hand it. It has no opinion on what those samples mean - pink
// noise, a sine wave, a recording, silence - that's entirely up to whoever wrote the function
// you pass in. Pair this with a generator module like pinknoise.h or sinewave.h (or write your
// own - the whole point is that this file never has to change to support a new one).
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sat 2026-08-22 File created.                                                     Version: 00.01
// Sat 2026-08-22 Split the driver away from pink noise/sine generation, which        Version: 00.02
//                move to their own pinknoise.h/sinewave.h modules - this file no
//                longer knows what AudioMode or a frequency even are. Separation
//                of concerns: a driver that generates its own signal isn't a
//                driver, it's a signal generator wearing a driver's name.
// Sat 2026-10-10 Doc comments no longer CoreAudio-specific - audio.c now has a       Version: 00.03
//                Windows (waveOut) backend too, same contract. No API change.
// -----------------------------------------------------------------------------------------------
#ifndef SHARED_AUDIO_H
#define SHARED_AUDIO_H

#ifdef __cplusplus
extern "C" {
#endif

// The sample rate every generator paired with this driver must assume - a phase accumulator
// (see sinewave.c) needs this to convert a frequency in Hz into a per-sample phase step.
#define AUDIO_SAMPLE_RATE 44100.0

// A sample generator: produces the next sample for one channel, roughly in [-1, 1]. Called once
// per output sample, in order, from the driver's real-time audio thread (CoreAudio's render
// thread on macOS, audio.c's own waveOut thread on Windows) - implementations must be fast and
// allocation-free, and typically keep their own static state between calls (a phase, a filter
// history) rather than taking any arguments.
typedef double (*AudioSampleFn)(void);

// Opens the system's current default output device and starts real-time playback at
// AUDIO_SAMPLE_RATE, stereo. Both channels are silent until audio_set_channels() is called - call
// audio_stop() before calling this again.
//
// @return 0 on success, -1 on failure (no output device, CoreAudio/waveOut setup failed).
int audio_start(void);

// Changes what's playing, without needing to stop and restart (which would click/glitch).
//
// @param left, right  The generator to call for that channel's next sample each buffer, or NULL
//                      for silence on that channel. Safe to call at any time, including while
//                      already playing - takes effect on the next audio buffer.
void audio_set_channels(AudioSampleFn left, AudioSampleFn right);

// Stops playback and releases the output device.
void audio_stop(void);

#ifdef __cplusplus
}
#endif

#endif // SHARED_AUDIO_H

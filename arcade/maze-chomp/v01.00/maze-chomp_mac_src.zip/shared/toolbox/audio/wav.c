// -----------------------------------------------------------------------------------------------
// wav.c - Implements wav.h: a plain RIFF/WAVE parser (no external dependency - the format is
// simple enough, unlike PNG, to hand-roll correctly) plus the single-voice playback state.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-10-11 File created.                                                     Version: 00.01
// -----------------------------------------------------------------------------------------------
#include "wav.h"
#include "audio.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Set from the main thread, read from the render thread - see audio.c's s_left/s_right for why a
// plain volatile is enough here (a stale read for one buffer is harmless).
static const WavClip * volatile s_clip = NULL; // the pointer itself is volatile, not the pointee
static volatile bool s_loop = false;
static size_t s_position = 0;

// WAV format codes this decoder understands, from the 'fmt ' chunk's first field.
#define WAVE_FORMAT_PCM        1
#define WAVE_FORMAT_IEEE_FLOAT 3

// Reads a little-endian value of the given byte width from buf - WAV is little-endian
// throughout, regardless of host byte order.
static uint32_t read_le(const unsigned char *buf, int bytes) {
    uint32_t v = 0;
    for (int i = 0; i < bytes; i++) v |= ((uint32_t)buf[i]) << (8 * i);
    return v;
}

// @return 0 on success, -1 on failure (missing file, malformed RIFF/WAVE, unsupported format or
//         sample rate).
int wav_load(WavClip *clip, const char *path) {
    clip->samples = NULL;
    clip->frame_count = 0;

    FILE *f = fopen(path, "rb");
    if (!f) return -1;

    unsigned char header[12];
    if (fread(header, 1, 12, f) != 12 ||
        memcmp(header, "RIFF", 4) != 0 || memcmp(header + 8, "WAVE", 4) != 0) {
        fclose(f);
        return -1;
    }

    // fmt chunk fields, filled in once the 'fmt ' chunk is found below.
    uint16_t format = 0, channels = 0, bits_per_sample = 0;
    uint32_t sample_rate = 0;
    int have_fmt = 0;

    unsigned char *pcm_data = NULL;
    uint32_t pcm_size = 0;

    // Chunks appear in any order, and some (LIST, fact, ...) aren't ones this decoder cares
    // about - skip anything that isn't 'fmt ' or 'data' rather than assuming a fixed layout.
    unsigned char chunk_header[8];
    while (fread(chunk_header, 1, 8, f) == 8) {
        uint32_t chunk_size = read_le(chunk_header + 4, 4);

        if (memcmp(chunk_header, "fmt ", 4) == 0) {
            unsigned char fmt[16];
            if (chunk_size < 16 || fread(fmt, 1, 16, f) != 16) { fclose(f); free(pcm_data); return -1; }
            format = (uint16_t)read_le(fmt + 0, 2);
            channels = (uint16_t)read_le(fmt + 2, 2);
            sample_rate = read_le(fmt + 4, 4);
            bits_per_sample = (uint16_t)read_le(fmt + 14, 2);
            have_fmt = 1;
            // fmt chunks can carry extra bytes (WAVE_FORMAT_EXTENSIBLE) beyond the 16 read above -
            // skip them, plus the padding byte every odd-sized chunk gets.
            fseek(f, (long)(chunk_size - 16) + (long)(chunk_size & 1), SEEK_CUR);
        } else if (memcmp(chunk_header, "data", 4) == 0) {
            pcm_data = malloc(chunk_size);
            if (!pcm_data || fread(pcm_data, 1, chunk_size, f) != chunk_size) {
                fclose(f); free(pcm_data); return -1;
            }
            pcm_size = chunk_size;
            fseek(f, (long)(chunk_size & 1), SEEK_CUR); // odd-sized chunks are padded to even
        } else {
            fseek(f, (long)chunk_size + (long)(chunk_size & 1), SEEK_CUR);
        }
    }
    fclose(f);

    if (!have_fmt || !pcm_data) { free(pcm_data); return -1; }
    if (sample_rate != (uint32_t)AUDIO_SAMPLE_RATE) { free(pcm_data); return -1; }
    if (format != WAVE_FORMAT_PCM && format != WAVE_FORMAT_IEEE_FLOAT) { free(pcm_data); return -1; }
    if (channels != 1 && channels != 2) { free(pcm_data); return -1; }

    int bytes_per_sample = bits_per_sample / 8;
    if (bytes_per_sample < 1 || bytes_per_sample > 4) { free(pcm_data); return -1; }
    if (format == WAVE_FORMAT_IEEE_FLOAT && bytes_per_sample != 4) { free(pcm_data); return -1; }

    size_t bytes_per_frame = (size_t)bytes_per_sample * channels;
    size_t frame_count = pcm_size / bytes_per_frame;

    double *samples = malloc(frame_count * sizeof(double));
    if (!samples) { free(pcm_data); return -1; }

    for (size_t frame = 0; frame < frame_count; frame++) {
        double channel_sum = 0.0;

        for (int ch = 0; ch < channels; ch++) {
            const unsigned char *p = pcm_data + frame * bytes_per_frame + (size_t)ch * bytes_per_sample;
            double v;

            if (format == WAVE_FORMAT_IEEE_FLOAT) {
                uint32_t bits = read_le(p, 4);
                float fv;
                memcpy(&fv, &bits, 4);
                v = (double)fv;
            } else if (bytes_per_sample == 1) {
                // 8-bit PCM is the one WAV format stored unsigned (0..255, midpoint 128).
                v = (p[0] - 128) / 128.0;
            } else {
                // 16/24/32-bit PCM is signed, little-endian, sign-extended from its own width.
                uint32_t raw = read_le(p, bytes_per_sample);
                int32_t signed_raw;
                uint32_t sign_bit = 1u << (bytes_per_sample * 8 - 1);
                if (raw & sign_bit) {
                    signed_raw = (int32_t)(raw - (sign_bit << 1));
                } else {
                    signed_raw = (int32_t)raw;
                }
                double full_scale = (double)(1u << (bytes_per_sample * 8 - 1));
                v = signed_raw / full_scale;
            }

            channel_sum += v;
        }

        samples[frame] = channel_sum / channels; // downmix to mono
    }

    free(pcm_data);
    clip->samples = samples;
    clip->frame_count = frame_count;
    return 0;
}

void wav_free(WavClip *clip) {
    if (s_clip == clip) wav_stop();
    free(clip->samples);
    clip->samples = NULL;
    clip->frame_count = 0;
}

void wav_play(const WavClip *clip, bool loop) {
    s_position = 0;
    s_loop = loop;
    s_clip = clip; // set last - the render thread must never see a position stale for a new clip
}

double wav_sample(void) {
    const WavClip *clip = (const WavClip *)s_clip;
    if (!clip || s_position >= clip->frame_count) return 0.0;

    double sample = clip->samples[s_position];
    s_position++;

    if (s_position >= clip->frame_count) {
        if (s_loop) {
            s_position = 0;
        } else {
            s_clip = NULL;
        }
    }

    return sample;
}

bool wav_is_playing(void) {
    return s_clip != NULL;
}

void wav_stop(void) {
    s_clip = NULL;
}

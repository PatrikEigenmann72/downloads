// -----------------------------------------------------------------------------------------------
// wav.h - Plays a loaded WAV file through the audio driver (audio.h) - background music, a
// recorded sound effect, anything that isn't synthesized. Pairs with audio.h exactly like
// sinewave.h/pinknoise.h do: wav_sample() matches AudioSampleFn, so it plugs straight into
// audio_set_channels() without audio.c ever needing to know a WAV file exists.
//
// One clip plays at a time (same single-voice design as sinewave/pinknoise) - mixing several
// simultaneous sounds is a job for a layer above this one (see the arcade engine's arcade_sfx,
// which already mixes multiple synthesized voices the same way) rather than something this
// driver-level module takes on itself.
//
// Decoding is deliberately plain: 8/16/24/32-bit integer PCM or 32-bit float, mono or stereo
// (stereo is downmixed to mono - L and R averaged together - rather than carried through as a
// true stereo image, since AudioSampleFn has no channel argument to keep two interleaved
// positions in sync by), at exactly AUDIO_SAMPLE_RATE. No resampling - a file recorded at a
// different rate fails to load rather than silently playing at the wrong pitch.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-10-11 File created.                                                     Version: 00.01
// -----------------------------------------------------------------------------------------------
#ifndef SHARED_WAV_H
#define SHARED_WAV_H

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// A decoded clip: mono samples, normalized to roughly [-1, 1] regardless of the source file's own
// bit depth or channel count.
typedef struct {
    double *samples;
    size_t  frame_count;
} WavClip;

// Decodes a WAV file into clip. Fails (rather than resampling or guessing) if the file's sample
// rate doesn't match AUDIO_SAMPLE_RATE, or its format isn't 8/16/24/32-bit integer PCM or 32-bit
// float.
//
// @param clip  Filled in on success; untouched on failure.
// @param path  Path to the .wav file.
// @return 0 on success, -1 on failure (missing file, malformed RIFF/WAVE, unsupported format or
//         sample rate).
int wav_load(WavClip *clip, const char *path);

// Releases the decoded samples. Safe to call on a WavClip that failed to load (samples is NULL).
// Stops playback first if this clip is the one currently playing.
void wav_free(WavClip *clip);

// Starts clip playing from its first frame, replacing whatever was playing before. clip must stay
// valid (not freed) until playback is stopped or replaced - this module only keeps a pointer to
// it, not a copy.
//
// @param clip  The clip to play.
// @param loop  true to wrap back to frame 0 and keep playing once the clip ends; false to go
//              silent (wav_sample() returns 0.0) once it does.
void wav_play(const WavClip *clip, bool loop);

// Matches AudioSampleFn (see audio.h) - pass this directly to audio_set_channels() (the same
// function for both channels gives centered mono playback through both speakers).
//
// @return The next sample of whatever clip is currently playing, or 0.0 if nothing is. Call once
//         per output sample, in order - the playback position carries state between calls.
double wav_sample(void);

// @return true if a clip is currently playing (hasn't reached its end without looping, and
//         wav_stop() hasn't been called since).
bool wav_is_playing(void);

// Goes silent. wav_sample() returns 0.0 until wav_play() is called again.
void wav_stop(void);

#ifdef __cplusplus
}
#endif

#endif // SHARED_WAV_H

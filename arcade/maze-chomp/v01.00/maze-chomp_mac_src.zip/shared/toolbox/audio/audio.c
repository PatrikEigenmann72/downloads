// -----------------------------------------------------------------------------------------------
// audio.c - Implements audio.h. Two backends, one per platform, selected at compile time:
//   macOS   - a CoreAudio/AudioToolbox AudioUnit (the default output HAL unit) with a real-time
//             render callback.
//   Windows - winmm's waveOut, fed by a small ring of buffers that a dedicated high-priority
//             thread refills as the device hands them back.
// Either way it knows nothing about pink noise, sine waves, or any other signal - it just calls
// whatever AudioSampleFn audio_set_channels() was last given and writes the result to the output
// buffer. Both backends share that contract exactly, so audio.h and every generator stay
// platform-agnostic.
// -----------------------------------------------------------------------------------------------
// Author: Patrik Eigenmann
// eMail:  p.eigenmann72@gmail.com
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sat 2026-08-22 File created.                                                     Version: 00.01
// Sat 2026-08-22 Pink noise/sine generation moved out to pinknoise.c/sinewave.c -   Version: 00.02
//                this file is the generic driver now, generator-agnostic.
// Sat 2026-10-10 Added a Windows backend (winmm waveOut, 44.1kHz stereo float32,   Version: 00.03
//                4 x 512-frame buffers refilled by a time-critical thread) behind
//                #ifdef _WIN32, for the legacy/tone3 Windows port. The CoreAudio
//                backend below the #else is unchanged. Link with -lwinmm.
// -----------------------------------------------------------------------------------------------
#include "audio.h"

#ifdef _WIN32

#include <windows.h>
#include <mmsystem.h>
#include <mmreg.h> // WAVE_FORMAT_IEEE_FLOAT

// 4 buffers x 512 frames = ~46 ms queued at 44.1kHz - short enough that a channel change (see
// audio_set_channels()) is heard almost at once, long enough not to starve on a busy machine.
#define AUDIO_WIN_BUFFER_COUNT  4
#define AUDIO_WIN_BUFFER_FRAMES 512

static HWAVEOUT s_wave_out = NULL;
static HANDLE s_buffer_event = NULL; // signaled by winmm whenever a buffer comes back (WOM_DONE)
static HANDLE s_thread = NULL;
static volatile LONG s_running = 0;

static WAVEHDR s_headers[AUDIO_WIN_BUFFER_COUNT];
static float s_buffers[AUDIO_WIN_BUFFER_COUNT][AUDIO_WIN_BUFFER_FRAMES * 2]; // interleaved L/R

// Same reasoning as the CoreAudio backend's own copies below: set from the main thread, read
// from the audio thread, a stale read for one buffer is harmless - plain volatile is enough.
static volatile AudioSampleFn s_left = NULL;
static volatile AudioSampleFn s_right = NULL;

// Fills one buffer with the current generators' next samples - the Windows twin of
// audio_render() in the CoreAudio backend.
//
// @param out     Interleaved float32 L/R frames to write.
// @param frames  How many stereo frames to produce.
static void audio_fill(float *out, int frames) {
    AudioSampleFn left = s_left;
    AudioSampleFn right = s_right;

    for (int i = 0; i < frames; i++) {
        double l = left ? left() : 0.0;
        double r = right ? right() : 0.0;

        out[i * 2 + 0] = (float)l;
        out[i * 2 + 1] = (float)r;
    }
}

// The audio thread: sleeps until winmm hands a buffer back, then refills and re-queues every
// buffer that's done. Runs until audio_stop() clears s_running and wakes it one last time.
//
// @param unused  Unused - CreateThread's parameter.
// @return        0 always.
static DWORD WINAPI audio_thread(LPVOID unused) {
    (void)unused;
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);

    while (s_running) {
        WaitForSingleObject(s_buffer_event, INFINITE);

        for (int i = 0; i < AUDIO_WIN_BUFFER_COUNT && s_running; i++) {
            if (s_headers[i].dwFlags & WHDR_DONE) {
                audio_fill(s_buffers[i], AUDIO_WIN_BUFFER_FRAMES);
                waveOutWrite(s_wave_out, &s_headers[i], sizeof(WAVEHDR));
            }
        }
    }

    return 0;
}

// Releases whatever audio_start() managed to set up - shared by audio_stop() and audio_start()'s
// own failure paths. Safe on a partially-initialized state.
static void audio_release(void) {
    if (s_wave_out) {
        waveOutReset(s_wave_out); // hands every queued buffer back so it can be unprepared
        for (int i = 0; i < AUDIO_WIN_BUFFER_COUNT; i++) {
            if (s_headers[i].dwFlags & WHDR_PREPARED) {
                waveOutUnprepareHeader(s_wave_out, &s_headers[i], sizeof(WAVEHDR));
            }
        }
        waveOutClose(s_wave_out);
        s_wave_out = NULL;
    }
    if (s_buffer_event) {
        CloseHandle(s_buffer_event);
        s_buffer_event = NULL;
    }
}

// Opens the default output device (WAVE_MAPPER) and starts real-time 44.1kHz stereo float32
// playback, both channels silent until audio_set_channels() is called. Call audio_stop() before
// calling this again.
//
// @return 0 on success, -1 on failure (no output device, waveOut setup failed).
int audio_start(void) {
    WAVEFORMATEX format = {0};
    format.wFormatTag = WAVE_FORMAT_IEEE_FLOAT;
    format.nChannels = 2;
    format.nSamplesPerSec = (DWORD)AUDIO_SAMPLE_RATE;
    format.wBitsPerSample = 32;
    format.nBlockAlign = (WORD)(format.nChannels * format.wBitsPerSample / 8);
    format.nAvgBytesPerSec = format.nSamplesPerSec * format.nBlockAlign;
    format.cbSize = 0;

    s_buffer_event = CreateEvent(NULL, FALSE, FALSE, NULL); // auto-reset
    if (!s_buffer_event) return -1;

    if (waveOutOpen(&s_wave_out, WAVE_MAPPER, &format, (DWORD_PTR)s_buffer_event, 0,
                    CALLBACK_EVENT) != MMSYSERR_NOERROR) {
        s_wave_out = NULL;
        audio_release();
        return -1;
    }

    // Prime the device: every buffer starts out silent (both channels are NULL until
    // audio_set_channels()) and queued, so playback runs from the first moment.
    for (int i = 0; i < AUDIO_WIN_BUFFER_COUNT; i++) {
        ZeroMemory(&s_headers[i], sizeof(WAVEHDR));
        s_headers[i].lpData = (LPSTR)s_buffers[i];
        s_headers[i].dwBufferLength = sizeof(s_buffers[i]);
        if (waveOutPrepareHeader(s_wave_out, &s_headers[i], sizeof(WAVEHDR)) != MMSYSERR_NOERROR) {
            audio_release();
            return -1;
        }
        audio_fill(s_buffers[i], AUDIO_WIN_BUFFER_FRAMES);
        waveOutWrite(s_wave_out, &s_headers[i], sizeof(WAVEHDR));
    }

    s_running = 1;
    s_thread = CreateThread(NULL, 0, audio_thread, NULL, 0, NULL);
    if (!s_thread) {
        s_running = 0;
        audio_release();
        return -1;
    }

    return 0;
}

// Changes what's playing, without needing to stop and restart (which would click/glitch).
//
// @param left, right  The generator to call for that channel's next sample each buffer, or NULL
//                      for silence on that channel. Safe to call at any time, including while
//                      already playing.
void audio_set_channels(AudioSampleFn left, AudioSampleFn right) {
    s_left = left;
    s_right = right;
}

// Stops playback and releases the output device. The thread is stopped *before* waveOutReset():
// otherwise it could re-queue a buffer between the reset and the unprepare, which then fails.
void audio_stop(void) {
    if (!s_wave_out) return;

    s_running = 0;
    if (s_thread) {
        SetEvent(s_buffer_event); // wake it so it sees s_running == 0 and returns
        WaitForSingleObject(s_thread, INFINITE);
        CloseHandle(s_thread);
        s_thread = NULL;
    }

    audio_release();
}

#else // macOS - CoreAudio

#include <AudioToolbox/AudioToolbox.h>

static AudioUnit s_output_unit = NULL;

// Set from the main thread, read from the render thread. A stale read for one buffer (a few ms)
// is harmless here — worst case is one buffer generated by the previous channel setting — so
// plain volatile is enough; no lock needed for a single-word pointer swap like this.
static volatile AudioSampleFn s_left = NULL;
static volatile AudioSampleFn s_right = NULL;

// The AURenderCallback registered with the output AudioUnit in audio_start() - CoreAudio calls
// this on its own real-time audio thread every time it needs another buffer of samples, not from
// any code in this file directly.
//
// @param ref_con      Unused - would be inputProcRefCon from AURenderCallbackStruct.
// @param flags        Unused.
// @param timestamp    Unused.
// @param bus          Unused - there's only one output bus here.
// @param frame_count  How many stereo frames CoreAudio wants filled in this call.
// @param buffers      Where to write them - interleaved float32 L/R into buffers->mBuffers[0].
// @return             noErr always; there's no failure mode for pure sample generation.
static OSStatus audio_render(void *ref_con, AudioUnitRenderActionFlags *flags,
                              const AudioTimeStamp *timestamp, UInt32 bus, UInt32 frame_count,
                              AudioBufferList *buffers) {
    (void)ref_con; (void)flags; (void)timestamp; (void)bus;

    float *out = (float *)buffers->mBuffers[0].mData;
    AudioSampleFn left = s_left;
    AudioSampleFn right = s_right;

    for (UInt32 i = 0; i < frame_count; i++) {
        double l = left ? left() : 0.0;
        double r = right ? right() : 0.0;

        out[i * 2 + 0] = (float)l;
        out[i * 2 + 1] = (float)r;
    }

    return noErr;
}

// Opens the system's current default output device and starts real-time 44.1kHz stereo
// playback, both channels silent until audio_set_channels() is called. Call audio_stop() before
// calling this again.
//
// @return 0 on success, -1 on failure (no output device, CoreAudio setup failed).
int audio_start(void) {
    AudioComponentDescription desc = {
        .componentType = kAudioUnitType_Output,
        .componentSubType = kAudioUnitSubType_DefaultOutput,
        .componentManufacturer = kAudioUnitManufacturer_Apple,
        .componentFlags = 0,
        .componentFlagsMask = 0
    };

    AudioComponent component = AudioComponentFindNext(NULL, &desc);
    if (!component) return -1;

    if (AudioComponentInstanceNew(component, &s_output_unit) != noErr) return -1;

    AudioStreamBasicDescription format = {0};
    format.mSampleRate = AUDIO_SAMPLE_RATE;
    format.mFormatID = kAudioFormatLinearPCM;
    format.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked;
    format.mChannelsPerFrame = 2;
    format.mBitsPerChannel = 32;
    format.mBytesPerPacket = 8;
    format.mFramesPerPacket = 1;
    format.mBytesPerFrame = 8;

    if (AudioUnitSetProperty(s_output_unit, kAudioUnitProperty_StreamFormat, kAudioUnitScope_Input,
                              0, &format, sizeof(format)) != noErr) {
        AudioComponentInstanceDispose(s_output_unit);
        s_output_unit = NULL;
        return -1;
    }

    AURenderCallbackStruct callback = { .inputProc = audio_render, .inputProcRefCon = NULL };
    if (AudioUnitSetProperty(s_output_unit, kAudioUnitProperty_SetRenderCallback,
                              kAudioUnitScope_Input, 0, &callback, sizeof(callback)) != noErr) {
        AudioComponentInstanceDispose(s_output_unit);
        s_output_unit = NULL;
        return -1;
    }

    if (AudioUnitInitialize(s_output_unit) != noErr) {
        AudioComponentInstanceDispose(s_output_unit);
        s_output_unit = NULL;
        return -1;
    }

    if (AudioOutputUnitStart(s_output_unit) != noErr) {
        AudioUnitUninitialize(s_output_unit);
        AudioComponentInstanceDispose(s_output_unit);
        s_output_unit = NULL;
        return -1;
    }

    return 0;
}

// Changes what's playing, without needing to stop and restart (which would click/glitch).
//
// @param left, right  The generator to call for that channel's next sample each buffer, or NULL
//                      for silence on that channel. Safe to call at any time, including while
//                      already playing.
void audio_set_channels(AudioSampleFn left, AudioSampleFn right) {
    s_left = left;
    s_right = right;
}

// Stops playback and releases the output device.
void audio_stop(void) {
    if (!s_output_unit) return;

    AudioOutputUnitStop(s_output_unit);
    AudioUnitUninitialize(s_output_unit);
    AudioComponentInstanceDispose(s_output_unit);
    s_output_unit = NULL;
}

#endif // _WIN32

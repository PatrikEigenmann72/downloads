// -------------------------------------------------------------------------------------------
// config.c - Function library for the in-memory configuration system.
// This file implements the logic declared in config.h. It manages an internal
// array of key=value entries, allowing applications to add configuration values dynamically
// and retrieve them through typed getter functions. The application does not need to know
// how the array is stored, how many entries exist, or what type is used internally.
//
// The configuration system serializes key=value pairs into memory and deserializes them
// upon request. If a key does not exist or a type conversion fails, safe defaults are
// returned to ensure resilience. Errors are logged via the debug system to
// provide visibility without breaking execution flow.
// -------------------------------------------------------------------------------------------
// Author:      Patrik Eigenmann
// eMail:       p.eigenmann72@gmail.com
// GitHub:      https://github.com/PatrikEigenmann72/terminal
// -------------------------------------------------------------------------------------------
// Change Log:
// Tue 2025-11-25 File created (as samael.chronicle.config.c).                 Version: 00.01
// Wed 2025-11-26 Structural redesign: typedef ConfigEntry implemented.         Version: 00.02
// Thu 2025-11-27 Structural redesign: added config_add() and removed extern.   Version: 00.03
// Thu 2025-11-27 Added sophisticated documentation for implementation.         Version: 00.04
// Thu 2025-11-27 Integrated debug_error logging for missing keys/conversions.  Version: 00.05
// Sun 2026-08-23 Sorted into its own toolbox/config compartment and renamed    Version: 00.06
//                from samael.chronicle.config.c to config.c - see config.h's
//                change log for why. No behavior changed.
// Sat 2026-08-29 config_add() now copies key/value (strdup) instead of        Version: 00.07
//                storing the caller's own pointers - every existing caller
//                (helloc, treeclone) passes string literals, so this changed
//                nothing for them (a strdup of a literal is just a harmless
//                extra copy), but it was a real latent bug for the new
//                config_load_file() below: a line read into a stack buffer
//                and freed after the read loop moves on would otherwise
//                leave every entry pointing at freed memory.
// Sat 2026-08-29 Added config_load_file() - reads a plain "key=value" file    Version: 00.08
//                (blank lines and '#' comments skipped, same convention
//                engine/legacy_skin.h's own skin files already use) and adds
//                each line via config_add(). The legacy engine's own path to
//                eliminating <app>/config.h/.c entirely - see
//                tone3/resources/config/ for the first real use.
// Sun 2026-10-11 Added config_seed_overrides() - writes the user's own config.data  Version: 00.09
//                (app data) once, as a commented-out copy of the shipped one.
// -------------------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "config.h"
#include "logging/debug.h"   // Debugging support

// -------------------------------------------------------------------------------------------
// Internal Chronicle State
// These variables represent the private storage of configuration entries. They are declared
// as static to restrict their visibility to this translation unit (samael.chronicle.config.c).
// Applications cannot access them directly; they interact only through the public API.
//
// settings        Dynamic array of ConfigEntry records (key=value pairs).
// settings_count  Number of entries currently stored in the Chronicle.
// -------------------------------------------------------------------------------------------
static ConfigEntry* settings = NULL;
static int settings_count = 0;

// -------------------------------------------------------------------------------------------
// config_add - Adds a new configuration entry into the internal Chronicle.
// This function dynamically appends a key=value pair to the configuration memory. The key
// acts as a unique identifier, while the value is stored as a string. If the same key is
// added more than once, the most recent value overwrites the previous one.
//
// @param key   The string identifier for the configuration entry (e.g., "App.Name").
// @param value The string value associated with the key (e.g., "HelloWorld").
// -------------------------------------------------------------------------------------------
void config_add(const char* key, const char* value) {
    ConfigEntry* new_settings = realloc(settings, (settings_count + 1) * sizeof(ConfigEntry));
    if (!new_settings) {
        debug_err("Memory allocation failed while adding key '%s'.", key);
        return;
    }
    settings = new_settings;

    char* key_copy = strdup(key);
    char* value_copy = strdup(value);
    if (!key_copy || !value_copy) {
        debug_err("Memory allocation failed while copying key '%s'.", key);
        free(key_copy);
        free(value_copy);
        return;
    }

    settings[settings_count].key = key_copy;
    settings[settings_count].value = value_copy;
    settings_count++;
}

// -------------------------------------------------------------------------------------------
// get_setting - Internal lookup function for configuration entries.
// This helper searches the Chronicle's internal array for a given key and returns its
// associated string value. If the key does not exist, an error is logged.
//
// Searches newest-to-oldest (settings_count - 1 down to 0), not oldest-to-newest - config_add()
// always appends rather than overwriting in place, so the most recently added entry for a
// repeated key is the LAST one in the array, not the first. A forward search would have silently
// returned the original value forever, contradicting config_add()'s own documented "most recent
// value overwrites" contract - caught while adding config_load_file() below, which makes a
// repeated key (a config file overriding a value config_init() already added, say) a real,
// expected scenario rather than a purely theoretical one.
//
// @param key     The string identifier for the configuration entry.
// @return        The string value associated with the key, or NULL if the key does not exist.
// -------------------------------------------------------------------------------------------
static const char* get_setting(const char* key) {
    for (int i = settings_count - 1; i >= 0; i--) {
        if (strcmp(settings[i].key, key) == 0) {
            return settings[i].value;
        }
    }
    debug_err("Configuration key '%s' not found.", key);
    return NULL;
}

// -------------------------------------------------------------------------------------------
// config_get_string - Retrieves a configuration value as a string.
// Returns the stored string exactly as added via config_add(). If the key does not exist,
// logs an error and returns an empty string.
//
// @param key     The string identifier for the configuration entry.
// @return        The string value associated with the key, or "" if the key does not exist.
// -------------------------------------------------------------------------------------------
const char* config_get_string(const char* key) {
    const char* value = get_setting(key);
    if (!value) {
        debug_err("Conversion error: key '%s' has no valid string value.", key);
        return "";
    }
    return value;
}

// -------------------------------------------------------------------------------------------
// config_get_int - Retrieves a configuration value as an integer.
// Converts the stored string into an integer. If the key does not exist or conversion fails,
// logs an error and returns 0 as a safe default.
//
// @param key     The string identifier for the configuration entry.
// @return        The integer value associated with the key, or 0 if missing/invalid.
// -------------------------------------------------------------------------------------------
int config_get_int(const char* key) {
    const char* value = get_setting(key);
    if (!value) return 0;

    char* endptr;
    int result = (int)strtol(value, &endptr, 10);
    if (*endptr != '\0') {
        debug_err("Conversion error: key '%s' value '%s' is not a valid integer.", key, value);
        return 0;
    }
    return result;
}

// -------------------------------------------------------------------------------------------
// config_get_bool - Retrieves a configuration value as a boolean.
// Recognized values (case-insensitive):
//   true, yes, on, +, or any integer > 1   → logical truth
//   false, no, off, 0                      → logical falsehood
//
// If the key does not exist or parsing fails, logs an error and returns false.
//
// @param key     The string identifier for the configuration entry.
// @return        true if the value represents logical truth, false otherwise.
// -------------------------------------------------------------------------------------------
bool config_get_bool(const char* key) {
    const char* value = get_setting(key);
    if (!value) return false;

    char normalized[32];
    snprintf(normalized, sizeof(normalized), "%s", value);
    for (char* p = normalized; *p; ++p) *p = tolower(*p);

    if (strcmp(normalized, "true") == 0 || strcmp(normalized, "yes") == 0 ||
        strcmp(normalized, "on") == 0 || strcmp(normalized, "+") == 0) {
        return true;
    }
    if (strcmp(normalized, "false") == 0 || strcmp(normalized, "no") == 0 ||
        strcmp(normalized, "off") == 0 || strcmp(normalized, "0") == 0) {
        return false;
    }

    char* endptr;
    long num = strtol(normalized, &endptr, 10);
    if (*endptr == '\0' && num > 1) {
        return true;
    }

    debug_err("Conversion error: key '%s' value '%s' is not a valid boolean.", key, value);
    return false;
}

// -------------------------------------------------------------------------------------------
// config_get_double - Retrieves a configuration value as a double.
// Converts the stored string into a double-precision floating-point number. If the key
// does not exist or conversion fails, logs an error and returns 0.0.
//
// @param key     The string identifier for the configuration entry.
// @return        The double value associated with the key, or 0.0 if missing/invalid.
// -------------------------------------------------------------------------------------------
double config_get_double(const char* key) {
    const char* value = get_setting(key);
    if (!value) return 0.0;

    char* endptr;
    double result = strtod(value, &endptr);
    if (*endptr != '\0') {
        debug_err("Conversion error: key '%s' value '%s' is not a valid double.", key, value);
        return 0.0;
    }
    return result;
}

// -------------------------------------------------------------------------------------------
// config_get_float - Retrieves a configuration value as a float.
// Converts the stored string into a single-precision floating-point number. If the key
// does not exist or conversion fails, logs an error and returns 0.0f.
//
// @param key     The string identifier for the configuration entry.
// @return        The float value associated with the key, or 0.0f if missing/invalid.
// -------------------------------------------------------------------------------------------
float config_get_float(const char* key) {
    const char* value = get_setting(key);
    if (!value) return 0.0f;

    char* endptr;
    float result = strtof(value, &endptr);
    if (*endptr != '\0') {
        debug_err("Conversion error: key '%s' value '%s' is not a valid float.", key, value);
        return 0.0f;
    }
    return result;
}

// -------------------------------------------------------------------------------------------
// config_get_char - Retrieves a configuration value as a single character.
// Returns the first character of the stored string. If the key does not exist or the
// value is empty, logs an error and returns the null character ('\0').
//
// @param key     The string identifier for the configuration entry.
// @return        The first character of the string value, or '\0' if missing/empty.
// -------------------------------------------------------------------------------------------
char config_get_char(const char* key) {
    const char* value = get_setting(key);
    if (!value || strlen(value) == 0) {
        debug_err("Conversion error: key '%s' has no valid character value.", key);
        return '\0';
    }
    return value[0];
}

// -------------------------------------------------------------------------------------------
// config_load_file - Reads path (one "key=value" assignment per line) and adds each as a
// config entry via config_add() - the same convention engine/legacy_skin.h's own skin files
// already use in the legacy project family: blank lines and lines starting with '#' (after
// leading whitespace) are skipped; everything up to the first '=' is the key, everything after
// is the value, neither one trimmed further (a value with meaningful leading/trailing spaces is
// the caller's own business). A line with no '=' at all is silently skipped, not an error - lets
// a config file carry blank separator lines or stray comments without a strict "#" prefix
// breaking the load.
//
// config_add() copies both key and value (see its own doc comment), so path's own read buffer
// doesn't need to outlive this call - normal stack-local fgets() usage is safe.
//
// @param path  The config file to read.
// @return      true if path was opened and read (even if it turned out empty or had nothing
//              usable in it) - false only if path couldn't be opened at all. A missing/bad
//              config file is never fatal, matching legacy_skin_load()'s own contract.
// -------------------------------------------------------------------------------------------
bool config_load_file(const char* path) {
    FILE* f = fopen(path, "r");
    if (!f) {
        debug_err("Could not open config file '%s'.", path);
        return false;
    }

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        size_t len = strlen(line);
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = '\0';

        char* start = line;
        while (*start == ' ' || *start == '\t') start++;
        if (*start == '\0' || *start == '#') continue;

        char* eq = strchr(start, '=');
        if (!eq) continue;
        *eq = '\0';

        config_add(start, eq + 1);
    }

    fclose(f);
    return true;
}

// See config.h for the full contract.
bool config_seed_overrides(const char* user_path, const char* shipped_path) {
    FILE* existing = fopen(user_path, "r");
    if (existing) {
        fclose(existing);
        return true; // the user's own file - never touched
    }

    FILE* in = fopen(shipped_path, "r");
    if (!in) return false;
    char tmp_path[1024];
    snprintf(tmp_path, sizeof(tmp_path), "%s.tmp", user_path);
    FILE* out = fopen(tmp_path, "w");
    if (!out) {
        fclose(in);
        return false;
    }

    fprintf(out, "# config.data - your own settings. Every key=value line here overrides the same key\n");
    fprintf(out, "# in the shipped config.data (read-only, inside the program's own folder).\n");
    fprintf(out, "# Below: a copy of the shipped file, every setting commented out - remove the '#' in\n");
    fprintf(out, "# front of a setting to change it. Delete this file to start over.\n\n");

    char line[512];
    while (fgets(line, sizeof(line), in)) {
        const char* start = line;
        while (*start == ' ' || *start == '\t') start++;
        bool setting = *start != '#' && strchr(start, '=') != NULL;
        fprintf(out, "%s%s", setting ? "#" : "", line);
    }
    fclose(in);

    bool ok = fclose(out) == 0 && rename(tmp_path, user_path) == 0;
    if (!ok) remove(tmp_path);
    return ok;
}

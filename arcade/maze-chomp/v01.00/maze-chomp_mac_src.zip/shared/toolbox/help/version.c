// -----------------------------------------------------------------------------------------------
// version.c - The --version standard (see version.h): the flag check and the one layout of the
// identity block, with the identity every application shares. An application only passes its
// name, version and build date - through the version_requested() macro, from its own main.c.
// -----------------------------------------------------------------------------------------------
// Author:      Patrik Eigenmann
// eMail:       p.eigenmann72@gmail.com
// GitHub:      https://github.com/PatrikEigenmann72/toolbox
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-10-11 File created - version_print().                                  Version: 00.01
// Sun 2026-10-11 version_handle() (the flag check behind version_requested());    Version: 00.02
//                author, eMail and license come from version.h, not the caller.
// -----------------------------------------------------------------------------------------------
#include <stdio.h>
#include <string.h>

#include "version.h"

// See version.h for the full contract.
void version_print(const char *name, int major, int minor, const char *build_date) {
    printf("%s - Version %02d.%02d\n", name, major, minor);
    printf("%-12s%s\n", "Author:", VERSION_AUTHOR);
    printf("%-12s%s\n", "eMail:", VERSION_EMAIL);
    printf("%-12s%s\n", "License:", VERSION_LICENSE);
    printf("%-12s%s\n", "Build Date:", build_date);
}

// See version.h for the full contract.
bool version_handle(int argc, char **argv, const char *name, int major, int minor,
                    const char *build_date) {
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--version") == 0 || strcmp(argv[i], "-version") == 0 ||
            strcmp(argv[i], "-v") == 0) {
            version_print(name, major, minor, build_date);
            return true;
        }
    }
    return false;
}

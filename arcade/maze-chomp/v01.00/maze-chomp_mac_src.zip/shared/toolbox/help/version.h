// -----------------------------------------------------------------------------------------------
// version.h - The --version standard for every application: one template, one identity, one
// flag check. An application contributes only what is really its own - its name and version,
// which already live in its main.c (APP_NAME, MAJOR, MINOR) - and everything else (author,
// contact, license, layout, which flags count) is decided here, once.
//
// Usage, in main() before anything else opens a screen or window:
//
//     if (version_requested(argc, argv)) return 0;
//
// version_requested() is a macro, so it picks up APP_NAME, MAJOR and MINOR from the main.c it's
// used in, and __DATE__ there - the build date shown is the application's, not this module's.
// -----------------------------------------------------------------------------------------------
// Author:      Patrik Eigenmann
// eMail:       p.eigenmann72@gmail.com
// GitHub:      https://github.com/PatrikEigenmann72/toolbox
// -----------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-08-24 File created.                                                    Version: 00.01
// Sun 2026-10-11 Added version_print() (version.c) - the one layout every         Version: 00.02
//                component_display() prints, values aligned under "Build Date:".
// Sun 2026-10-11 The whole --version standard lives here now: identity constants  Version: 00.03
//                (VERSION_AUTHOR/EMAIL/LICENSE), the flag check (--version, -version,
//                -v) and version_requested(argc, argv), which takes APP_NAME/MAJOR/MINOR
//                from the calling main.c. The per-app component_display() contract is
//                gone - no application implements anything for --version any more.
// -----------------------------------------------------------------------------------------------
#ifndef TOOLBOX_HELP_VERSION_H
#define TOOLBOX_HELP_VERSION_H

#include <stdbool.h>

// The identity every application shares.
#define VERSION_AUTHOR   "Patrik Eigenmann"
#define VERSION_EMAIL    "p.eigenmann72@gmail.com"
#define VERSION_LICENSE  "MIT"

// ---------------------------------------------------------------------------------------
// version_requested - If argv holds a version flag (--version, -version or -v, anywhere - so
// `tool --debug --version` works too), prints the identity block and returns true; the caller
// then exits. Otherwise prints nothing and returns false.
//
// Needs APP_NAME (the program's name, e.g. "maze-chomp"), MAJOR and MINOR defined in the
// calling file - main.c, where pmake reads MAJOR/MINOR to name the binary anyway.
// ---------------------------------------------------------------------------------------
#define version_requested(argc, argv) \
    version_handle((argc), (argv), APP_NAME, MAJOR, MINOR, __DATE__)

// ---------------------------------------------------------------------------------------
// version_handle - What version_requested() expands to; call it directly only if a program
// keeps its name/version somewhere else than APP_NAME/MAJOR/MINOR.
//
// @return  true if a version flag was found (and the block printed).
// ---------------------------------------------------------------------------------------
bool version_handle(int argc, char **argv, const char *name, int major, int minor,
                    const char *build_date);

// ---------------------------------------------------------------------------------------
// version_print - Prints the identity block, the one layout every application uses:
//
//     maze-chomp - Version 00.12
//     Author:     Patrik Eigenmann
//     eMail:      p.eigenmann72@gmail.com
//     License:    MIT
//     Build Date: Oct 11 2026
// ---------------------------------------------------------------------------------------
void version_print(const char *name, int major, int minor, const char *build_date);

#endif

// ------------------------------------------------------------------------------------------------
// enigma.c - This project implements a modern, software‑based interpretation of the Enigma machine
// — a cipher device developed and used in the early to mid‑20th century to protect commercial,
// diplomatic, and military communication. Enigma was deployed extensively by Nazi Germany during
// World War II, where it was trusted to secure the most sensitive and top‑secret messages.
//
// In December 1932, Marian Rejewski of the Polish Cipher Bureau achieved the first major
// breakthrough against the plugboard‑equipped Enigma by applying permutation theory and
// exploiting operational weaknesses. His work, continued by Jerzy Różycki and Henryk Zygalski,
// laid the mathematical foundation for all subsequent Allied cryptanalysis.
//
// On 26–27 July 1939, in Pyry near Warsaw, Polish intelligence shared their techniques, equipment,
// and reconstructed Enigma machines with French and British representatives. This act of
// cooperation became the starting point for the larger Allied cryptanalytic effort.
//
// After the invasion of Poland, the Cipher Bureau staff escaped to Romania, destroyed their
// equipment to prevent capture, and eventually resumed cryptologic work in France. Their
// contributions continued quietly, often uncredited, but essential.
//
// At Bletchley Park, Alan Turing and his colleagues expanded on the Polish foundations, developing
// new techniques and electromechanical devices to handle the enormous wartime traffic. Turing’s
// work was central not only to breaking Enigma but also to the birth of modern computing. After
// the war, he was prosecuted under discriminatory laws for his homosexuality, subjected to chemical
// castration, and died in 1954 under circumstances widely believed to be suicide. His treatment
// remains one of the most tragic injustices in the history of science and technology.
//
// WHY THIS PROJECT EXISTS
// -----------------------
// This software is not a replica of the historical Enigma. It is a personal exploration —
// technical, historical, and emotional. Rebuilding a rotor‑based cipher engine taught me
// more than how to design a reversible transformation or implement a stepping mechanism.
// It forced me to confront the human story behind the machine: the brilliance of the people who
// broke it, the cruelty of the systems that punished them, and the uncomfortable truth that
// technological progress does not automatically make us better human beings.
//
// Turing’s fate is not an isolated historical footnote. It is a reminder that societies can
// celebrate genius while destroying the person who carries it. That realization disturbed me
// deeply — not as a programmer, but as a human being. It made me reflect on how little we have
// evolved in the ways that matter most. We still marginalize, exclude, and dehumanize people
// for their identity, orientation, language, appearance, or beliefs.
//
// This project is my small way of acknowledging that history, honoring the people who shaped it,
// and refusing to let the human cost be forgotten.
//
// PERSONAL TOUCH
// --------------
// Every rotor in this engine contains a subtle imprint: at positions 27 and 28, the initials of
// musicians from the “Club 27.” It’s a quiet tribute to artists whose brilliance burned
// intensely and briefly — another reminder of how fragile human lives are, and how often
// extraordinary people are lost too soon.
//
// WHAT THIS TOOL IS
// -----------------
// Yes, it is a cipher engine.
// Yes, it encrypts and decrypts text and files.
// Yes, it is technically functional and practically useful.
// 
// But it is also a statement:
// 
// •  about history
// •  about injustice
// •  about the cost of brilliance
// •  about the responsibility we carry when we build things
// •  about the need for a more humane future
//
// This is not just a tool.
// It is a reflection of why the tool exists.
// ------------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// ------------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-08-24 Versions 00.01-00.09: initial build-out - extracting rotor/         Version: 00.09
//                LargeRotor/MediumRotor/SmallRotor/EnigmaEngine into the shared
//                cipher engine, manpage functionality, debug/log integration, and
//                organizing the file by regions. Full entry-by-entry history
//                archived in enigma.changelog.txt.
// Mon 2026-08-24 Major Release.                                                     Version: 01.00
// Mon 2026-08-24 MAJOR/MINOR, manpage_display(), and component_display() moved     Version: 01.01
//                out of this file into main.c - the one place every project's own
//                identity/version lives (see pmake's own changelog for the full
//                reasoning). Removed the GitHub line from the header comment too -
//                wrong (pointed at "helloc") and will change anyway.
// Mon 2026-08-24 BugFix: enigma_encrypt_string()/enigma_decrypt_string()/                Version: 01.02
//                enigma_encrypt_file()/enigma_decrypt_file() took output by value
//                with no allocation of their own - every real call from main.c
//                passed a NULL output, which enigma_encrypt()/enigma_decrypt()
//                (the shared cipher engine) then wrote into character-by-character,
//                segfaulting on the very first character. All four now allocate the
//                buffer themselves (strlen(input)+1, since Enigma is a 1:1 character
//                substitution) and return it - caller frees. See main.c's own
//                changelog for the call-site updates.
// ------------------------------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>

#include "enigma.h"

#include "cipher/enigma.h"
#include "debug.h"
#include "log.h"

#pragma region Enigma functions
/**
 * Encrypting a string using the Enigma engine. This function takes an input string and processes
 * each character through the encryption mechanism of the Enigma engine, producing an encrypted
 * string. The function iterates through each character in the input string, encrypts it.
 *
 * @param input The string to encrypt.
 * @return A newly allocated buffer containing the encrypted string (same length as input, since
 *         Enigma is a 1:1 character substitution), or NULL on allocation failure. Caller frees.
 */
char *enigma_encrypt_string(const char *input) {
    debug_info("Allocate the enigma engine.");
    log_info("Allocate the enigma engine.");
    EnigmaEngine eng;

    debug_info("Initialize the enigma engine.");
    log_info("Initialize the enigma engine.");
    enigma_init(&eng);

    // Enigma is a 1:1 character substitution - the encrypted output is always exactly as long
    // as the input, plus the null terminator enigma_encrypt() itself writes.
    char *output = malloc(strlen(input) + 1);
    if (!output) {
        debug_err("Failed to allocate the output buffer.");
        log_err("Failed to allocate the output buffer.");
        return NULL;
    }

    debug_info("Encrypt the input string to a cipher.");
    log_info("Encrypt the input string to a cipher.");
    enigma_encrypt(&eng, input, output);

    return output;
}

/**
 * Decrypting a string using the Enigma engine. This function takes an input string and processes
 * each character through the decryption mechanism of the Enigma engine, producing a decrypted
 * string. The function iterates through each character in the input string, decrypts it.
 *
 * @param input The string to decrypt.
 * @return A newly allocated buffer containing the decrypted string (same length as input, since
 *         Enigma is a 1:1 character substitution), or NULL on allocation failure. Caller frees.
 */
char *enigma_decrypt_string(const char *input) {
    debug_info("Allocate the enigma engine.");
    log_info("Allocate the enigma engine.");
    EnigmaEngine eng;

    debug_info("Initialize the enigma engine.");
    log_info("Initialize the enigma engine.");
    enigma_init(&eng);

    char *output = malloc(strlen(input) + 1);
    if (!output) {
        debug_err("Failed to allocate the output buffer.");
        log_err("Failed to allocate the output buffer.");
        return NULL;
    }

    debug_info("Decrypt the input cypher to plaintext.");
    log_info("Decrypt the input cypher to plaintext.");
    enigma_decrypt(&eng, input, output);

    return output;
}

/**
 * Encrypts a file using the Enigma engine. This function reads the contents of the specified file,
 * processes each character through the encryption mechanism of the Enigma engine, and writes the
 * encrypted result back to the file or to a new file. This allows for encrypting entire
 * files while maintaining the state of the Enigma engine across characters, ensuring that the
 * stepping mechanism is correctly applied throughout the encryption process.
 *
 * @param filename The name of the file to encrypt.
 * @return A newly allocated buffer containing the encrypted file contents, or NULL if the file
 *         couldn't be read or the output buffer couldn't be allocated. Caller frees.
 */
char *enigma_encrypt_file(const char *filename) {

    debug_info("Reading file: %s.", filename);
    log_info("Reading file: %s.", filename);
    char *buffer = read_file(filename);

    if (!buffer) {
        debug_err("%s is not a file.", filename);
        log_err("%s is not a file.", filename);
        return NULL;
    }

    char *output = enigma_encrypt_string(buffer);

    debug_info("Free up the buffer.");
    log_info("Free up the buffer.");
    free(buffer);

    return output;
}

/**
 * Decrypts a file using the Enigma engine. This function reads the contents of the specified file,
 * processes each character through the decryption mechanism of the Enigma engine, and writes the
 * decrypted result back to the file or to a new file.
 *
 * @param filename The name of the file to decrypt.
 * @return A newly allocated buffer containing the decrypted file contents, or NULL if the file
 *         couldn't be read or the output buffer couldn't be allocated. Caller frees.
 */
char *enigma_decrypt_file(const char *filename) {

    debug_info("Reading file: %s.", filename);
    log_info("Reading file: %s.", filename);
    char *buffer = read_file(filename);

    if (!buffer) {
        debug_err("%s is not a file.", filename);
        log_err("%s is not a file.", filename);
        return NULL;
    }

    char *output = enigma_decrypt_string(buffer);

    debug_info("Free up the buffer.");
    log_info("Free up the buffer.");
    free(buffer);

    return output;
}
#pragma endregion

#pragma region File functions
/**
 * Checks if the specified path is a file. This function is used to verify that the provided path
 * points to a valid file before attempting to read from or write to it. This is important
 * for ensuring that the Enigma engine can successfully access the file for encryption or decryption
 * operations. By checking if the path is a file, you can prevent errors and ensure that the Enigma
 * engine operates on valid input, which is essential for both encrypting and decrypting messages
 * accurately.
 * 
 * @param path The path to check.
 * @return 1 if the path is a file, 0 otherwise.
 */
int is_file(const char *path) {

    struct stat st;

    debug_info("Check %s.", path);
    log_info("Check %s.", path);
    return stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

/**
 * Reads the entire contents of a file into a newly allocated buffer. The caller is responsible
 * for freeing the returned buffer.
 *
 * @param path The path of the file to read.
 * @return A pointer to a newly allocated buffer containing the file contents, or NULL on failure.
 */
char *read_file(const char *path) {

    debug_info("Read %s.", path);
    log_info("Read %s.", path);

    FILE *f = fopen(path, "rb");
    if (!f) return NULL;

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);

    char *buf = malloc(size + 1);
    if (!buf) {
        debug_err("File empty!");
        log_err("File empty!");
        fclose(f);
        return NULL;
    }

    fread(buf, 1, size, f);
    buf[size] = '\0';

    fclose(f);
    return buf;
}
#pragma endregion

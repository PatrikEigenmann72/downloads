// -------------------------------------------------------------------------------------------
// main.c - The heart of the software project. This is where the magic begins, and where the
// journey starts. For a C program, this is the entry point that brings everything together.
// It handles command-line arguments, manages the flow of execution, and coordinates the
// various components that make up the whole. This file is the central hub from which the
// program operates, ensuring that all parts work in harmony to achieve the desired
// functionality.
//
// Build: pmake enigma (from this folder) - see enigma.pmake. -DDEBUG (a pmake build flag) is
// unrelated to this program's own --debug/--keywords (see debug.h) - the former no longer even
// exists in pmake itself (see pmake's own changelog).
// -------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// -------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-08-24 Versions 00.01-00.06: initial build-out - CLI functionality       Version: 00.06
//                (-e/-d), manpage functionality, debug/log outputs, UTF-8 Windows
//                console support, and the MacOS/Linux flush bugfix. Full
//                entry-by-entry history archived in main.changelog.txt.
// Mon 2026-08-24 Major Release.                                                    Version: 01.00
// Mon 2026-08-24 MAJOR/MINOR, manpage_display(), and component_display() moved     Version: 01.01
//                in from enigma.c - this file is now the one canonical place for
//                this project's identity/version (see pmake's own changelog for
//                the full reasoning). Removed the stale -DDEBUG compile-instructions
//                block above and the wrong GitHub line - pmake no longer has
//                -DDEBUG at all, and the URL will change anyway.
// Mon 2026-08-24 argc safety: mode/input no longer read argv[1]/argv[2]              Version: 01.02
//                unconditionally - bare `enigma` with no args read argv[2] past
//                the guaranteed-valid range (undefined behavior). Added the same
//                argc<2/manpage_is_help_triggered() and --version-anywhere checks
//                pmake's main() already has, plus a clear error instead of a NULL
//                dereference when -e/-d is given with no input.
// Mon 2026-08-24 BugFix: -e/-d segfaulted on every real invocation. output stayed        Version: 01.03
//                NULL the whole time - passed by value into enigma_encrypt_string()/
//                enigma_encrypt_file() (and the decrypt equivalents), which write
//                into it character-by-character with no allocation of their own.
//                Those four functions now allocate and return the buffer themselves
//                (see enigma.c/enigma.h's own changelogs) - call sites here updated
//                to take the return value, check it for NULL, and free() it after
//                printing. Also fixed the manpage's "-(\)?" claim (never actually
//                checked by manpage_is_help_triggered() - just fell through the
//                generic unrecognized-mode fallback) to the real flag, -?.
// Mon 2026-08-24 BugFix: encrypt/decrypt round trips grew a blank line every time.    Version: 01.04
//                printf("%s\n", output) always appended '\n', but output already
//                ends in '\n' whenever the input did (echo'd strings, most text
//                files) - '\n' isn't in the rotor alphabet so it passes through
//                encryption/decryption unchanged. Added print_output(), which only
//                appends '\n' when output doesn't already end with one - still
//                covers the original "stray %" fix for output with no trailing
//                newline, without doubling up when there already is one.
// -------------------------------------------------------------------------------------------

// Standard Library Includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Samael Libraries Includes
#include "debug.h"             // Minimalist debugger header.
#include "log.h"               // Logging system header.
#include "manpage.h"                 // Manpage system header.
#include "version.h"                 // Version/identity contract - see component_display() below.
#include "stringutility.h"           // append_format(), used by manpage_display() below.

// enigma includes
#include "enigma.h"

// ------------------------------------------------------------
// Identity constants - the one canonical version/identity for this binary. run() (see pmake.c,
// part of the pmake project) reads MAJOR/MINOR straight out of this file to name the output
// binary; manpage_display()/component_display() below read the same pair - no second,
// independently-bumpable copy anywhere.
// ------------------------------------------------------------
#define APP_NAME    "enigma"
#define MAJOR       1
#define MINOR       4

#define AUTHOR      "Patrik Eigenmann"
#define EMAIL       "p.eigenmann72@gmail.com"
#define LICENSE     "GNU GPL 3.0"
#define BUILD_DATE  __DATE__

// -------------------------------------------------------------------------------------------
// manpage_display - This function displays a familiar UNIX-style manpage tailored for enigma.
// Declared as an extern contract in shared/toolbox/help/manpage.h - implemented here in main.c
// because each application has its own specific content to present.
// -------------------------------------------------------------------------------------------
void manpage_display() {

    log_info("Assembling and displaying the manpage content.");
    debug_info("Assembling and displaying the manpage content.");

    int major = MAJOR;
    log_info("Setting major version to %02d.", major);
    debug_info("Setting major version to %02d.", major);

    int minor = MINOR;
    log_info("Setting minor version to %02d.", minor);
    debug_info("Setting minor version to %02d.", minor);

    // Define the filename of the manpage content
    char *name = NULL;
    log_info("Setting application name to NULL.");
    debug_info("Setting application name to NULL.");

    append_format(&name, APP_NAME);
    log_info("Appended application name: %s.", name);
    debug_info("Appended application name: %s.", name);

    char *synopsis = NULL;
    log_info("Setting synopsis to NULL.");
    debug_info("Setting synopsis to NULL.");

    append_format(&synopsis, "      enigma [ -e \"plaintext\" | filename ]\n");
    append_format(&synopsis, "      enigma [ -d \"ciphertext\" | filename ]\n");
    append_format(&synopsis, "      enigma [--debug[:level]] [--keywords:csv]\n");
    append_format(&synopsis, "      enigma [-h | -H | -help | -Help | -?] [--version]\n");
    log_info("Built synopsis content.");
    debug_info("Built synopsis content.");

    char *description = NULL;
    log_info("Setting description to NULL.");
    debug_info("Setting description to NULL.");

    append_format(&description, "      %s - This tool is a modern C implementation inspired by the Enigma \n", APP_NAME);
    append_format(&description, "      machine — the cipher device used throughout the early and mid - 20th \n");
    append_format(&description, "      century to secure commercial, diplomatic, and military communication. \n");
    append_format(&description, "      Enigma was deployed extensively by Nazi Germany during World War II and \n");
    append_format(&description, "      was trusted to protect the most sensitive messages.\n");
    append_format(&description, "\n");
    append_format(&description, "      The first major breakthroughs against Enigma came in 1932 from Polish \n");
    append_format(&description, "      cryptologists Marian Rejewski, Jerzy Różycki, and Henryk Zygalski, \n");
    append_format(&description, "      whose work laid the mathematical foundation for all later Allied \n");
    append_format(&description, "      cryptanalysis. In July 1939, Polish intelligence shared their methods \n");
    append_format(&description, "      and reconstructed machines with French and British representatives, \n");
    append_format(&description, "      enabling the larger wartime codebreaking effort.\n");
    append_format(&description, "\n");
    append_format(&description, "      At Bletchley Park, Alan Turing and his colleagues expanded on this \n");
    append_format(&description, "      foundation, developing new techniques and electromechanical systems \n");
    append_format(&description, "      to handle the enormous volume of encrypted traffic. Turings \n");
    append_format(&description, "      contributions were central to the success of the Enigma - breaking \n");
    append_format(&description, "      effort and to the birth of modern computing. His later persecution \n");
    append_format(&description, "      for his homosexuality — culminating in his death in 1954 — remains \n");
    append_format(&description, "      one of the most tragic injustices in the history of science.\n");
    append_format(&description, "\n");
    append_format(&description, "      This project is not a replica of the historical Enigma. It is a \n");
    append_format(&description, "      personal interpretation: a rotor-based cipher engine inspired by \n");
    append_format(&description, "      the mechanical principles of the original, but redesigned with a \n");
    append_format(&description, "      modern, extended alphabet and a unique stepping cadence. Each \n");
    append_format(&description, "      rotor includes a subtle tribute at positions 27 and 28 — the \n");
    append_format(&description, "      initials of musicians from the “Club 27,” a nod to brilliant \n");
    append_format(&description, "      lives cut short.\n");
    append_format(&description, "\n");
    append_format(&description, "      The purpose of this tool is both technical and human. Building it \n");
    append_format(&description, "      was an exploration of reversible cipher design, but also a \n");
    append_format(&description, "      confrontation with the history behind the machine: the brilliance of \n");
    append_format(&description, "      those who broke it, the cruelty of the systems that punished them, \n");
    append_format(&description, "      and the uncomfortable truth that technological progress does not \n");
    append_format(&description, "      guarantee moral progress. This project exists to honor that history \n");
    append_format(&description, "      and to acknowledge the human cost behind the mathematics.\n");

    log_info("Built description content.");
    debug_info("Built description content.");

    char *options = NULL;
    log_info("Setting options to NULL.");
    debug_info("Setting options to NULL");

    append_format(&options, "      -e [\"plaintext\" | file]\n");
    append_format(&options, "         Encrypts a quoted string or the full contents of a plaintext \n");
    append_format(&options, "         file. This is the forward path through the Enigma‑inspired \n");
    append_format(&options, "         engine. The result is emitted to stdout.\n");
    append_format(&options, "\n");
    append_format(&options, "      -d [\"ciphertext\" | file]\n");
    append_format(&options, "         Decrypts ciphertext created by this tool. Accepts inline \n");
    append_format(&options, "         encrypted text or a file containing it. The engine retraces \n");
    append_format(&options, "         the exact rotor sequence used during encryption and restores \n");
    append_format(&options, "         the original plaintext with full fidelity.\n");
    append_format(&options, "\n");
    append_format(&options, "      Output redirection:\n");
    append_format(&options, "         Use '>' to write the result to a file, or '>>' to append to an\n");
    append_format(&options, "         existing file. For example:\n");
    append_format(&options, "            enigma -e \"Hello\" > secret.txt\n");
    append_format(&options, "            enigma -d secret.txt >> log.txt\n");
    append_format(&options, "\n");
    append_format(&options, "      --debug, --debug:<level>, --debug=<level>\n");
    append_format(&options, "         Enables enigma's own runtime diagnostic output. --debug alone shows \n");
    append_format(&options, "         everything; --debug:<level> narrows it to verbose, info, warn, error, \n");
    append_format(&options, "         or all. Either : or = works.\n");
    append_format(&options, "\n");
    append_format(&options, "      --keywords:<csv>, --keywords=<csv>\n");
    append_format(&options, "         Narrows enigma's own diagnostic output (see --debug above) to lines \n");
    append_format(&options, "         tagged with one of the given comma-separated keywords. Either : or = \n");
    append_format(&options, "         works.\n");
    append_format(&options, "\n");
    append_format(&options, "      -h, -H, -help, -Help, -?\n");
    append_format(&options, "         Do you need help? Any of these flags will open the application's \n");
    append_format(&options, "         manpage. This UNIX-style help file, familiar to developers and \n");
    append_format(&options, "         system administrators, is integrated into enigma itself. The \n");
    append_format(&options, "         beauty of this approach is that anyone working on macOS, BSD, UNIX, \n");
    append_format(&options, "         or Linux will instantly feel at home with the layout. Think of it as \n");
    append_format(&options, "         your built-in guide whenever you need more insight into the program \n");
    append_format(&options, "         enigma.\n");
    append_format(&options, "\n");
    append_format(&options, "      --version\n");
    append_format(&options, "         Prints the tool's identity block and exits.\n");
    log_info("Built options content.");
    debug_info("Built options content.");

    char *license = NULL;
    log_info("Setting license to NULL.");
    debug_info("Setting license to NULL.");

    append_format(&license, "      Copyright 2024 Free Software Foundation, Inc. License GPLv3+: GNU GPL version 3\n");
    append_format(&license, "      or later <https://gnu.org/licenses/gpl.html>. This is free software: you are free\n");
    append_format(&license, "      to change and redistribute it. There is NO WARRANTY, to the extent permitted by law.\n");
    log_info("Built license content.");
    debug_info("Built license content.");

    // Create the manpage in the file
    log_info("Initializing manpage with assembled content.");
    debug_info("Initializing manpage with assembled content.");
    manpage_init(major, minor, name, synopsis, description, options, license);

    // Free up the memory.
    free(name);
    log_info("Freed memory allocated for name.");
    debug_info("Freed memory allocated for name.");

    free(synopsis);
    log_info("Freed memory allocated for synopsis.");
    debug_info("Freed memory allocated for synopsis.");

    free(description);
    log_info("Freed memory allocated for description.");
    debug_info("Freed memory allocated for description.");

    free(options);
    log_info("Freed memory allocated for options.");
    debug_info("Freed memory allocated for options.");

    free(license);
    log_info("Freed memory allocated for license.");
    debug_info("Freed memory allocated for license.");
}

// -------------------------------------------------------------------------------------------
// component_display - Prints the tool's identity block: name, version, author, contact,
// license, and build date. Used when the --version flag is provided. Declared as an extern
// contract in shared/toolbox/help/version.h - implemented here in main.c because each
// application has its own specific identity to present.
// -------------------------------------------------------------------------------------------
void component_display(void) {
    printf("%s - Version %02d.%02d\n", APP_NAME, MAJOR, MINOR);
    printf("Author: %s\n", AUTHOR);
    printf("eMail: %s\n", EMAIL);
    printf("License: %s\n", LICENSE);
    printf("Build Date: %s\n", BUILD_DATE);
}

// -------------------------------------------------------------------------------------------
// print_output - Prints the encrypted/decrypted result, appending a trailing newline only if
// output doesn't already end with one. A plain `printf("%s\n", output)` here would double up:
// most real input (a shell-redirected file, an echo'd string) already ends in '\n', and since
// '\n' isn't in the rotor alphabet it passes straight through encryption/decryption unchanged -
// unconditionally adding another '\n' on top compounds by one blank line every round trip
// (encrypt then decrypt then encrypt again...). Still guarantees a trailing newline when output
// has none, which is what the "stray %" fix below was actually for.
// -------------------------------------------------------------------------------------------
static void print_output(const char *output) {
    size_t len = strlen(output);
    if (len > 0 && output[len - 1] == '\n') {
        printf("%s", output);
    } else {
        printf("%s\n", output);
    }
}

/**
 * main - This function marks the beginning of execution for any C program. It serves as the
 * central coordinator, handling command-line arguments, initializing subsystems, and directing
 * the overall flow of the application. From here, the program invokes its core routines,
 * manages resources, and produces output. The main function embodies the universal convention
 * of C: every application, regardless of purpose or domain, begins its journey here.
 *
 * @param argc   The number of command-line arguments passed to the program.
 * @param argv   The array of command-line argument strings.
 * @return       EXIT_SUCCESS (0) on successful execution, or an error code otherwise.
 */
int main(int argc, char **argv) {

    debug_parse_args(argc, argv); // --debug/--debug=<level>, --keywords=<csv> - see debug.h.
    setConsoleUTF8(); // Enable UTF-8 support for Windows console.
    log_init(LOG_ALL);

    // If no arguments were provided, or the user asked for help explicitly, print the help text
    // and exit cleanly. Checked before touching argv[1]/argv[2] below - bare `enigma` with no
    // args previously read argv[2] past the guaranteed-valid range (undefined behavior).
    if (argc < 2 || manpage_is_help_triggered(argc, argv)) {
        manpage_display();
        return EXIT_SUCCESS;
    }

    // Scanned across the whole argv, like manpage_is_help_triggered() above, so
    // `enigma --debug --version` finds it too, not just `enigma --version`.
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--version") == 0) {
            component_display();
            return EXIT_SUCCESS;
        }
    }

    const char *mode  = argv[1];
    const char *input = (argc > 2) ? argv[2] : NULL;

    debug_info("The %d command arguments are %s & %s", (argc - 1), mode, input ? input : "(none)");
    log_info("The %d command arguments are %s & %s", (argc - 1), mode, input ? input : "(none)");

    // -e/-d both require an input argument - fail clearly instead of passing NULL into
    // is_file()/enigma_encrypt_*()/enigma_decrypt_*() below.
    if ((strncmp(mode, "-e", 2) == 0 || strncmp(mode, "-d", 2) == 0) && !input) {
        debug_err("No plaintext/ciphertext or filename given after %s.\n", mode);
        log_err("No plaintext/ciphertext or filename given after %s.\n", mode);
        printf("Error: No plaintext/ciphertext or filename given after %s.\n", mode);
        return EXIT_FAILURE;
    }

    // ───────────────────────────────────────────────
    // 1. ENCRYPTION MODE (-e*)
    // ───────────────────────────────────────────────
    if (strncmp(mode, "-e", 2) == 0) {

        debug_info("Entering the encryption routine.");
        log_info("Entering the encryption routine.");

        char *output = NULL;

        if (is_file(input)) {
            debug_info("Input is a file.");
            log_info("Input is a file.");

            output = enigma_encrypt_file(input);

            debug_info("Encryption of %s complete.", input);
            log_info("Encryption of %s complete.", input);
        } else {
            debug_info("Input is plaintext.");
            log_info("Input is plaintext.");

            output = enigma_encrypt_string(input);

            debug_info("Encryption of plaintext complete.");
            log_info("Encryption of plaintext complete.");
        }

        if (!output) {
            debug_err("Encryption failed.");
            log_err("Encryption failed.");
            printf("Error: Encryption failed.\n");
            return EXIT_FAILURE;
        }

        print_output(output);
        free(output);

        debug_info("Output the encrypted text.");
        log_info("Output the encrypted text.");

        return EXIT_SUCCESS;
    }

    // ───────────────────────────────────────────────
    // 2. DECRYPTION MODE (-d*)
    // ───────────────────────────────────────────────
    if (strncmp(mode, "-d", 2) == 0) {

        debug_info("Entering the decryption routine.");
        log_info("Entering the decryption routine.");

        char *output = NULL;

        if (is_file(input)) {
            debug_info("Input is a file.");
            log_info("Input is a file.");

            output = enigma_decrypt_file(input);

            debug_info("Decryption of %s complete.", input);
            log_info("Decryption of %s complete.", input);
        } else {
            debug_info("Input is cipher text.");
            log_info("Input is cipher text.");

            output = enigma_decrypt_string(input);

            debug_info("Decryption of cipher text complete.");
            log_info("Decryption of cipher text complete.");
        }

        if (!output) {
            debug_err("Decryption failed.");
            log_err("Decryption failed.");
            printf("Error: Decryption failed.\n");
            return EXIT_FAILURE;
        }

        print_output(output);
        free(output);

        debug_info("Output the decrypted text.");
        log_info("Output the decrypted text.");

        return EXIT_SUCCESS;
    }

    // ───────────────────────────────────────────────
    // 3. INVALID MODE → MANPAGE (commented out)
    // ───────────────────────────────────────────────
    manpage_display();
    return EXIT_FAILURE;
}
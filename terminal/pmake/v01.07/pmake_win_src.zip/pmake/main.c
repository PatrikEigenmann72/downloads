// ****************************************************************************************************
// `pmake` isn’t here to replace your entire toolchain or teach you a new language. It exists because
// somewhere along the way, compiling a few lines of C code turned into a ceremony — full of build
// scripts that felt like mini-programs, declarations inside declarations, and files that read more
// like puzzles than instructions. Make is clever, maybe too clever. CMake has good intentions, but it's
// asking you to describe the very idea of a build system before touching a single .c file.
//
// This tool is none of that. No DSLs, no abstraction layers, no strange incantations. Just a small,
// direct program that reads your preferences and passes them to your compiler, like a polite assistant
// who doesn’t interrupt. If your project is sprawling, there are bigger hammers. But if you just want
// to compile your work without learning someone else’s language — that’s exactly where `pmake` steps in.
//
// It’s not trying to impress you. It’s assisting you in the process of building your software.
// 
// To build `pmake`, the most direct way is to use your compiler of choice:
// gcc   -Wall -Wextra -std=c99 -Iinclude src/*.c -o bin/pmake  
// clang -Wall -Wextra -std=c99 -Iinclude src/*.c -o bin/pmake  
//
// If you'd rather hand the work off to a file, you've got options.
// Use `pmake.pmake` for self-compilation, `Makefile` for tradition,
// or `CMakeLists.txt` if that’s your flavor.
//
// Installation scripts are available too if you want `pmake` as a system-wide tool available.
// Check out `scripts/install.sh` for Unix-like systems or `install.cmd` on Windows.
// ----------------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// ----------------------------------------------------------------------------------------------------
// Mon 2026-08-24 Versions 00.01-00.32: initial build-out - merged cVersion/cManPage       Version: 00.32
//                in, target=obj/exec/shared handling, the library-string rewrites,
//                the switch to {project}.pmake, a complete overhaul, manpage help
//                text passes, the Samael framework port, outsourcing all logic to
//                pmake.c (main.c became a thin entry point), --version, UTF-8
//                Windows console support, and this cycle's fixes: -DDEBUG removed
//                for --debug/--keywords, a missing-file segfault, an argv-order
//                filename bug, debug_err()/log_err() on every error exit, and a
//                --version argv-position bug. Full entry-by-entry history archived
//                in main.changelog.txt.
// Mon 2026-08-24 Major Release.                                                          Version: 01.00
// Mon 2026-08-24 Added this file's own MAJOR/MINOR - now the version every project's         Version: 01.01
//                own main.c carries, read by run() (see pmake.c) to name that project's
//                output binary, universally, in place of the old <project>.c convention.
//                Independent of pmake.c's own MAJOR/MINOR (pmake's own --version identity).
// Mon 2026-08-24 Reverted 01.01's split: two independently-bumpable version numbers      Version: 01.02
//                for one binary made no sense. manpage_display() and component_display()
//                moved here from pmake.c too, alongside MAJOR/MINOR - both read the same
//                pair run() reads from this file, so there's exactly one version number
//                for the whole binary, not two that can drift apart. pmake.c is pure
//                build-tool logic now (parse/run/Makefile lifecycle/filename handling).
// Mon 2026-08-24 component_display() un-static'd and given a formal extern contract          Version: 01.03
//                in the new shared/toolbox/help/version.h, mirroring manpage_display()'s
//                existing one in manpage.h - every project is now expected to supply its
//                own component_display() too, not just pmake.
// Mon 2026-08-24 Removed the To Do's block - every item on it was already marked         Version: 01.04
//                Done, including one (-DDEBUG) that's since been removed entirely.
// Mon 2026-08-24 Fixed a stale comment above #include "pmake.h" claiming a             Version: 01.05
//                nonexistent "parse.h" defined the .pmake-reading logic (that's
//                pmake.h/pmake.c) and describing debug.h/version.h/manpage.h as if
//                they belonged to this one include, when they're already listed
//                separately above.
// Mon 2026-08-24 Removed GIT/GitHub entirely - the header comment and --version's         Version: 01.06
//                printed URL disagreed with each other and with pmake.c/pmake.h's own
//                (three different wrong URLs across three files), and the real one
//                will change anyway. Simpler to have none than a wrong one.
// Mon 2026-08-24 Fixed this file's own header comment: eMail said p.eigenmann@gmx.net,   Version: 01.07
//                but the EMAIL macro --version actually prints is p.eigenmann72@gmail.com
//                - confirmed that's the correct one, now matching.
// *****************************************************************************************************/

// Standard C headers — the foundations we all lean on. These handle essential tasks like printing to
// the terminal, managing dynamic memory, and working with plain old C strings. Nothing fancy — just
// the timeless utilities that keep everything ticking.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Samael framework headers - Samael is growing C and Java library with ease of use tools and application
// helpers, that bring joy to programming CLI or UI driven applications.
#include "debug.h"
#include "log.h"
#include "manpage.h"
#include "version.h"
#include "stringutility.h"

// Project header — pmake's own build-tool interface: the Makefile struct, and parse()/run()/
// free_makefile()/normalize_filename(), the functions that actually read a .pmake file and turn
// it into a compiler command. Everything app-shaped (identity, manpage, version) lives here in
// main.c instead - see this file's own changelog for why.
#include "pmake.h"

// ------------------------------------------------------------
// Identity constants - every project's own copy of these lives in its own main.c, not in its
// <project>.c (that file, where present, holds project-specific build/app logic only - see
// pmake.c). MAJOR/MINOR is the one canonical version number for this binary: run() (see pmake.c)
// reads it straight out of this file to name the output binary, and manpage_display()/
// component_display() below read the same pair - no second, independently-bumpable copy anywhere.
// ------------------------------------------------------------
#define APP_NAME    "pmake"
#define MAJOR 1
#define MINOR 7

#define AUTHOR      "Patrik Eigenmann"
#define EMAIL       "p.eigenmann72@gmail.com"
#define LICENSE     "GNU GPL 3.0"
#define BUILD_DATE  __DATE__

// -------------------------------------------------------------------------------------------
// manpage_display
//
// Builds and displays the application's integrated manpage. This function assembles all
// sections—name, synopsis, description, options, and license—into a complete help page and
// delegates the final rendering to manpage_init(). The content is constructed dynamically
// using append_format(), which keeps the layout flexible and easy to maintain.
//
// The layout mirrors the UNIX manpage structure so developers and system administrators feel
// immediately at home. This function is only invoked when help flags are detected, and its
// output replaces normal program execution.
//
// @note Memory for all dynamically built sections is allocated here and freed before return.
// -------------------------------------------------------------------------------------------
void manpage_display() {

    log_info("Assembling and displaying the manpage content.");
    debug_info("Assembling and displaying the manpage content.");

    int major = MAJOR;
    log_info("Setting major version to %02d.", major);
    debug_info("Setting major version to %02d.", major);

    int minor = MINOR;
    log_info("Setting minor version to %02d.", minor);
    debug_info("Setting minor version to %02d.", minor);

    // NAME
    char *name = NULL;
    append_format(&name, APP_NAME);
    log_verbose("Appended application name: %s.", name);

    // SYNOPSIS
    char *synopsis = NULL;
    append_format(&synopsis,
        "      %s [makefile] [--debug[:level]] [--keywords:csv] [-h | -H | -help | -Help | -?]",
        name
    );
    log_info("Built synopsis content.");

    // DESCRIPTION
    char *description = NULL;
    append_format(&description,
        "      %s reads a <project>.pmake file and translates its contents into compiler\n"
        "      instructions. There is no scripting language, no hidden behavior, and no\n"
        "      abstraction layer. The file is intentionally simple so the developer stays\n"
        "      in control and always understands what the compiler is doing.\n"
        "\n"
        "      %s is designed for people who prefer clarity over complexity. If you want a\n"
        "      build tool that behaves exactly as it says—nothing more, nothing less—%s\n"
        "      stays out of your way.\n",
        name, name, name
    );
    log_info("Built description content.");

// OPTIONS
    char *options = NULL;
    append_format(&options,
        "      makefile\n"
        "          A project makefile is named <project>.pmake. It contains the compiler\n"
        "          settings for the project in a minimal, human-readable format. There are\n"
        "          no conditionals, loops, or DSL constructs—just straightforward\n"
        "          configuration.\n"
        "\n"
        "      --debug, --debug:<level>, --debug=<level>\n"
        "          Enables %s's own runtime diagnostic output while it compiles your\n"
        "          project - not a flag passed to the project's own compiler. --debug alone\n"
        "          shows everything; --debug:<level> narrows it to verbose, info, warn,\n"
        "          error, or all. Either : or = works.\n"
        "\n"
        "      --keywords:<csv>, --keywords=<csv>\n"
        "          Narrows %s's own diagnostic output (see --debug above) to lines tagged\n"
        "          with one of the given comma-separated keywords. Either : or = works.\n"
        "\n"
        "      -h, -H, -help, -Help, -?\n"
        "          Displays the integrated manpage. All variants are accepted for\n"
        "          convenience.\n"
        "\n"
        "      --version\n"
        "          Prints the tool's identity block and exits.\n",
        name, name
    );
    log_info("Built options content.");

    // LICENSE
    char *license = NULL;
    append_format(&license,
        "      Copyright 2024 Free Software Foundation, Inc. License GPLv3+: GNU GPL\n"
        "      version 3 or later <https://gnu.org/licenses/gpl.html>. This is free\n"
        "      software: you are free to change and redistribute it. There is NO WARRANTY,\n"
        "      to the extent permitted by law.\n"
    );
    log_info("Built license content.");

    // Initialize manpage
    log_info("Initializing manpage with assembled content.");
    manpage_init(major, minor, name, synopsis, description, options, license);

    // Cleanup
    free(name);
    free(synopsis);
    free(description);
    free(options);
    free(license);

    log_info("Freed all allocated manpage content.");
}

// -------------------------------------------------------------------------------------------
// component_display
//
// Prints the tool's identity block.
// Shows name, version, author, contact, repository, license, and build date.
// Used when the --version flag is provided.
// No dynamic memory.
// No side effects beyond stdout.
// Intended as a stable, human‑readable provenance entry point.
//
// Note: Declared as an extern contract in shared/toolbox/help/version.h (same split as
// manpage_display() in manpage.h) - implemented here in main.c because each application has its
// own identity to present.
// -------------------------------------------------------------------------------------------
void component_display(void)
{
    printf("%s - Version %02d.%02d\n", APP_NAME, MAJOR, MINOR);
    printf("Author: %s\n", AUTHOR);
    printf("eMail: %s\n", EMAIL);
    printf("License: %s\n", LICENSE);
    printf("Build Date: %s\n", BUILD_DATE);
}

// -----------------------------------------------------------------------------------------------------
// int main(int argc, char **argv) - This is where execution begins. The main-function serves as the
// entry point for all C and C++ programs that actually do something. When arguments are provided,
// they’re passed through `argc` (the argument count) and `argv` (argument vector) holds the actual inputs
// as strings — the first one’s always the program name.
// 
// The function returns an exit status to the operating system. I use EXIT_SUCCESS and EXIT_FAILURE —
// symbolic constants defined in <stdlib.h> — instead of raw integers like 0 or 1. It keeps things clear,
// portable, and easy to read.
// 
// @param argc  Number of arguments passed to the program
// @param argv  The actual arguments, starting with the program name itself
// @return      EXIT_SUCCESS on successful completion, EXIT_FAILURE if something goes wrong
// -----------------------------------------------------------------------------------------------------
// Recognizes pmake's own option flags (--debug and its --debug=<level>/--debug:<level> forms,
// --keywords=<csv>/--keywords:<csv>) so main() can tell them apart from the .pmake filename
// argument, regardless of which order they're given in.
//
// @param arg  One argv[] token.
// @return     1 if arg is one of pmake's recognized flags, 0 otherwise (i.e. a filename).
static int is_pmake_flag(const char *arg) {
    if (strcmp(arg, "--debug") == 0) return 1;
    if (strncmp(arg, "--debug=", 8) == 0)     return 1;
    if (strncmp(arg, "--debug:", 8) == 0)     return 1;
    if (strncmp(arg, "--keywords=", 11) == 0) return 1;
    if (strncmp(arg, "--keywords:", 11) == 0) return 1;
    return 0;
}

int main(int argc, char **argv) {

    debug_parse_args(argc, argv); // --debug/--debug=<level>, --keywords=<csv> - see debug.h.
    setConsoleUTF8(); // Enable UTF-8 support for Windows console.

    // If no arguments were provided, or the user asked for help explicitly, print the help text and exit
    // cleanly. A program that can’t explain itself isn’t ready to be used — this one does, and it does
    // so without assuming you already know what you’re doing.
    if (argc < 2 || manpage_is_help_triggered(argc, argv)) {
        manpage_display();

        //print_help(v);
        return EXIT_SUCCESS;
    }

    // After checking if the help or "manpage" is called, the next UNIX compliant standard is to check for
    // --version flag. If the user asks for the version of the application. Display the component meta data.
    // Scanned across the whole argv, like manpage_is_help_triggered() above - not just argv[1] - so
    // `pmake --debug --version` finds it too, instead of treating "--version" as the filename.
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--version") == 0) {
            component_display();
            return EXIT_SUCCESS;
        }
    }

    // Find the first argument that isn't one of pmake's own flags - that's the .pmake filename,
    // wherever it falls among --debug/--keywords (e.g. `pmake --debug myproject.pmake` works
    // the same as `pmake myproject.pmake --debug`). If every argument is a recognized flag, no
    // filename was actually given - fail clearly instead of trying to open e.g. "--debug.pmake".
    char *filename_arg = NULL;
    for (int i = 1; i < argc; i++) {
        if (!is_pmake_flag(argv[i])) {
            filename_arg = argv[i];
            break;
        }
    }
    if (!filename_arg) {
        debug_err("No .pmake file specified.\n");
        log_err("No .pmake file specified.\n");
        printf("Error: No .pmake file specified.\n");
        return EXIT_FAILURE;
    }

    // In case something goes wrong, the error message is stored here.
    char *errmsg = NULL;

    // Normalize the filename from the user's input.
    // Then debug it, so we know what we're working with.
    char *filename = normalize_filename(filename_arg);
    debug_info("filename = '%s'\n", filename);
    
    // Parse the provided `.pmake` file into a structured format.
    // This returns a Makefile pointer with all relevant fields filled out — or
    // sets `errmsg` if something goes wrong before we can proceed.
    Makefile *mf = parse(filename, &errmsg);

    // If an error message was returned during parsing or setup, print it, clean up the allocated string,
    // and exit with failure. The message goes to stdout — this tool doesn't pretend it's more than it is.
    // Checked before touching mf below: on failure mf is NULL, so mf->comp etc. would segfault.
    if (errmsg) {
        debug_err("%s\n", errmsg);
        log_err("%s\n", errmsg);
        printf("Error: %s\n", errmsg);
        free(errmsg);
        free_makefile(mf);
        return EXIT_FAILURE;
    }

    // Debugging output to help understand what the program is doing. This is useful during
    // development. Debug output is controlled by --debug/--keywords (see debug.h), parsed
    // above via debug_parse_args() - not by anything in the pmakefile itself.
    debug_info("comp    = '%s'\n", mf->comp);
    debug_info("flags   = '%s'\n", mf->flags);
    debug_info("target  = '%s'\n", mf->target);
    debug_info("bin     = '%s'\n", mf->bin);
    debug_info("src     = '%s'\n", mf->src);
    debug_info("libs    = '%s'\n", mf->libs);
    debug_info("project = '%s'\n", mf->project);

    // Kick off the build process using the parsed makefile. If something goes wrong, `errmsg` gets
    // populated and handled downstream. `run()` is the part that turns config into action.
    run(mf, &errmsg);

    // If something broke during execution, report the error, free the dynamically allocated error
    // message, and clean up the makefile data. Leaving no mess behind — even when things don't go
    // according to plan.
    if (errmsg) {
        debug_err("%s\n", errmsg);
        log_err("%s\n", errmsg);
        printf("Error: %s\n", errmsg);
        free(errmsg);
        free_makefile(mf);
        return EXIT_FAILURE;
    }

    // Clean up any remaining data tied to the makefile before exiting successfully.
    // If we made it here, the build ran without errors — no drama, no leftovers.
    free_makefile(mf);
    return EXIT_SUCCESS;
}
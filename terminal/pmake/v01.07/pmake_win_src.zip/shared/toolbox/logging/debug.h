/* ****************************************************************************************************
 * debug.h - When something's wrong right now and you need to watch it happen, a permanent log file
 * isn't fast enough - this is the "turn it on, watch the console, turn it back off" tool instead:
 * colorized, four severity levels, meant for active troubleshooting rather than a permanent record.
 * Off by default, only turns on via a launch-time flag or environment variable - no recompile needed:
 *
 *   bin/tool                        # silent - this is the shipped-version experience
 *   bin/tool --debug                # everything, including per-frame spam
 *   bin/tool --debug=warn           # only warnings/errors (--debug:warn also accepted)
 *   TOOLBOX_DEBUG=verbose bin/tool  # same thing via environment variable instead
 *
 * Every debug_*() call also accepts an optional keyword tag - a comma-separated string of whatever
 * vocabulary makes sense (a subsystem, a sequence name, an operation), e.g.
 * debug_verbose_tag("pdf_creation,write_file", "..."). __func__ is captured automatically for every
 * call already, so it doubles as a free keyword with no extra typing:
 *
 *   bin/tool --debug --keywords=pdf_creation         # only lines tagged pdf_creation, or logged
 *                                                     # from a function literally named that
 *   bin/tool --debug --keywords:write_file,save_pdf  # OR match - either tag qualifies
 *                                                     # (: and = both work, whichever you prefer)
 *
 * With no --keywords given, every line that passes the level mask prints, same as if this feature
 * didn't exist - keywords are purely a way to cut noise once you already know roughly where a bug
 * lives, not a replacement for the level mask. The plain debug_verbose/info/warn/err() macros pass
 * no explicit tag of their own (func-name matching alone still applies); the debug_*_tag() variants
 * exist for a call site that wants to carry an explicit tag beyond its own function name.
 *
 * For a permanent, always-on record written to a file regardless of any of this, see log.h instead -
 * the two are deliberately separate.
 * ----------------------------------------------------------------------------------------------------
 * Author:      Patrik Eigenmann
 * eMail:       p.eigenmann72@gmail.com
 * GitHub:      https://github.com/PatrikEigenmann72/terminal
 * ----------------------------------------------------------------------------------------------------
 * Change Log:
 * Sun 2025-06-22 File created (as samael.huginandmunin.debug.h).                       Version: 00.01
 * Sat 2025-11-15 Added timestamped, color-coded debug macros.                          Version: 00.02
 * Thu 2026-05-07 Added verbose debug macro and the matching color code.                Version: 00.03
 * Sun 2026-08-23 Sorted into its own toolbox/logging compartment and renamed from      Version: 00.04
 *                samael.huginandmunin.debug.h to debug.h. No behavior changed.
 * Sun 2026-08-23 Rebuilt entirely around legacy/arcade's legacy_debug.h design         Version: 00.05
 *                (ported here under plain names, no legacy_ prefix): dropped the old
 *                -DDEBUG compile-time on/off switch in favor of a real runtime level
 *                mask (--debug/--debug=<level> flag, TOOLBOX_DEBUG env var, or an
 *                explicit debug_set_level() call), added --keywords tag filtering,
 *                and switched output to stderr so this is safe to use from inside an
 *                active ncurses screen, not just a plain CLI tool. This is meant to
 *                become the one debug implementation across every project in this
 *                repo, and eventually legacy/arcade too - see legacy_debug.h's own
 *                change log for the plan there.
 * Sun 2026-08-23 Header guard renamed DEBUG_H -> TOOLBOX_LOGGING_DEBUG_H -             Version: 00.06
 *                standing convention now: every toolbox header guard is
 *                TOOLBOX_<FOLDERNAME>_<TOOL>_H (folder segment dropped for
 *                loose-drawer files), so a project's own same-named header can
 *                never silently collide with one from toolbox.
 * **************************************************************************************************** */
#ifndef TOOLBOX_LOGGING_DEBUG_H
#define TOOLBOX_LOGGING_DEBUG_H

#define DEBUG_NONE    0x00
#define DEBUG_VERBOSE 0x01
#define DEBUG_INFO    0x02
#define DEBUG_WARN    0x04
#define DEBUG_ERR     0x08
#define DEBUG_ALL     (DEBUG_VERBOSE | DEBUG_INFO | DEBUG_WARN | DEBUG_ERR)

#ifdef __cplusplus
extern "C" {
#endif

// Overrides the active level mask directly. Optional - without a call, the level comes from a
// --debug/--debug=<level> command-line flag (see debug_parse_args() below), or the TOOLBOX_DEBUG
// environment variable, or defaults to DEBUG_NONE (silent) if none of those are set.
//
// @param mask  One of DEBUG_NONE/VERBOSE/INFO/WARN/ERR/ALL, or an OR'd combination.
void debug_set_level(int mask);

// @return The currently active level mask.
int debug_get_level(void);

// Sets the active keyword filter directly from a comma-separated list. Optional - without a call
// (or with an empty string), no filtering happens and every line that passes the level mask
// prints. Normally set via --keywords=<csv> on the command line instead (see debug_parse_args()).
//
// @param csv  Comma-separated tags to filter on (OR-matched), or "" to clear any filter.
void debug_set_keywords(const char *csv);

// Call once at the top of main(), passing argc/argv straight through. Looks for --debug (an alias
// for --debug=verbose), --debug=<level>/--debug:<level>, and --keywords=<csv>/--keywords:<csv>
// among the arguments and applies whichever it finds (either separator works); every other
// argument is left untouched.
//
// @param argc, argv  Passed straight through from main().
//                     Valid <level> values: none, verbose, info, warn, error, all, or a raw
//                     numeric bitmask.
void debug_parse_args(int argc, char **argv);

// Internal - use the debug_*()/debug_*_tag() macros below, which fill in file/func/line for you.
// keywords is a comma-separated tag list for this specific call site ("" for none) - matched
// against the active --keywords filter alongside the automatically-captured function name.
void debug_write(int level, const char *level_str, const char *file, const char *func, int line,
                  const char *keywords, const char *fmt, ...);

#define debug_verbose(...) debug_write(DEBUG_VERBOSE, "VRB", __FILE__, __func__, __LINE__, "", __VA_ARGS__)
#define debug_info(...)    debug_write(DEBUG_INFO,    "INF", __FILE__, __func__, __LINE__, "", __VA_ARGS__)
#define debug_warn(...)    debug_write(DEBUG_WARN,    "WRN", __FILE__, __func__, __LINE__, "", __VA_ARGS__)
#define debug_err(...)     debug_write(DEBUG_ERR,     "ERR", __FILE__, __func__, __LINE__, "", __VA_ARGS__)

// Tagged variants, for a call site that wants an explicit keyword beyond its own function name.
#define debug_verbose_tag(keywords, ...) debug_write(DEBUG_VERBOSE, "VRB", __FILE__, __func__, __LINE__, keywords, __VA_ARGS__)
#define debug_info_tag(keywords, ...)    debug_write(DEBUG_INFO,    "INF", __FILE__, __func__, __LINE__, keywords, __VA_ARGS__)
#define debug_warn_tag(keywords, ...)    debug_write(DEBUG_WARN,    "WRN", __FILE__, __func__, __LINE__, keywords, __VA_ARGS__)
#define debug_err_tag(keywords, ...)     debug_write(DEBUG_ERR,     "ERR", __FILE__, __func__, __LINE__, keywords, __VA_ARGS__)

#ifdef __cplusplus
}
#endif

#endif // TOOLBOX_LOGGING_DEBUG_H

// ------------------------------------------------------------------------------------------------
// pmake.h - `pmake` isn’t here to replace your entire toolchain or teach you a new language. It
// exists because somewhere along the way, compiling a few lines of C code turned into a ceremony —
// full of build scripts that felt like mini-programs, declarations inside declarations, and files
// that read more like puzzles than instructions. Make is clever, maybe too clever. CMake has good
// intentions, but it's asking you to describe the very idea of a build system before touching a
// single .c file.
//
// This tool is none of that. No DSLs, no abstraction layers, no strange incantations. Just a small,
// direct program that reads your preferences and passes them to your compiler, like a polite
// assistant who doesn’t interrupt. If your project is sprawling, there are bigger hammers. But if
// you just want to compile your work without learning someone else’s language — that’s exactly
// where `pmake` steps in.
//
// It’s not trying to impress you. It’s assisting you in the process of building your software.
// ------------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// ------------------------------------------------------------------------------------------------
// Change Log:
// Tue 2026-04-20 File created.                                                     Version: 00.01
// Wed 2026-04-29 Added methods display_manpage.                                    Version: 00.02
// Wed 2026-04-29 Added functionallity from parse.c and removed version.c.          Version: 00.03
// Fri 2026-05-01 Switched globals to preprocessor constants for immutability.      Version: 00.04
// Tue 2026-06-30 Integrating OS gnosticism.                                        Version: 00.05
// Mon 2026-08-24 Removed debug_from_cli and strip_debug_flag() - -DDEBUG is gone,  Version: 00.06
//                see pmake.c's own changelog for why.
// Mon 2026-08-24 Removed manpage_display() and component_display() declarations - Version: 00.07
//                both moved into main.c along with MAJOR/MINOR, see pmake.c's own
//                changelog for why.
// Mon 2026-08-24 Removed the GitHub line from this file's own header comment -    Version: 00.08
//                wrong (pointed at "helloc", a different project entirely) and
//                will change anyway. See main.c's own changelog for the reasoning.
// ------------------------------------------------------------------------------------------------
#ifndef PMAKE_H
#define PMAKE_H

// This struct represents the parsed contents of a simple build configuration file. Each field stores
// a relevant directive: the compiler to use, flags to pass, target type (e.g., executable, shared
// library), and paths for source, output, and optional libraries. Designed for clarity and direct use
// in small CLI tools.
typedef struct {
    char *comp;
    char *flags;
    char *target;
    char *project;
    char *bin;
    char *src;
    char *libs;
    char *os_gnostic; // Optional field for OS-specific directives.
} Makefile;

// --------------------------------------------------------------------------------
// Parse a build configuration file and return a populated Makefile struct.
// If parsing fails, errmsg will point to a dynamically allocated error message.
//
// @param filename  Path to the config file to parse
// @param errmsg    Pointer to store error message (set to NULL on success)
// @return          Allocated Makefile* on success, NULL on failure
// --------------------------------------------------------------------------------
Makefile *parse(const char *filename, char **errmsg);

// --------------------------------------------------------------------------------
// Execute the build process based on the provided Makefile configuration.
// Translates the struct fields into a compiler command and invokes it.
//
// On failure, errmsg will point to an allocated string describing the issue.
// Caller is responsible for freeing errmsg if set.
//
// @param mf      Parsed build configuration
// @param errmsg  Output pointer for error messages (set to NULL on success)
// --------------------------------------------------------------------------------
void run(const Makefile *mf, char **errmsg);

// --------------------------------------------------------------------------------
// Free all dynamically allocated memory associated with a Makefile struct.
// Safely deallocates each field and then the struct itself.
//
// @param mf  Pointer to a Makefile previously returned by parse()
//            (or NULL, in which case nothing happens)
// --------------------------------------------------------------------------------
void free_makefile(Makefile *mf);

// --------------------------------------------------------------------------------
// Convert a user-supplied filename into a normalized format.
// This may add or adjust extensions, strip leading paths, or enforce consistency
// in naming conventions. Useful for resolving shorthand or ambiguous filenames.
//
// @param input  Raw filename or command-line argument
// @return       Dynamically allocated, normalized filename string (caller frees)
// --------------------------------------------------------------------------------
char *normalize_filename(const char *input);

#endif
// -------------------------------------------------------------------------------------------
// treeclone.c - Who hasn’t used the UNIX tree command to get a quick overview of a directory?
// treeclone is a compact re‑implementation of that idea — a small C program that walks your
// filesystem and prints a clean, readable tree view of folders and files. It’s fast, minimal,
// and configurable, with sensible defaults and a simple exclusion system. If you want a portable,
// dependency‑free tree tool that behaves exactly the way you expect, treeclone has you covered.
// This c file is the implementation of the treeclone kernel.
// -------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// -------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-08-24 Versions 00.01-00.04: initial build-out - the internal              Version: 00.04
//                constants became #define macros, is_version_triggered() and
//                version_display() added. Full entry-by-entry history archived
//                in treeclone.changelog.txt.
// Mon 2026-08-24 Major Release.                                                      Version: 01.00
// Mon 2026-08-24 MAJOR/MINOR, manpage_display(), and version_display() (renamed      Version: 01.01
//                component_display(), fulfilling the shared/toolbox/help/version.h
//                contract) moved out of this file into main.c - the one place every
//                project's own identity/version lives (see pmake's own changelog for
//                the full reasoning). is_version_triggered() moved too, as a static
//                helper (not a shared contract - manpage_is_help_triggered() is, this
//                isn't). Removed the GitHub line from the header comment and the
//                dead, unused APP_EXTRACT_FILTER macro (config_init() already hardcodes
//                the same filter string directly, not via this macro).
// Mon 2026-08-24 BugFix: -exclude/the default filter never really worked. Three          Version: 01.02
//                separate bugs stacked in is_excluded(): (1) strstr(token, name) had
//                the arguments backwards from its own doc comment ("if the filename
//                contains any token") - only ever matched by accident, for default
//                patterns shaped like "name/" (".git/" contains ".git"); a real
//                pattern like "txt" could never match, since the filename is always
//                longer than the pattern. (2) str_trim(token)'s return value was
//                discarded - it doesn't trim in place despite its own doc comment,
//                it mallocs and returns a new string, so leading whitespace after
//                each comma (", .git/") was never actually stripped, and every call
//                leaked. (3) fixing (1) alone regressed the trailing-slash directory
//                patterns (".git/", "bin/", "tmp/", "build/") - readdir()'s d_name
//                never has one, so a token needs it stripped before matching, not
//                just swapped. All three fixed together: capture str_trim()'s return,
//                strip a trailing '/', then strstr(name, trimmed).
// Mon 2026-08-24 is_excluded() gained an is_dir parameter: a trailing-slash token           Version: 01.03
//                (".git/", "bin/") is meant to exclude exactly that directory, not
//                any file whose name happens to contain the same letters (a "bin/"
//                token was also hiding a file named "cabin.txt"). Now only matches
//                when is_dir is true; a token with no trailing slash still matches
//                files and directories alike. Both call sites (main.c, walk() below)
//                reordered to stat() before checking exclusion, since that's the only
//                way to know is_dir at that point.
// -------------------------------------------------------------------------------------------

#include <stdio.h>     // printf, snprintf
#include <stdlib.h>    // malloc, free
#include <string.h>    // strdup, strtok, strlen, strstr, strcmp, strncpy, strcat
#include <dirent.h>    // DIR, struct dirent, opendir, readdir, closedir
#include <sys/stat.h>  // stat, S_ISDIR
#include <unistd.h>    // PATH_MAX on some systems

#include "debug.h"   // debug_info()
#include "log.h"     // log_info()
#include "stringutility.h" // str_trim()
#include "config.h"    // config_add()

#include "treeclone.h"

// -------------------------------------------------------------------------------------------
// is_excluded - Evaluates whether a given filesystem entry should be filtered out based on a
// comma‑separated list of exclusion tokens. The logic is intentionally simple and
// deterministic: each token is trimmed and matched using a raw substring search against name.
// A token written with a trailing slash (".git/", "bin/", "tmp/") only ever matches a
// directory entry - is_dir must be true - so it excludes exactly that directory and nothing
// merely containing the same letters (a "bin/" token doesn't also hide a file named
// "cabin.txt"). A token with no trailing slash (".txt", "bin") matches files and directories
// alike, wherever the substring appears.
//
// This avoids globbing, regex engines, or hidden matching rules. The behavior is transparent,
// predictable, and easy to reason about—consistent with the UNIX philosophy of simple,
// explicit tools.
//
// @param name        The filename or directory name to evaluate.
// @param is_dir      1 if this entry is a directory, 0 if it's a file.
// @param patterns    A comma‑separated list of exclusion tokens (may be NULL).
// @return            1 if the entry should be excluded, 0 otherwise.
// -------------------------------------------------------------------------------------------
int is_excluded(const char *name, int is_dir, const char *patterns) {

    if (!patterns) return 0;

    char *copy = strdup(patterns);
    char *token = strtok(copy, ",");

    while (token) {

        // str_trim() does NOT modify in place, despite its own doc comment - it mallocs and
        // returns a new trimmed string. The old code called str_trim(token) and discarded that
        // return value, so leading/trailing whitespace was never actually stripped (and the
        // allocation leaked every call). Capture it, and free it once we're done with it.
        char *trimmed = str_trim(token);

        if (trimmed) {

            // A trailing slash marks a directory-only token - readdir()'s d_name never has
            // one, so strip it before matching, but remember it was there: this token must
            // then only match a directory entry, or "bin/" would also hide any file whose
            // name happens to contain "bin" (e.g. "cabin.txt").
            size_t tlen = strlen(trimmed);
            int dir_only = (tlen > 0 && trimmed[tlen - 1] == '/');
            if (dir_only) trimmed[tlen - 1] = '\0';

            // If token is empty, skip
            if (strlen(trimmed) > 0 && (!dir_only || is_dir)) {

                // Substring match: does name contain token, not the other way around - a
                // token like "txt" is almost always shorter than the filenames it's meant to
                // match, so strstr(name, token) is the only order that can ever find it.
                if (strstr(name, trimmed) != NULL) {
                    free(trimmed);
                    free(copy);
                    return 1;
                }
            }

            free(trimmed);
        }

        token = strtok(NULL, ",");
    }

    free(copy);
    return 0;
}

// -------------------------------------------------------------------------------------------
// walk - Recursively traverses a directory and prints its contents in a clean, human‑readable
// tree structure. This function is the core engine of the application: it collects entries,
// applies exclusion rules, sorts them (directories first, then alphabetical), prints the
// current level, and then descends into subdirectories.
//
// The design is intentionally explicit and deterministic:
//   • No global state is accessed.
//   • No hidden configuration lookups occur.
//   • All behavior (prefix formatting, depth tracking, exclusion filtering) is controlled
//     entirely by the parameters passed in.
//   • Recursion is transparent and predictable.
//
// This keeps the traversal easy to reason about, easy to debug, and consistent with the
// UNIX philosophy of simple, composable tools.
//
// @param path        The filesystem path to traverse (e.g., "./src").
// @param basename    The root directory name (used only for display).
// @param prefix      The accumulated path prefix for nested directories.
// @param depth       Current recursion depth, used for visual indentation.
// @param excludes    The merged exclusion filter string passed down from main().
// -------------------------------------------------------------------------------------------
void walk(const char *path, const char *basename, const char *prefix, int depth, const char *excludes) {

    Entry entries[1024];
    int count = 0;

    struct dirent *entry;
    char full[PATH_MAX];

    debug_info("walk() into: path='%s' prefix='%s' depth=%d", path, prefix, depth);

    DIR *dir = opendir(path);
    if (!dir) {
        debug_info("FAILED to open directory: %s", path);
        return;
    }

    // Collect entries
    while ((entry = readdir(dir)) != NULL) {

        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) continue;

        // stat() runs before is_excluded() now - a directory-only token (".git/", "bin/")
        // needs to know whether this entry actually is a directory to decide whether it
        // applies at all.
        snprintf(full, sizeof(full), "%s/%s", path, entry->d_name);

        struct stat st;
        if (stat(full, &st) != 0) {
            debug_info("  stat() FAILED for %s", full);
            continue;
        }

        int is_dir = S_ISDIR(st.st_mode);
        if (is_excluded(entry->d_name, is_dir, excludes)) continue;

        strncpy(entries[count].name, entry->d_name, PATH_MAX);
        entries[count].is_dir = is_dir;

        debug_info("  collected: %s (%s)",
                   entry->d_name,
                   entries[count].is_dir ? "DIR" : "FILE");

        count++;
    }

    closedir(dir);

    // Sort: directories first, then alphabetical
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {

            int swap = 0;

            if (entries[i].is_dir != entries[j].is_dir) {
                if (entries[j].is_dir)
                    swap = 1;
            } else {
                if (strcmp(entries[i].name, entries[j].name) > 0)
                    swap = 1;
            }

            if (swap) {
                Entry tmp = entries[i];
                entries[i] = entries[j];
                entries[j] = tmp;
            }
        }
    }

    debug_info("  sorted %d entries in '%s'", count, prefix);

    // Print + recurse
    for (int i = 0; i < count; i++) {

        snprintf(full, sizeof(full), "%s/%s", path, entries[i].name);

        int is_last = (i == count - 1);

        // Build visual prefix
        char visual[PATH_MAX] = "";
        for (int d = 0; d < depth; d++) {
            strcat(visual, "│   ");
        }

        // Choose symbol
        const char *symbol = is_last ? "└── " : "├── ";

        if (entries[i].is_dir) {

            debug_info("  DIR: %s -> recurse", entries[i].name);

            printf("%s%s%s/\n", visual, symbol, entries[i].name);

            char newprefix[PATH_MAX];
            snprintf(newprefix, sizeof(newprefix), "%s/%s", prefix, entries[i].name);

            walk(full, basename, newprefix, depth + 1, excludes);

        } else {

            debug_info("  FILE: %s", entries[i].name);

            printf("%s%s%s\n", visual, symbol, entries[i].name);
        }
    }
}

// -------------------------------------------------------------------------------------------
// config_init - This function is required in every project that uses the Samael framework,
// specifically the samael.chronicle.config.h module. It defines the initial set of
// configuration values the application needs at startup. Developers implement config_init()
// to add key=value pairs using the config_add() API, such as application name, version,
// labels, numeric values, or other parameters.
//
// The purpose of config_init() is to provide a single, centralized place where an application
// declares its important settings. This makes configuration easy to understand, maintain,
// and adjust over time.
//
// @note This function fulfills the extern declaration in samael.chronicle.config.h. The
//       framework does not provide a default implementation; each application must define it.
// -------------------------------------------------------------------------------------------
void config_init(void) {
    
    // Add configuration entries using the public API.
    log_info("Add configuration entries using the public API.");
    debug_info("Add configuration entries using the public API.");

    config_add("App.ExtractFilter", "*.tmp, tmp/, .vscode, .git/, .DS_Store, bin/, build/");
    log_info("Added App.ExtractFilter -> *.tmp, tmp/, .vscode, .git/, .DS_Store");
    debug_info("Added App.ExtractFilter -> *.tmp, tmp/, .vscode, .git/, .DS_Store");
}
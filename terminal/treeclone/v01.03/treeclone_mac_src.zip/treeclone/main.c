// -------------------------------------------------------------------------------------------
// main.c - The heart of the software project. This is where the magic begins, and where the
// journey starts. For a C program, this is the entry point that brings everything together.
// It handles command-line arguments, manages the flow of execution, and coordinates the
// various components that make up the whole. This file is the central hub from which the
// program operates, ensuring that all parts work in harmony to achieve the desired
// functionality.
//
// Build: pmake treeclone (from this folder) - see treeclone.pmake. -DDEBUG (a pmake build flag)
// is unrelated to this program's own --debug/--keywords (see debug.h) - the former no longer
// even exists in pmake itself (see pmake's own changelog).
// -------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// -------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-08-24 Versions 00.01-00.11: initial build-out - CLI parsing, Samael          Version: 00.11
//                logging/debug integration, config_init() with a default exclusion
//                filter, the walk()/is_excluded() kernel (eventually moved into
//                treeclone.h/.c), and Windows UTF-8 console support. Full
//                entry-by-entry history archived in main.changelog.txt.
// Mon 2026-08-24 Major Release.                                                        Version: 01.00
// Mon 2026-08-24 MAJOR/MINOR, manpage_display(), and version_display() (renamed        Version: 01.01
//                component_display(), fulfilling the shared/toolbox/help/version.h
//                contract) moved in from treeclone.c, along with is_version_triggered()
//                as a static helper - this file is now the one canonical place for
//                this project's identity/version (see pmake's own changelog for the
//                full reasoning). Removed the stale -DDEBUG compile-instructions block
//                above and the wrong GitHub line - pmake no longer has -DDEBUG at all,
//                and the URL will change anyway. Also fixed two real bugs found in the
//                moved manpage_display(): the OPTIONS text said "helloc" instead of
//                "treeclone" (copy-paste residue), and "-(\)?" was never actually
//                checked by manpage_is_help_triggered() - fixed to the real flag, -?.
// Mon 2026-08-24 -exclude "csv" (a separate argv token for the value) replaced           Version: 01.02
//                with --exclude:csv/--exclude=csv, matching --debug/--keywords'
//                convention - one flag, one token, either separator. Manpage OPTIONS
//                text rewritten to document the actual matching semantics (plain
//                substring, no globbing - ".txt" for an extension, ".git/" for an
//                exact directory, a bare word for anything matching that pattern).
// Mon 2026-08-24 BugFix: --exclude:.git/ (or any trailing-slash token) was also         Version: 01.03
//                hiding files whose name happened to contain the same letters, e.g.
//                "bin/" hiding "cabin.txt" too. is_excluded() needs to know whether
//                an entry is a directory to honor that distinction, so stat() now
//                runs before the exclusion check instead of after - see
//                treeclone.c's own changelog for the full reasoning.
// -------------------------------------------------------------------------------------------

/* Include the standard libraries */
#include <stdio.h>      // printf, perror
#include <stdlib.h>     // EXIT_SUCCESS, EXIT_FAILURE
#include <string.h>     // strcmp, snprintf
#include <dirent.h>     // DIR, opendir, readdir, closedir
#include <sys/stat.h>   // stat, S_ISDIR
#include <limits.h>     // PATH_MAX
#include <unistd.h>     // getcwd


/* Include the Samael libraries */
#include "debug.h"             // Minimalist debugger header.
#include "config.h"                // Configuration manager header.
#include "stringutility.h"           // String utility functions header.
#include "manpage.h"                 // ManPage generation and display header.
#include "version.h"                 // Version/identity contract - see component_display() below.
#include "log.h"               // Logging system header.

/* Include the treeclone files */
#include "treeclone.h"

// ------------------------------------------------------------
// Identity constants - the one canonical version/identity for this binary. run() (see pmake.c,
// part of the pmake project) reads MAJOR/MINOR straight out of this file to name the output
// binary; manpage_display()/component_display() below read the same pair - no second,
// independently-bumpable copy anywhere.
// ------------------------------------------------------------
#define APP_NAME    "treeclone"
#define MAJOR       1
#define MINOR       3

#define AUTHOR      "Patrik Eigenmann"
#define EMAIL       "p.eigenmann72@gmail.com"
#define LICENSE     "GNU GPL 3.0"
#define BUILD_DATE  __DATE__

// -------------------------------------------------------------------------------------------
// manpage_display - This function displays a familiar UNIX-style manpage tailored for
// treeclone. Declared as an extern contract in shared/toolbox/help/manpage.h - implemented here
// in main.c because each application has its own specific content to present.
// -------------------------------------------------------------------------------------------
void manpage_display() {

    log_info("Assembling and displaying the manpage content.");
    debug_info("Assembling and displaying the manpage content.");

    int major = MAJOR;
    log_info("Setting major version to %02d.", major);
    debug_info("Setting major version to %02d.", major);

    int minor = MINOR;
    log_info("Setting minor version to %02d.", minor);
    debug_info("Setting minor version to %02d.", minor);

    // Define the filename of the manpage content
    char *name = NULL;
    log_info("Setting application name to NULL.");
    debug_info("Setting application name to NULL.");

    append_format(&name, APP_NAME);
    log_verbose("Appended application name: %s.", name);
    debug_info("Appended application name: %s.", name);

    char *synopsis = NULL;
    log_info("Setting synopsis to NULL.");
    debug_info("Setting synopsis to NULL.");

    append_format(&synopsis, "      treeclone [--exclude:csv] [--debug[:level]] [--keywords:csv]\n");
    append_format(&synopsis, "      treeclone [-h | -H | -help | -Help | -?] [--version]");
    log_info("Built synopsis content.");
    debug_info("Built synopsis content.");

    char *description = NULL;
    log_info("Setting description to NULL.");
    debug_info("Setting description to NULL.");

    append_format(&description, "      treeclone - as the name suggests, this is a simple clone of the CLI tree.\n");
    log_info("Built description content.");
    debug_info("Built description content.");

    char *options = NULL;
    log_info("Setting options to NULL.");
    debug_info("Setting options to NULL");

    append_format(&options, "      --exclude:csv, --exclude=csv\n");
    append_format(&options, "      Comma-separated patterns to exclude from the tree, matched as a plain\n");
    append_format(&options, "      substring against each entry's name (no globbing). \".txt\" excludes\n");
    append_format(&options, "      every file whose name contains it (e.g. any *.txt file); \".git/\" (a\n");
    append_format(&options, "      trailing slash) excludes that exact directory name; a bare word like\n");
    append_format(&options, "      \"bin\" excludes anything matching that pattern - a bin/ directory or\n");
    append_format(&options, "      any file containing \"bin\" in its name. Merges with the built-in\n");
    append_format(&options, "      defaults (*.tmp, tmp/, .vscode, .git/, .DS_Store, bin/, build/), not\n");
    append_format(&options, "      a replacement for them. Either : or = works.\n");
    append_format(&options, "\n");
    append_format(&options, "      --debug, --debug:<level>, --debug=<level>\n");
    append_format(&options, "      Enables treeclone's own runtime diagnostic output. --debug alone shows\n");
    append_format(&options, "      everything; --debug:<level> narrows it to verbose, info, warn, error, or all.\n");
    append_format(&options, "      Either : or = works.\n");
    append_format(&options, "\n");
    append_format(&options, "      --keywords:<csv>, --keywords=<csv>\n");
    append_format(&options, "      Narrows treeclone's own diagnostic output (see --debug above) to lines\n");
    append_format(&options, "      tagged with one of the given comma-separated keywords. Either : or = works.\n");
    append_format(&options, "\n");
    append_format(&options, "      -h, -H, -help, -Help, -?\n");
    append_format(&options, "      Do you need help? Any of these flags will open the application's manpage.\n");
    append_format(&options, "      This UNIX-style help file, familiar to developers and system administrators,\n");
    append_format(&options, "      is integrated into treeclone itself. The beauty of this approach is that anyone\n");
    append_format(&options, "      working on macOS, BSD, UNIX, or Linux will instantly feel at home with the layout.\n");
    append_format(&options, "      Think of it as your built-in guide whenever you need more insight into the\n");
    append_format(&options, "      program treeclone.\n");
    append_format(&options, "\n");
    append_format(&options, "      --version\n");
    append_format(&options, "      Prints the tool's identity block and exits.\n");
    log_info("Built options content.");
    debug_info("Built options content.");

    char *license = NULL;
    log_info("Setting license to NULL.");
    debug_info("Setting license to NULL.");

    append_format(&license, "      Copyright 2024 Free Software Foundation, Inc. License GPLv3+: GNU GPL version 3\n");
    append_format(&license, "      or later <https://gnu.org/licenses/gpl.html>. This is free software: you are free\n");
    append_format(&license, "      to change and redistribute it. There is NO WARRANTY, to the extent permitted by law.\n");
    log_info("Built license content.");
    debug_info("Built license content.");

    // Create the manpage in the file
    log_info("Initializing manpage with assembled content.");
    debug_info("Initializing manpage with assembled content.");
    manpage_init(major, minor, name, synopsis, description, options, license);

    // Free up the memory.
    free(name);
    log_info("Freed memory allocated for name.");
    debug_info("Freed memory allocated for name.");

    free(synopsis);
    log_info("Freed memory allocated for synopsis.");
    debug_info("Freed memory allocated for synopsis.");

    free(description);
    log_info("Freed memory allocated for description.");
    debug_info("Freed memory allocated for description.");

    free(options);
    log_info("Freed memory allocated for options.");
    debug_info("Freed memory allocated for options.");

    free(license);
    log_info("Freed memory allocated for license.");
    debug_info("Freed memory allocated for license.");
}

// -------------------------------------------------------------------------------------------
// component_display - Prints the tool's identity block: name, version, author, contact,
// license, and build date. Used when a version flag is provided. Declared as an extern
// contract in shared/toolbox/help/version.h - implemented here in main.c because each
// application has its own specific identity to present.
// -------------------------------------------------------------------------------------------
void component_display(void) {
    printf("%s - Version %02d.%02d\n", APP_NAME, MAJOR, MINOR);
    printf("Author:  %s\n", AUTHOR);
    printf("eMail:   %s\n", EMAIL);
    printf("License: %s\n", LICENSE);
    printf("Build Date: %s\n", BUILD_DATE);
}

// -------------------------------------------------------------------------------------------
// is_version_triggered - Evaluates the command-line arguments to determine if any version
// flags are present. It checks for "--version", "-version", or "-v" flags, anywhere in argv -
// not a shared toolbox contract like manpage_is_help_triggered() (that one's declared in
// manpage.h), just a local helper.
//
// @param argc   The number of command-line arguments passed to the program.
// @param argv   The array of command-line argument strings.
// @return       1 if a version flag is detected, 0 otherwise.
// -------------------------------------------------------------------------------------------
static int is_version_triggered(int argc, char *argv[]) {
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--version") == 0 ||
            strcmp(argv[i], "-version") == 0 ||
            strcmp(argv[i], "-v") == 0) {
            return 1;
        }
    }
    return 0;
}

// -------------------------------------------------------------------------------------------
// main - This function marks the beginning of execution for any C program. It serves as the
// central coordinator, handling command-line arguments, initializing subsystems, and directing
// the overall flow of the application. From here, the program invokes its core routines,
// manages resources, and produces output. The main function embodies the universal convention
// of C: every application, regardless of purpose or domain, begins its journey here.
//
// @param argc   The number of command-line arguments passed to the program.
// @param argv   The array of command-line argument strings.
// @return       EXIT_SUCCESS (0) on successful execution, or an error code otherwise.
// -------------------------------------------------------------------------------------------
int main(int argc, char **argv) {

    debug_parse_args(argc, argv); // --debug/--debug=<level>, --keywords=<csv> - see debug.h.
    setConsoleUTF8();  // Enable UTF-8 output on Windows console.

    // The very first thing an application needs is a working logging system.
    log_init(LOG_ALL);  // Initialize logging system with all levels enabled.

    // After that, we need to initialize the configuration if it has one.
    config_init();

    // And now, let's see if the manpage is triggered, because if it is, the display of
    // the manpage will end the application on QTRL + Z I believe.
    if (manpage_is_help_triggered(argc, argv)) {
        manpage_display();
        return EXIT_SUCCESS;
    }

    // Version flag check: If the user requests version information, display it and exit.
    if (is_version_triggered(argc, argv)) {
        component_display();
        return EXIT_SUCCESS;
    }
    
    // After all that, we can actually start the application and start with the initialization
    // of some properties and variables. Also, debugging and logging is ready to go.
    debug_info("Start the application %s.", argv[0]);
    log_info("Start the application %s.", argv[0]);
    
    // Define and initialize if necessary all variables used in the project.
    Entry entries[1024];                        // Array of entries. An entry can be a folder or a file.

    // check if the parent (active directory) is a folder!
    // If not, there is something estancially wrong with the file system.
    DIR *dir = opendir(".");
    if (!dir) {
        debug_err("Active directory is not a folder!");
        log_err("Active directory is not a folder!");
        return EXIT_FAILURE;
    }

    struct dirent *entry;                       // Directory entry.
    char path[PATH_MAX];                        // Absolut path.

    char cwd[PATH_MAX];                         // Relative path.
    getcwd(cwd, sizeof(cwd));                   // Getting the active directory

    char *basename = strrchr(cwd, '/');         // Storing the active directory name in basename/
    basename = basename ? basename + 1 : cwd;   // If basename exists, skip past the slash; otherwise use cwd as fallback 

    debug_info("Active directory: %s", basename);
    log_info("Active directory: %s", basename);

    char *cli_excludes = NULL;                  // Let's start preparing for --exclude

    // Scan for --exclude:<csv> / --exclude=<csv>, same convention as --debug/--keywords
    // (see debug.h) - either separator works, one argv token, no separate value argument.
    static const char *exclude_prefixes[] = { "--exclude=", "--exclude:" };
    for (int i = 1; i < argc; i++) {
        for (size_t p = 0; p < 2; p++) {
            size_t plen = strlen(exclude_prefixes[p]);
            if (strncmp(argv[i], exclude_prefixes[p], plen) == 0) {
                cli_excludes = argv[i] + plen;
                debug_info("CLI exclusion filter detected: %s", cli_excludes);
                log_info("CLI exclusion filter detected: %s", cli_excludes);
                break;
            }
        }
    }

    // Get the standard excludes from the config memory.
    const char *default_excludes = config_get_string("App.ExtractFilter");

    // We need this final string to merge the config filters and the command line filters.
    char *final_excludes = NULL;

    // Here is where the merge happens
    if (default_excludes && cli_excludes) {
        append_format(&final_excludes, "%s,%s", default_excludes, cli_excludes);
    } else if (cli_excludes) {
        append_format(&final_excludes, "%s", cli_excludes);
    } else if (default_excludes) {
        append_format(&final_excludes, "%s", default_excludes);
    }

    debug_info("Final exclusion filter: %s", final_excludes);
    log_info("Final exclusion filter: %s", final_excludes);

    // Store merged filter back into config so it is ready for walk().
    if (final_excludes) {
        debug_info("Rewrite exclusion filter: %s in config", final_excludes);
        log_info("Rewrite exclusion filter: %s in config", final_excludes);
        config_add("App.ExtractFilter", final_excludes);
    }

    // Here we start with variables used for the application purpose.
    int count = 0;                              // This is the level of subfolders we are in.
    const char *excludes = final_excludes;      // convenience alias.

    // We are entering the main loop for the tree building sequence.
    debug_info("Entering the main loop for tree building in memory.");
    log_info("Entering the main loop for tree building in memory.");
    while ((entry = readdir(dir)) != NULL) {

        // Calling a dir or ls -l the first two entries are just the active directory
        // and the directory before that. So, cd .. works. We don't need that. The
        // Tree should start cleanly with the active directory. {Please notice, I do
        // not call it project, because project can be a file, active directory is always a
        // directory.}
        if (strcmp(entry->d_name, ".") == 0 ||
            strcmp(entry->d_name, "..") == 0){
            debug_info(". .. Exclusion");
            log_info(". .. Exclusion");
            continue;
        }

        // Safely build a formatted path string like "path/filename" without overflowing memory.
        snprintf(path, sizeof(path), "./%s", entry->d_name);

        struct stat st;                                         // Create a stat struct.
        if (stat(path, &st) != 0){
            debug_info("Check status of %s went wrong.", path);
            log_info("Check status of %s went wrong.", path);
            continue;
        }

        int is_dir = S_ISDIR(st.st_mode);

        // Now we have enough information about the filters (and, crucially, whether this
        // entry is a directory - a directory-only token like ".git/" needs that to decide
        // whether it applies at all), here we apply all the exclusion filters, so that
        // unwanted folders and files are not shown in a clean tree display.
        if (is_excluded(entry->d_name, is_dir, excludes)) {
            debug_info("Check exclusions: %s with %s.", entry->d_name, excludes);
            log_info("Check exclusions: %s with %s", entry->d_name, excludes);
            continue;
        }

        debug_info("Add entry %s to the tree.", entry->d_name);
        log_info("Add entry %s to the tree.", entry->d_name);
        strncpy(entries[count].name, entry->d_name, PATH_MAX);  // Copy filename into storage.
        entries[count].is_dir = is_dir;                          // Check if it is a directory
        debug_info("Increase counter %d by 1.", count);
        log_info("Increase counter %d by 1.", count);
        count++;    // Tree branch done, move on.
    }

    debug_info("Close directory");
    log_info("Close directory");
    closedir(dir);  // Close the directory we are in.

    // It performs a stable, explicit, two‑pass comparison over the entries[] array to ensure:
    // 1.  Directories come before files.
    // 2.  Names are sorted alphabetically within each group.
    debug_info("Applying a naive O(n²) swap sort. It's dumb, but directories are small.");
    log_info("Applying a naive O(n²) swap sort. It's dumb, but directories are small.");
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {

            int swap = 0;

            if (entries[i].is_dir != entries[j].is_dir) {
                if (entries[j].is_dir)
                    swap = 1;
            } else {
                if (strcmp(entries[i].name, entries[j].name) > 0)
                    swap = 1;
            }

            if (swap) {
                debug_info("Swap entries: %s with %s.", entries[i].name, entries[j].name);
                log_info("Swap entries: %s with %s.", entries[i].name, entries[j].name);
                Entry tmp = entries[i];
                entries[i] = entries[j];
                entries[j] = tmp;
            }
        }
    }

    // The entries are checked and sorted, now we can start displaying the result.
    // We start with the base (root/project) name.
    debug_info("Uff, after all that we finally get to output the tree starting with %s.", basename);
    log_info("Uff, after all that we finally get to output the tree starting with %s.", basename);
    printf("%s/\n", basename);

    // And now we are moving into the hirarchical structure of the active directory.
    for (int i = 0; i < count; i++) {

        // Safely build a formatted path string like "path/filename" without overflowing memory.
        snprintf(path, sizeof(path), "./%s", entries[i].name);

        int is_last = (i == count - 1);                             // Check if it is the last folder.
        const char *symbol = is_last ? "└── " : "├── ";             // Nice symbols to create a human readable tree.

        // check if the entry is a directory.
        if (entries[i].is_dir) {
            // If it is a directory, print it as a directory.
            debug_info("Directory: %s.", entries[i].name);
            log_info("Directory: %s.", entries[i].name);
            printf("%s%s/\n", symbol, entries[i].name);
            // And then walk recursively throught the new directory.
            walk(path, basename, entries[i].name, 1, excludes);
        } else {
            // If it is a file, just display it as a file.
            debug_info("File: %s.", entries[i].name);
            log_info("File: %s.", entries[i].name);
            printf("%s%s\n", symbol, entries[i].name);
        }
    }

    // Whole program went through and was successfull.
    return EXIT_SUCCESS;
}
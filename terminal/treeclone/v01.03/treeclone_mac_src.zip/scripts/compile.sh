#!/bin/bash
# ------------------------------------------------------------------------------------
# Script:       compile.sh
# Description:  Builds one tool in this project by name (its folder must contain a
#               matching <tool>.pmake). Forwards to pmake from inside that folder, then
#               normalizes the result. bin/'s top level always shows the same
#               ever-accumulating build history, in every repo - pmake's own
#               version-suffixed output (bin/<tool>_vXX.XX), left exactly where pmake
#               wrote it, so you can always tell what's actually been compiled. What
#               happens next differs by repo: in the terminal project, a flat
#               bin/<tool> copy (no suffix) is the whole deliverable - a CLI tool is
#               just a binary, nothing else to organize. Everywhere else (legacy,
#               arcade, ...), bin/<tool>/ becomes a self-contained deployable copy (the
#               binary, plain name, plus the project's own resources/ synced in via
#               rsync, *.db files excluded - a live database bin/<tool>/<tool> itself
#               writes into is never something this script should overwrite from the
#               source tree's own copy) - so a project reading resources/skin/,
#               .../config/, etc. via a relative path works the same run straight from
#               bin/<tool>/ as it does from its source folder), and bin/<tool>.lnk is a
#               top-level symlink into it for convenience (the .lnk suffix avoids
#               colliding with the bin/<tool>/ folder's own name). Either way, this
#               script doesn't build a bundle, an install, or anything else - see
#               scripts/install.sh for what happens next.
# ------------------------------------------------------------------------------------
# Author:       Patrik Eigenmann
# eMail:        p.eigenmann@gmx.net
# ------------------------------------------------------------------------------------
# Change Log:
# Sun 2026-08-23 File created, ported from legacy's own copy - LEGACY_ROOT      Version: 00.01
#                renamed TERMINAL_ROOT, same as arcade's copy renames it
#                ARCADE_ROOT. Otherwise identical.
# Mon 2026-08-24 Removed -DDEBUG from the help text - pmake dropped that flag   Version: 00.02
#                entirely (see pmake's own changelog); any extra argument here
#                still forwards straight through to pmake, so its real flags
#                (-DDEBUG for the target project's own build, --debug/--keywords
#                for pmake's own diagnostics) work exactly as pmake documents
#                them, this script just never claimed the wrong one before.
# Fri 2026-08-28 One script, no more per-repo renamed copies (TERMINAL_ROOT/     Version: 00.03
#                LEGACY_ROOT/ARCADE_ROOT drifting out of sync was already a
#                real bug - this repo's own copy still said TERMINAL_ROOT).
#                PROJECT_ROOT now detects its own repo by folder name at
#                runtime and installs accordingly: "terminal" gets the old
#                flat bin/<tool> binary (a CLI tool is just a binary); every
#                other repo gets bin/<tool>/ - the binary plus a copy of the
#                project's own resources/ tree (if it has one), so a built
#                project is self-contained and doesn't need its source
#                checkout to run.
# Fri 2026-08-28 Both install branches now clear away a stale install of the   Version: 00.04
#                OTHER kind first (a leftover flat bin/<tool> file breaks
#                mkdir -p for the folder form; a leftover bin/<tool>/
#                directory breaks mv for the flat form) - caught by actually
#                running this against cobs, which still had its pre-this-
#                script flat bin/cobs binary sitting there.
# Fri 2026-08-28 Installing the built binary is now a cp, not a mv - mv        Version: 00.05
#                erased pmake's own version-suffixed file (pmake_mac_v01.07,
#                say), so bin/ only ever showed whatever was built most
#                recently, with no way to tell what versions had actually
#                been compiled. Now both the version-suffixed original and
#                the plain bin/<tool>(/<tool>) copy live in bin/ side by
#                side.
# Fri 2026-08-28 Real fix, not a patch: the bin/<tool>/<tool> folder this      Version: 00.06
#                script built for non-terminal projects was pure redundancy -
#                it existed only so install.sh could later build a real
#                bundle out of it, duplicating work across two scripts for no
#                reason. Bundle-building (icon resolution, Info.plist, the
#                ncurses/otool -L TTY-wrapper decision - all of it, moved
#                verbatim from install.sh's install_macos_bundle()) now
#                happens HERE, right after the flat normalize step, producing
#                bin/<tool>.app directly. install.sh no longer builds
#                anything - it only copies whichever artifact this script
#                already produced.
# Fri 2026-08-28 The flat normalize step's cp now clears away a stale         Version: 00.07
#                bin/<tool>/ directory first - caught immediately by
#                actually running this against arcade's pac-man, which still
#                had one from before Version 00.06 retired that folder
#                convention. Plain cp refuses to overwrite a directory with a
#                file, and (worth knowing) that refusal didn't trip set -e -
#                the script kept going and built a bundle from a binary that
#                was never actually copied.
# Fri 2026-08-28 Every step now announces itself (Normalizing: ..., Bundling: Version: 00.08
#                ..., the ncurses-wrapper decision, which icon it picked or
#                that none was found) - previously the only visible output
#                was pmake's own "Compiling:" line, so the normalize/bundle
#                steps this script does on top of that were invisible.
# Fri 2026-08-28 Reverted Version 00.06: "compile never had to decide         Version: 00.09
#                between terminal and legacy or arcade - it only compiles.
#                what decides is install" - correct, and cleaner than what
#                00.06 built. This script goes back to being a pure builder:
#                compile, then normalize to a flat bin/<tool>, full stop - no
#                REPO_NAME, no bundle, no icon/otool logic, none of it. All
#                of that (build_icns/find_icon_src/build_macos_bundle, the
#                terminal-or-not branch) moves back to install.sh, which
#                already owns that decision and now owns building the
#                artifact that decision implies, too - "compile" builds one
#                thing, "install" decides what that thing becomes.
# Fri 2026-08-28 Deliberate partial reversal of Version 00.09's own           Version: 00.10
#                principle: the flat bin/<tool> dev/test binary had no
#                resources/ next to it once 00.09 stopped building a
#                bin/<tool>/ folder - fine for terminal (no resources/
#                concept at all), a real gap for legacy/arcade (a project
#                reading e.g. resources/skin/<tool>.skin via a path relative
#                to its own working directory can't find it when run
#                straight from bin/, unlike from its own source folder).
#                REPO_NAME is back, but scoped narrowly: terminal keeps
#                today's flat cp, unchanged. Everywhere else now gets
#                bin/<tool>/ again - not quite the pre-00.06 shape though:
#                this one holds the real version-suffixed build (moved, not
#                copied, so it isn't duplicated at bin/'s top level too), a
#                bin/<tool>/<tool> symlink to whichever version that
#                currently is, and a copy of the project's own resources/ -
#                a real, standalone, runnable dev copy, not just a
#                feed-through for install.sh to consume. install.sh's own
#                FLAT_BIN lookup updated to match (bin/<tool>/<tool>, not
#                bin/<tool>, for non-terminal - see its own changelog).
# Fri 2026-08-28 Version 00.10 got the actual shape wrong - moving the        Version: 00.11
#                version-suffixed build INTO bin/<tool>/ meant bin/'s top
#                level no longer showed the accumulating build history the
#                way terminal's own bin/ still does, and a bin/<tool>/<tool>
#                symlink-to-a-file-in-the-same-folder wasn't actually adding
#                anything over just copying it there directly. Corrected,
#                per explicit direction: pmake's version-suffixed output now
#                stays exactly where pmake put it, untouched, at bin/'s top
#                level (the same flat, ever-accumulating history terminal
#                has) - copied (not moved) from there into bin/<tool>/<tool>
#                (a real file, the self-contained deployable unit, alongside
#                a fresh copy of resources/). A new bin/<tool>.lnk symlink at
#                bin/'s top level points into that folder for convenience -
#                named with a .lnk suffix specifically so it doesn't collide
#                with the bin/<tool>/ folder's own name. install.sh's own
#                bin/<tool>/<tool> lookup didn't need to change - it already
#                pointed at the right path, just resolving through a real
#                file now instead of a symlink.
# Sat 2026-08-29 Both binary installs (bin/<tool>/<tool> and terminal's own    Version: 00.12
#                flat bin/<tool>) now copy to a .new temp name and mv it into
#                place, instead of cp'ing straight over the existing file -
#                caught directly: rebuilding and relaunching the same path in
#                quick succession (scripts/compile.sh <tool> && scripts/
#                term.sh <tool>, repeated - exactly this script's own usual
#                workflow) could leave the kernel's code-signing validation
#                for that inode out of sync with its just-overwritten
#                content, killing the very next launch with SIGKILL (Code
#                Signature Invalid). mv within the same directory is atomic
#                and always produces a fresh inode, so there's nothing stale
#                left to race against.
# Sun 2026-08-31 The resources copy is now `rsync -a --delete --exclude=      Version: 00.13
#                '*.db'`, not `rm -rf` + `cp -R` - caught directly, almost
#                losing real data: cobs's own resources/db/cobs.db is a LIVE
#                database an already-running bin/cobs/cobs writes into, not a
#                static resource this script should ever treat as disposable
#                and blindly overwrite from the source tree's own (blank)
#                copy. Everything else still syncs exactly as before
#                (including deleting anything removed from source) - only
#                *.db files are left alone entirely, in both directions.
# ------------------------------------------------------------------------------------

show_help() {
cat << EOF
NAME
    compile.sh - build one tool/project's binary and normalize it in bin/

SYNOPSIS
    scripts/compile.sh <tool> [pmake args...]

DESCRIPTION
    Builds the <tool> folder using its <tool>.pmake file. pmake's own
    version-suffixed output always stays at bin/'s top level, untouched. In
    the terminal project, a flat bin/<tool> copy (no suffix) is the whole
    deliverable. Everywhere else, bin/<tool>/ becomes a self-contained
    deployable copy (the binary, plain name, plus the project's own
    resources/), and bin/<tool>.lnk is a top-level symlink into it for
    convenience. See scripts/install.sh for what happens to that next (a CLI
    tool copied flat, or a real project turned into a double-clickable
    bundle). Any extra
    arguments are forwarded straight through to pmake - see 'pmake -h' for
    what it accepts (-DDEBUG, --debug, --keywords). Run from anywhere inside
    the project.

EXAMPLES
    scripts/compile.sh pmake
    scripts/compile.sh enigma -DDEBUG
    scripts/compile.sh enigma --debug:warn
EOF
}

case "$1" in
    -h|-help|-\?|"")
        show_help
        exit 0
        ;;
esac

set -e

TOOL="$1"
shift

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOL_DIR="$PROJECT_ROOT/$TOOL"

if [ ! -d "$TOOL_DIR" ]; then
    echo "No such tool folder: $TOOL_DIR"
    exit 1
fi

echo "Building $TOOL..."
cd "$TOOL_DIR"
pmake "$TOOL" "$@"

# pmake names its output "<tool>_<suffix>" (version, and OS if is_os_gnostic=on) and
# always writes it flat into bin/ - normalizing it below is this script's own job, not
# pmake's.
BUILT="$(ls -t "$PROJECT_ROOT/bin/${TOOL}"_* 2>/dev/null | head -n1)"
if [ -z "$BUILT" ]; then
    echo "pmake did not produce a binary in $PROJECT_ROOT/bin."
    exit 1
fi

REPO_NAME="$(basename "$PROJECT_ROOT")"

if [ "$REPO_NAME" = "terminal" ]; then
    # A CLI tool is just a binary, the same way ls/cat/cp/rm always were - a flat,
    # OS/version-suffix-free copy is the whole deliverable, no resources/ concept at all.
    # Clears away a stale bin/<tool>/ directory first, in case this project was last
    # built by an older version of this script.
    FLAT_BIN="$PROJECT_ROOT/bin/$TOOL"
    echo "Normalizing: bin/$(basename "$BUILT") -> bin/$TOOL"
    if [ -d "$FLAT_BIN" ]; then
        rm -rf "$FLAT_BIN"
    fi
    # Atomic copy-then-rename, same reasoning as the non-terminal branch below - see its own
    # comment for the macOS code-signing bug this avoids.
    cp "$BUILT" "$FLAT_BIN.new"
    chmod +x "$FLAT_BIN.new"
    mv -f "$FLAT_BIN.new" "$FLAT_BIN"

    echo "Done. Type 'bin/$TOOL' (from $PROJECT_ROOT) to run, or scripts/install.sh $TOOL to install it."
else
    # pmake's own version-suffixed output ($BUILT) stays exactly where pmake put it, at
    # bin/'s top level, untouched - that's the flat, ever-accumulating build history
    # (bin/<tool>_vXX.XX, bin/<tool>_vYY.YY, ...), same idea as the terminal project's
    # own bin/, just without a plain flat name competing for the same spot.
    #
    # bin/<tool>/ is the self-contained, deployable unit: a real copy of the binary
    # (plain name, no version/OS suffix) plus a fresh copy of the project's own
    # resources/ (skin, config, db, ...) - so a project reading e.g.
    # resources/skin/<tool>.skin via a path relative to its own working directory finds
    # it the same way whether run from bin/<tool>/ or from its own source folder. This
    # folder is what install.sh turns into a bundle, and what you'd copy/zip elsewhere
    # to hand someone a working copy.
    #
    # bin/<tool>.lnk is a symlink into that folder, purely for convenience - so you can
    # type/tab-complete bin/<tool>.lnk from bin/'s own top level instead of digging into
    # bin/<tool>/<tool>. The .lnk suffix exists only to avoid colliding with the
    # bin/<tool>/ folder's own name - a symlink and a directory can't share one name.
    #
    # Clears away a stale bin/<tool> FILE first (mkdir -p fails if a plain file already
    # sits at that path) - in case this project was last built by an older version of
    # this script, when bin/<tool> itself used to be that flat file.
    BIN_DIR="$PROJECT_ROOT/bin/$TOOL"
    if [ -f "$BIN_DIR" ]; then
        rm -f "$BIN_DIR"
    fi
    mkdir -p "$BIN_DIR"

    echo "Copying: bin/$(basename "$BUILT") -> bin/$TOOL/$TOOL"
    # Copy to a temp name, then atomically rename into place - overwriting bin/<tool>/<tool>
    # in-place (the old plain "cp" here) hit a real macOS bug: rebuilding and relaunching the
    # same path in quick succession (e.g. scripts/compile.sh <tool> && scripts/term.sh <tool>,
    # repeated) can leave the kernel's code-signing validation for that inode out of sync with
    # its just-overwritten content, killing the very next launch with SIGKILL (Code Signature
    # Invalid) - not a bug in the tool itself. mv within the same directory is atomic and always
    # produces a fresh inode, so there's nothing stale left to race against.
    cp "$BUILT" "$BIN_DIR/$TOOL.new"
    chmod +x "$BIN_DIR/$TOOL.new"
    mv -f "$BIN_DIR/$TOOL.new" "$BIN_DIR/$TOOL"

    if [ -d "$TOOL_DIR/resources" ]; then
        echo "Copying: $TOOL/resources -> bin/$TOOL/resources (except *.db - see this script's own changelog)"
        mkdir -p "$BIN_DIR/resources"
        rsync -a --delete --exclude='*.db' "$TOOL_DIR/resources/" "$BIN_DIR/resources/"
    fi

    LNK="$PROJECT_ROOT/bin/$TOOL.lnk"
    if [ -d "$LNK" ]; then
        rm -rf "$LNK"
    fi
    echo "Linking: bin/$TOOL.lnk -> $TOOL/$TOOL"
    ln -sf "$TOOL/$TOOL" "$LNK"

    echo "Done. Type 'bin/$TOOL.lnk' or 'bin/$TOOL/$TOOL' (from $PROJECT_ROOT) to run, or scripts/install.sh $TOOL to install it."
fi

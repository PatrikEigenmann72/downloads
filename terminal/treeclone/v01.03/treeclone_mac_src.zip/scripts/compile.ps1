# ------------------------------------------------------------------------------------
# Script:       compile.ps1
# Description:  Builds one tool in this project by name (its folder must contain a
#               matching <tool>.pmake). Forwards to pmake from inside that folder, then
#               installs the result into bin\ - a flat bin\<tool>.exe binary in the
#               terminal project (a CLI tool is just a binary, same as ls/cat/cp always
#               were), or a self-contained bin\<tool>\ directory everywhere else (legacy,
#               arcade, ...) - the binary plus a copy of the project's own resources\
#               tree, if it has one, so a built project can be run or copied elsewhere
#               without depending on the source checkout it was built from. Windows port
#               of compile.sh - see that file's own changelog for shared history.
# ------------------------------------------------------------------------------------
# Author:       Patrik Eigenmann
# eMail:        p.eigenmann@gmx.net
# ------------------------------------------------------------------------------------
# Change Log:
# Mon 2026-08-24 File created, ported from compile.sh.                       Version: 00.01
# Fri 2026-08-28 Brought up to compile.sh's Version 00.04 standard: no more   Version: 00.02
#                terminal-only assumption - $RepoName now detects the repo
#                by folder name at runtime and installs accordingly (see
#                compile.sh's own changelog for the full why). Both install
#                branches clear away a stale install of the OTHER kind
#                first, same as compile.sh. Not runnable/testable on this
#                machine (no pwsh available) - ported by hand, matching
#                compile.sh line for line as closely as PowerShell allows;
#                verify on a real Windows box before relying on it.
# Fri 2026-08-28 Installing the built binary is now Copy-Item, not           Version: 00.03
#                Move-Item - same fix as compile.sh's own Version 00.05, for
#                the same reason: Move-Item erased pmake's own version-
#                suffixed .exe, leaving no way to tell what versions had
#                actually been compiled.
# ------------------------------------------------------------------------------------

param(
    [Parameter(Position = 0)]
    [string]$Tool,

    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$PmakeArgs
)

function Show-Help {
    @"
NAME
    compile.ps1 - build one tool/project and install it into bin\

SYNOPSIS
    scripts\compile.ps1 <tool> [pmake args...]

DESCRIPTION
    Builds the <tool> folder using its <tool>.pmake file, then installs the
    result into bin\ - a flat bin\<tool>.exe binary in the terminal project,
    or a self-contained bin\<tool>\ directory (binary + a copy of the
    project's own resources\ tree, if any) in every other project (legacy,
    arcade, ...). Any extra arguments are forwarded straight through to
    pmake - see 'pmake -h' for what it accepts (-DDEBUG, --debug,
    --keywords). Run from anywhere inside the project.

EXAMPLES
    scripts\compile.ps1 pmake
    scripts\compile.ps1 enigma -DDEBUG
    scripts\compile.ps1 enigma --debug:warn
"@
}

if (-not $Tool -or $Tool -eq '-h' -or $Tool -eq '-help' -or $Tool -eq '-?') {
    Show-Help
    exit 0
}

$ErrorActionPreference = 'Stop'

$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$ToolDir = Join-Path $ProjectRoot $Tool

if (-not (Test-Path $ToolDir -PathType Container)) {
    Write-Host "No such tool folder: $ToolDir"
    exit 1
}

Write-Host "Building $Tool..."
Push-Location $ToolDir
try {
    & pmake $Tool @PmakeArgs
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
finally {
    Pop-Location
}

# pmake names its output "<tool>_<suffix>.exe" (version, and OS if is_os_gnostic=on) and
# always writes it flat into bin\ - installation (below) is this script's job, not pmake's.
$Built = Get-ChildItem -Path (Join-Path $ProjectRoot 'bin') -Filter "$Tool`_*.exe" -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending |
    Select-Object -First 1

if (-not $Built) {
    Write-Host "pmake did not produce a binary in $ProjectRoot\bin - nothing to install."
    exit 1
}

$RepoName = Split-Path -Leaf $ProjectRoot

if ($RepoName -eq 'terminal') {
    # A CLI tool is just a binary, the same way ls/cat/cp/rm always were - no project
    # folder, nothing else to install alongside it. Clears away a stale bin\<tool>\
    # directory first, in case this tool used to be installed the other way.
    $FlatPath = Join-Path $ProjectRoot "bin\$Tool.exe"
    $StaleDir = Join-Path $ProjectRoot "bin\$Tool"
    if (Test-Path $StaleDir -PathType Container) {
        Remove-Item -Recurse -Force $StaleDir
    }
    Copy-Item -Force $Built.FullName $FlatPath
    Write-Host "Done. Type 'bin\$Tool.exe' (from $ProjectRoot) to run."
}
else {
    # A real project can have its own file structure (resources\, ...), so it gets a
    # self-contained bin\<tool>\ directory - the binary plus a copy of whatever
    # resources\ the project ships, mirroring how a legacy install put an app's own
    # files together in one directory rather than scattering them. Clears away a
    # stale flat bin\<tool>.exe binary first, in case this tool used to be installed
    # the other way.
    $InstallDir = Join-Path $ProjectRoot "bin\$Tool"
    $StaleFile = Join-Path $ProjectRoot "bin\$Tool.exe"
    if (Test-Path $StaleFile -PathType Leaf) {
        Remove-Item -Force $StaleFile
    }
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Copy-Item -Force $Built.FullName (Join-Path $InstallDir "$Tool.exe")

    $ResourcesSrc = Join-Path $ToolDir 'resources'
    if (Test-Path $ResourcesSrc -PathType Container) {
        $ResourcesDst = Join-Path $InstallDir 'resources'
        if (Test-Path $ResourcesDst) {
            Remove-Item -Recurse -Force $ResourcesDst
        }
        Copy-Item -Recurse -Force $ResourcesSrc $ResourcesDst
    }

    Write-Host "Done. Type 'bin\$Tool\$Tool.exe' (from $ProjectRoot) to run."
}

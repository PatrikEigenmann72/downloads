// -----------------------------------------------------------------------------------------------
// debug.c - Implements debug.h: on-demand console diagnostics for active troubleshooting. Plain
// C, no ncurses dependency. Ported from legacy/arcade's legacy_debug.c with names de-prefixed
// (legacy_debug_* -> debug_*, LEGACY_DEBUG_* -> DEBUG_*) and the environment variable renamed
// LEGACY_DEBUG -> TOOLBOX_DEBUG; logic otherwise untouched.
//
// Prints to stderr, not stdout - a program built on legacy/arcade's ncurses engine owns stdout
// while its screen is active and redraws it continuously, so writing debug lines there would
// corrupt the screen. stderr is untouched by ncurses, so this is safe to call at any time,
// including from inside a render loop - redirect it to a file (`bin/tool --debug 2>debug.log`)
// and `tail -f debug.log` in another terminal to watch live diagnostics while the tool runs
// normally in the first. For a plain CLI tool with no ncurses screen at all, stderr is still the
// right place for diagnostic chatter - it stays out of anything the tool pipes to another program.
// -----------------------------------------------------------------------------------------------
// Author:      Patrik Eigenmann
// eMail:       p.eigenmann72@gmail.com
// GitHub:      https://github.com/PatrikEigenmann72/terminal
// -----------------------------------------------------------------------------------------------
// Change Log:
// Sun 2026-08-23 File created - ported from legacy/arcade's legacy_debug.c. See      Version: 00.01
//                debug.h's change log for the full history and rationale.
// Tue 2026-09-15 debug_timestamp(): fixed incompatible-pointer-type warning on         Version: 00.02
//                toolchains where timeval.tv_sec (long) and time_t (long long) differ
//                in width, by converting through a time_t temporary before localtime().
// -----------------------------------------------------------------------------------------------
#include "debug.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <sys/time.h>

#define DEBUG_COLOR_RESET   "\x1b[0m"
#define DEBUG_COLOR_VERBOSE "\x1b[90m" // gray
#define DEBUG_COLOR_INFO    "\x1b[34m" // blue
#define DEBUG_COLOR_WARN    "\x1b[33m" // yellow
#define DEBUG_COLOR_ERR     "\x1b[31m" // red

#define DEBUG_MAX_KEYWORDS 16
#define DEBUG_KEYWORD_LEN  32

// The active --keywords filter, split once when set. Empty (count 0) means "no filter" - every
// line that passes the level mask prints, same as before this feature existed.
static char s_active_keywords[DEBUG_MAX_KEYWORDS][DEBUG_KEYWORD_LEN];
static int s_active_keyword_count = 0;

// Splits a comma-separated csv into out[], up to max entries, truncating any token longer than
// a slot. Shared by debug_set_keywords() (the filter) and debug_own_keywords_match() (a call
// site's own keywords), so both use identical parsing.
//
// @param csv        The comma-separated string to split, e.g. "pdf_creation,write_file".
// @param out        Destination array, at least max entries deep.
// @param max        Capacity of out - excess tokens beyond this are silently dropped.
// @param out_count  Set to how many tokens were actually written into out.
static void debug_split_csv(const char *csv, char out[][DEBUG_KEYWORD_LEN], int max, int *out_count) {
    *out_count = 0;
    if (!csv || !*csv) return;

    const char *p = csv;
    while (*p && *out_count < max) {
        const char *comma = strchr(p, ',');
        size_t len = comma ? (size_t)(comma - p) : strlen(p);
        if (len >= DEBUG_KEYWORD_LEN) len = DEBUG_KEYWORD_LEN - 1;

        memcpy(out[*out_count], p, len);
        out[*out_count][len] = '\0';
        (*out_count)++;

        if (!comma) break;
        p = comma + 1;
    }
}

// Lazily resolved on first use rather than requiring an explicit init call: reads TOOLBOX_DEBUG
// once, falls back to DEBUG_NONE (silent - this is the shipped-version experience) if unset or
// unrecognized. A --debug flag (via debug_parse_args()) or an explicit debug_set_level() call
// both override this.
static int s_level_resolved = 0;
static int s_level = DEBUG_NONE;

// Accepts a level name (case-insensitive) or a raw numeric bitmask (e.g. "12" for WARN|ERR).
//
// @param value  The text to parse - a level name or a numeric string.
// @return       The parsed mask, or -1 for anything unrecognized (leaving the caller's current
//               level untouched is the caller's job, not this function's).
static int debug_parse_level(const char *value) {
    if (strcasecmp(value, "none") == 0)    return DEBUG_NONE;
    if (strcasecmp(value, "verbose") == 0) return DEBUG_ALL;
    if (strcasecmp(value, "all") == 0)     return DEBUG_ALL;
    if (strcasecmp(value, "info") == 0)    return DEBUG_INFO | DEBUG_WARN | DEBUG_ERR;
    if (strcasecmp(value, "warn") == 0)    return DEBUG_WARN | DEBUG_ERR;
    if (strcasecmp(value, "error") == 0)   return DEBUG_ERR;

    char *end = NULL;
    long n = strtol(value, &end, 0);
    if (end && *end == '\0') return (int)n;

    return -1;
}

// Reads the TOOLBOX_DEBUG environment variable exactly once, the first time any debug_*() call
// needs to know the active level and nothing has set one explicitly yet.
static void debug_resolve(void) {
    if (s_level_resolved) return;
    s_level_resolved = 1;

    const char *env = getenv("TOOLBOX_DEBUG");
    if (env) {
        int parsed = debug_parse_level(env);
        if (parsed >= 0) s_level = parsed;
    }
}

// Overrides the active level mask directly, bypassing the lazy environment-variable resolution
// in debug_resolve() (this counts as having already resolved).
//
// @param mask  One of DEBUG_NONE/VERBOSE/INFO/WARN/ERR/ALL, or an OR'd combination.
void debug_set_level(int mask) {
    s_level_resolved = 1;
    s_level = mask;
}

// @return The currently active level mask, resolving it from TOOLBOX_DEBUG first if nothing has
//         set one explicitly yet.
int debug_get_level(void) {
    debug_resolve();
    return s_level;
}

// Sets the active keyword filter directly from a comma-separated list.
//
// @param csv  Comma-separated tags to filter on (OR-matched), or "" to clear any filter.
void debug_set_keywords(const char *csv) {
    debug_split_csv(csv, s_active_keywords, DEBUG_MAX_KEYWORDS, &s_active_keyword_count);
}

// Scans argv for --debug/--debug=<level>/--debug:<level> and --keywords=<csv>/--keywords:<csv>,
// applying whichever it finds.
//
// @param argc, argv  Passed straight through from main(). Every argument that isn't one of the
//                     recognized flags is left untouched.
void debug_parse_args(int argc, char **argv) {
    // Accepts either separator ("--debug=warn" or "--debug:warn") - purely a matter of taste,
    // both mean the same thing.
    static const char *debug_prefixes[] = { "--debug=", "--debug:" };
    static const char *keywords_prefixes[] = { "--keywords=", "--keywords:" };

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--debug") == 0) {
            debug_set_level(DEBUG_ALL);
            continue;
        }

        bool matched = false;

        for (size_t p = 0; p < 2; p++) {
            size_t len = strlen(debug_prefixes[p]);
            if (strncmp(argv[i], debug_prefixes[p], len) == 0) {
                int level = debug_parse_level(argv[i] + len);
                if (level >= 0) debug_set_level(level);
                matched = true;
                break;
            }
        }
        if (matched) continue;

        for (size_t p = 0; p < 2; p++) {
            size_t len = strlen(keywords_prefixes[p]);
            if (strncmp(argv[i], keywords_prefixes[p], len) == 0) {
                debug_set_keywords(argv[i] + len);
                break;
            }
        }
    }
}

// Checks a call site's own keyword tags against the active filter - half of
// debug_passes_keyword_filter()'s OR condition, the other half being a bare function-name match.
//
// @param keywords  This call site's own comma-separated tags (a debug_*_tag() macro's first
//                   argument), or NULL/"" for none.
// @return          true if any token in keywords case-insensitively matches any active filter
//                   keyword.
static bool debug_own_keywords_match(const char *keywords) {
    if (!keywords || !*keywords) return false;

    char tokens[DEBUG_MAX_KEYWORDS][DEBUG_KEYWORD_LEN];
    int count = 0;
    debug_split_csv(keywords, tokens, DEBUG_MAX_KEYWORDS, &count);

    for (int i = 0; i < count; i++) {
        for (int j = 0; j < s_active_keyword_count; j++) {
            if (strcasecmp(tokens[i], s_active_keywords[j]) == 0) return true;
        }
    }
    return false;
}

// Decides whether one debug_*()/debug_*_tag() call site should actually print, once its level
// has already passed the level mask.
//
// @param func      The calling function's name, from __func__ via the debug_*() macros.
// @param keywords  This call site's own comma-separated tags, or NULL/"" for none.
// @return          true if the line should print: no filter set (s_active_keyword_count == 0)
//                   means "show everything" - unchanged from before this feature existed.
//                   Otherwise a line passes if func matches a filter keyword (free, since func
//                   is always captured automatically) or if any of keywords do (OR).
static bool debug_passes_keyword_filter(const char *func, const char *keywords) {
    if (s_active_keyword_count == 0) return true;

    for (int j = 0; j < s_active_keyword_count; j++) {
        if (func && strcasecmp(func, s_active_keywords[j]) == 0) return true;
    }

    return debug_own_keywords_match(keywords);
}

// Formats the current wall-clock time for a debug line's timestamp column.
//
// @return A "HH:MM:SS.mmm" timestamp for right now, in a static buffer reused on every call -
//         copy it if you need it to outlive the next debug_timestamp() call.
static const char *debug_timestamp(void) {
    static char buffer[32];
    struct timeval tv;
    gettimeofday(&tv, NULL);
    time_t sec = tv.tv_sec;
    struct tm *t = localtime(&sec);
    snprintf(buffer, sizeof(buffer), "%02d:%02d:%02d.%03d",
             t->tm_hour, t->tm_min, t->tm_sec, (int)(tv.tv_usec / 1000));
    return buffer;
}

// Writes one line to stderr, if level passes the mask and the keyword filter (if any). Called
// via the debug_verbose()/info()/warn()/err() macros (and their _tag() variants), which fill in
// file/func/line from __FILE__/__func__/__LINE__ so callers never pass those by hand.
//
// @param level      Which severity this line is.
// @param level_str  Short label printed in the line ("VRB"/"INF"/"WRN"/"ERR").
// @param file       Source file the call came from (__FILE__).
// @param func       Function the call came from (__func__).
// @param line       Line number the call came from (__LINE__).
// @param keywords   This call site's own comma-separated tags ("" for none).
// @param fmt, ...   A printf-style format string and its arguments - the actual message.
void debug_write(int level, const char *level_str, const char *file, const char *func, int line,
                  const char *keywords, const char *fmt, ...) {
    debug_resolve();
    if (!(s_level & level)) return;
    if (!debug_passes_keyword_filter(func, keywords)) return;

    const char *color = DEBUG_COLOR_INFO;
    if (level == DEBUG_VERBOSE) color = DEBUG_COLOR_VERBOSE;
    if (level == DEBUG_WARN)    color = DEBUG_COLOR_WARN;
    if (level == DEBUG_ERR)     color = DEBUG_COLOR_ERR;

    fprintf(stderr, "%s[%s] %s %s:%d (%s)", color, level_str, debug_timestamp(), file, line, func);
    if (keywords && *keywords) fprintf(stderr, " [%s]", keywords);
    fprintf(stderr, " - ");

    va_list args;
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);

    fprintf(stderr, "%s\n", DEBUG_COLOR_RESET);
    fflush(stderr);
}

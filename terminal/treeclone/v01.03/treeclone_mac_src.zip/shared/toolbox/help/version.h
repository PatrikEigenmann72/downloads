// -----------------------------------------------------------------------------------------------
// version.h - This file exists to give every application a simple, consistent way of
// displaying its own identity: name, version, author, contact, repository, license, and build
// date. By declaring the contract here, we make sure that --version output is not scattered or
// improvised, but instead follows a predictable pattern that developers can rely on and
// contributors can understand.
//
// The purpose is straightforward: applications embed their own identity constants and their own
// component_display() implementation directly in code (in main.c, alongside MAJOR/MINOR - see
// manpage.h's own manpage_display() for the same pattern), and this header just declares the
// contract every application fulfills, so --version behaves the same predictable way everywhere.
// -----------------------------------------------------------------------------------------------
// Author:      Patrik Eigenmann
// eMail:       p.eigenmann72@gmail.com
// GitHub:      https://github.com/PatrikEigenmann72/terminal
// -----------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-08-24 File created.                                                    Version: 00.01
// -----------------------------------------------------------------------------------------------
#ifndef TOOLBOX_HELP_VERSION_H
#define TOOLBOX_HELP_VERSION_H

// ---------------------------------------------------------------------------------------
// component_display - This function prints the application's identity block: name, version,
// author, contact, repository, license, and build date. It's the UNIX-convention counterpart to
// manpage_display() (see manpage.h) - "show me who you are" instead of "show me how to use you"
// - shown when the user passes --version.
//
// Note: This function is declared here but must be implemented in main.c, because each
// application has its own specific identity to present. The module enforces the contract, while
// the application provides the details - same split as manpage_display().
// ---------------------------------------------------------------------------------------
extern void component_display(void);

#endif

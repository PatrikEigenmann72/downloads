// -------------------------------------------------------------------------------------------
// treeclone.h - Who hasn’t used the UNIX tree command to get a quick overview of a directory?
// treeclone is a compact re‑implementation of that idea — a small C program that walks your
// filesystem and prints a clean, readable tree view of folders and files. It’s fast, minimal,
// and configurable, with sensible defaults and a simple exclusion system. If you want a portable,
// dependency‑free tree tool that behaves exactly the way you expect, treeclone has you covered.
// This header file is the kernel definition of the treeclone - the classic UNIX tree tool.
// -------------------------------------------------------------------------------------------
// Author:  Patrik Eigenmann
// eMail:   p.eigenmann72@gmail.com
// -------------------------------------------------------------------------------------------
// Change Log:
// Mon 2026-08-24 Versions 00.01-00.04: initial build-out - the internal              Version: 00.04
//                constants became #define macros, is_version_triggered() and
//                version_display() added. Full entry-by-entry history archived
//                in treeclone.changelog.txt.
// Mon 2026-08-24 Major Release.                                                      Version: 01.00
// Mon 2026-08-24 Removed the manpage_display()/version_display()/                    Version: 01.01
//                is_version_triggered() declarations - all three moved into main.c
//                (see treeclone.c's own changelog for the full reasoning). Removed
//                the GitHub line from the header comment too - wrong (pointed at
//                "helloc") and will change anyway.
// Mon 2026-08-24 is_excluded() gained an is_dir parameter, so a trailing-slash            Version: 01.02
//                token like ".git/" only matches an actual directory - see
//                treeclone.c's own changelog for why.
// -------------------------------------------------------------------------------------------
#ifndef TREECLONE_H
#define TREECLONE_H

#include <limits.h>

// ------------------------------------------------------------
// Entry is a simple data structure to define filesystem entries.
// ------------------------------------------------------------
typedef struct {
    char name[PATH_MAX];
    int is_dir;
} Entry;

// ------------------------------------------------------------
// Treeclone-specific functions
// ------------------------------------------------------------
void walk(const char *path, const char *basename, const char *prefix, int depth, const char *excludes);
int is_excluded(const char *name, int is_dir, const char *exclude);

// -------------------------------------------------------------------------------------------
// config_init - This function is required in every project that uses the Samael framework,
// specifically the config.h module. It defines the initial set of
// configuration values the application needs at startup. Developers implement config_init()
// to add key=value pairs using the config_add() API, such as application name, version,
// labels, numeric values, or other parameters.
//
// The purpose of config_init() is to provide a single, centralized place where an application
// declares its important settings. This makes configuration easy to understand, maintain,
// and adjust over time.
//
// @note This function fulfills the extern declaration in config.h. The
//       framework does not provide a default implementation; each application must define it.
// -------------------------------------------------------------------------------------------
void config_init(void);

#endif